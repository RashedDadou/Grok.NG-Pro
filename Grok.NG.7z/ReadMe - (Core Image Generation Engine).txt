# Core Image Generation Engine

Overview of Purpose and Core Concept: This file contains the core of a multidisciplinary image generation system (Traditional/Geometric/Futuristic/etc.). The main concept is: separating common logic (managing prompts, tasks, dependencies, timing, fallback, and refresh) from specialized logic (how parsing, integration, post-processing, and rendering are performed for each design type). It supports two main input modes: Batch (full description once) and Streaming (incremental writing → partial update and intelligent refresh).

Main Class Structure

CoreImageGenerationEngine (ABC)
    ├── __init__
    │   ├── specialization ← يأتي من _get_specialization_config()
    │   ├── tasks + dependencies + reverse_deps
    │   ├── input_port (list of strings)
    │   ├── prompt_state (حالياً غير مستخدم بقوة)
       │   └── last_task_data (للـ incremental refresh المستقبلي)
       │
    ├── receive_input(str) → تضيف قطعة نص جديدة
    │
    ├── add_task(name, complexity, dependencies)
    │
    ├── check_dependencies() → topological sort + التحقق من عدم وجود دورات
    │
    ├── generate_image(...) → الدالة الرئيسية
    │   ├── اكتشاف الوضع (batch / streaming)
    │   ├── تجميع الـ prompt الكامل
    │   ├── UnifiedStagePipeline.process(prompt, force_refresh)
    │   ├── memory_manager.advanced_creepy_filter (اختياري)
       │   ├── _render(task_data, is_video)
    │   └── _create_simple_image (placeholder حالياً: matplotlib)
    │
    └── الدوال المجردة التي يجب تنفيذها في كل subclass:
        ├── _get_specialization_config()
        ├── _analyze_prompt(prompt) → NLP
        ├── _integrate(task_data)
        ├── _post_process(task_data)
        ├── _render(task_data, is_video)
        └── _create_simple_image(task_data, is_video)

How the typical workflow currently works (batch mode): The user calls `engine.receive_input("Part of the description")` once or more. `engine.generate_image(force_refresh=..., is_video=...)`. Inside `generate_image`: `collects full_prompt = " ".join(self.input_port)`. `creates pipeline = UnifiedStagePipeline(self)`. `calls pipeline.process(full_prompt, force_refresh)`. It takes the result (`task_data`). It passes it to memory_manager.advanced_creepy_filter (if present). It calls `_render(task_data, is_video)`. It creates a simple preview via `_create_simple_image`. It returns `GenerationResult`.

Current state (January 2026) – Key strengths and weaknesses

Side
Current Status
Comment/Important Note
Batch mode
Works well
Passed recent tests on all three disciplines
Streaming/incremental
Only partially present (mode detection only)
No real process_delta yet – still replays all stages
Placeholder visuals
Very good in Geometric (spiral + koch)
Traditional and Futuristic are still too basic (matplotlib text + shapes)
post_processing return
Returns float → warning
Must be standardized to dict in all engines
memory_manager
Not enabled or visible in the last log
Needs real enablement or temporary removal of the condition
Error handling
Relatively good
Try/except is present in important places, but messages and fallback could be improved
Performance logging
Present and visible
stage_times appears in GenerationResult and print_generation_result

**Common Core for Multidisciplinary Image Generation Engines**

## Main Purpose

`Core_Image_Generation_Engine.py` is the Abstract Base Class that provides the common infrastructure for all specialized image generation engines (Traditional, Geometric, Futuristic, etc.).

It aims to:

- Unify the workflow (pipeline) between different disciplines
- Support streaming prompts and incremental refreshes
- Manage dependencies between tasks (tasks & dependencies graph)
- Accurately measure the performance of each stage
- Provide intelligent fallback and refresh mechanisms
- Separate rendering logic from analysis and integration

## Main Components

| Component | Description | Current State (January 2026) |

-------------------------------------------------------------------------------------------------------------------------

 ... Dataclass for tracking live prompt state (chunks, completed words, hash) | Partially used |

| `receive_input()` | Receives description bits (supports streaming) | Stable |

| `add_task()` + dependencies | Manages dynamic tasks with dependencies (topological sort) | Exists but not fully utilized |

| `_call_unit()` | Unified implementation for each stage (nlp, integration, post_processing, …) | Essential – system dependent |

| `UnifiedStagePipeline` | Unified stage implementation (currently created every time) | Works, but needs caching improvement |

| `generate_image()` | Main generation function (batch + streaming detection) | Works – passed 3 specialization tests |

| `_render()` + `_create_simple_image()` | Final output stage (currently placeholder) | placeholder → requires a real API |

| `memory_manager` | Creepy filter + context memory (optional) | Disabled/Not visible in the log |


Creepy filter + context memory (optional) ## Typical (Current) Workflow

1. `receive_input()` ← Collects prompt segments

2. `generate_image()` ←
- Detects mode (batch/streaming)
- Collects the full prompt
- Creates `UnifiedStagePipeline`
- Executes stages: nlp → integration → post_processing
- Passes result to `_render()`
- Creates simple preview (currently matplotlib)
3. Returns task_data to caller + saves preview path

## Currently Supported Features

- Automatic input pattern detection (batch vs streaming) via debounce
- Automatic task addition after NLP analysis
- Topological sort of tasks + dependency checking
- Accurately measures the time of each stage
- Force_refresh support
- Safe fallback in case of stage failure
- Saves simple previews + timestamps

## Current Limitations and Warnings (January 2026)

- Rendering The placeholder is still (matplotlib instead of a real model)
- `post_processing` returns a float instead of a dict → causes a warning
- Streaming support is only partially present (there is no real `process_delta` yet)
- `memory_manager.advanced_creepy_filter` is unused or disabled
- There are no negative prompts or advanced API parameters
- Real-time generation is very low (because the render is dummy)

## Suggested Steps for Future Development

1. Bind to a real API (fal.ai/replicate/stable-diffusion-webui/…)

2. Implement `process_delta` to support real incremental updates

3. Standardize the return format of each stage (→ a unified dict)

4. Enable and optimize `memory_manager` + creepy filter

5. Add support for negative prompts + seed + aspect ratio + style strength

6. Improve task_data caching between calls

7. Write unit tests for each stage

## How to Use (Simple example)

```python
engine = TraditionalDesignEngine()
engine.receive_input("A girl rides a white horse in a magical, foggy, and spooky forest")
result = engine.generate_image(force_refresh=True)
print(result.preview_path) # → traditional_preview_20260126_XXXXXX.png