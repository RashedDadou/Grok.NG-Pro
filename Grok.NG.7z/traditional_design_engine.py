# traditional_design_engine.py

import numpy as np
from dataclasses import dataclass, field   # ← أضف dataclass لو مش موجود
from typing import Dict, Any, Optional, List
from datetime import datetime
from PIL import Image, ImageDraw
import random
import logging
import math
from pathlib import Path
from time import perf_counter
from PIL import Image, ImageDraw, ImageFont

# الاستيراد الوحيد المهم (من الكور)
from Core_Image_Generation_Engine import CoreImageGenerationEngine
from memory_manager import GenerativeMemoryManager
from Image_generation import CoreImageGenerationEngine  # ← استيراد النواة
from generation_result import GenerationResult

print("تم تحميل traditional_design_engine.py")

logger = logging.getLogger(__name__)

from typing import List, Dict, Any, Optional
from copy import deepcopy

@dataclass
class TraditionalDesignResult:
    success: bool
    enhanced_prompt: str
    metadata: Dict[str, Any]
    layer_type: str = "foreground"
    message: str = ""
    design_time_seconds: float = 0.0
    
class traditionalDesignEngine(CoreImageGenerationEngine):
    """
    محرك متخصص في تحليل وتحسين وصف الكائنات التقليدية / العضوية فقط.
    الإخراج الرئيسي: dict نصي محسن + metadata
    لا يتدخل في توليد الصور النهائية (دور Final_Generation)
    """

    def __init__(self):
        super().__init__()
        self.specialization = {
            "name": "traditional_design",
            "type": "foreground",
            "description": "تصميم شخصيات ومخلوقات عضوية، تفاصيل تشريحية، تعبيرات عاطفية"
        }
        self.memory_manager = GenerativeMemoryManager()
        self.memory_manager.context_type = "traditional"
        logger.info("[TraditionalEngine] تم التهيئة – تصميم نصي فقط (foreground)")
        
    def _create_simple_image(self, prompt: str, target_size: tuple) -> Image.Image:
        """
        تنفيذ placeholder بسيط للدالة المطلوبة من الأب
        (هتنشئ صورة فارغة مع نص مؤقت عشان الكلاس يصير concrete)
        """
        img = Image.new("RGB", target_size, color=(220, 220, 220))  # رمادي فاتح
        draw = ImageDraw.Draw(img)
        draw.text((50, target_size[1]//2), f"Traditional Placeholder\n{prompt[:50]}...", fill=(0, 0, 0))
        return img
    
    def _get_specialization_config(self) -> Dict[str, Any]:
        return {"name": "traditional", "description": "تصميم عضوي"}

    def _analyze_prompt(self, prompt: str) -> Dict[str, Any]:
        return {"entities": prompt.split(), "style": "organic"}

    def _enhance_traditional_prompt(self, prompt: str) -> Dict[str, Any]:
        lower = prompt.lower()

        metadata = {
            "entities": self._extract_creatures(lower),
            "mood": self._detect_mood(lower),
            "lighting": self._suggest_lighting(lower),
            "anatomy": "highly detailed anatomy, realistic proportions, emotional expression",
            "details": "intricate skin texture, individual hair strands, fabric folds, subtle imperfections",
            "timestamp": datetime.now().isoformat()
        }

        enhanced = (
            f"{prompt}, {metadata['anatomy']}, {metadata['details']}, "
            f"{metadata['mood']} atmosphere, {metadata['lighting']}, "
            "masterpiece, best quality, ultra detailed, cinematic, 8k"
        )

        return {"prompt": enhanced, "metadata": metadata}

    def receive_input(self, prompt: str) -> bool:
        """
        تلقي prompt جديد مع التحقق الأساسي
        """
        if not isinstance(prompt, str) or not prompt.strip():
            logger.warning("Prompt غير صالح أو فارغ")
            return False

        stripped = prompt.strip()
        self.append_prompt_chunk(stripped)
        logger.info(f"[{self.specialization.get('name', 'unknown')}] received: {stripped[:60]}...")
        return True
    
    def _cleanup_temp_files(self):
        """
        حذف أي ملفات مؤقتة تم إنشاؤها (اختياري، حسب الحاجة)
        """
        for file_path in self.temp_files:
            try:
                Path(file_path).unlink()
                logger.info(f"تم حذف الملف المؤقت: {file_path}")
            except Exception as e:
                logger.warning(f"فشل حذف الملف المؤقت {file_path}: {e}")
        self.temp_files.clear()

    def append_prompt_chunk(self, chunk: str):
        """
        إضافة جزء من الـ prompt إلى المنفذ (بسيط ونظيف)
        """
        if not hasattr(self, "input_port"):
            self.input_port = []
        self.input_port.append(chunk.strip())
        logger.debug(f"Input chunk appended: {chunk[:50]}...")

    def add_task(self, task_name: str, complexity: float = 1.0, dependencies: Optional[List[str]] = None):
        """
        إضافة مهمة وصفية بسيطة (اختياري – للتتبع فقط، مش بصري)
        """
        if not hasattr(self, "tasks"):
            self.tasks = []
        self.tasks.append({
            "name": task_name,
            "complexity": complexity,
            "dependencies": dependencies or []
        })
        logger.debug(f"Added task: {task_name} (complexity: {complexity})")

    def _validate_specialization(self):
        pass

    def _initialize_units(self):
        pass

    def _initialize_memory_manager(self):
        self.memory_manager = GenerativeMemoryManager()
        self.memory_manager.context_type = "traditional"

    def _initialize_additional_state(self):
        self.temp_files = []

    def _log_specialization_details(self):
        logger.debug(f"تفاصيل تخصص: {self.specialization}")

    def _log_initial_state(self):
        logger.debug("حالة تهيئة تمت")

    def _run_initial_diagnostics(self):
        logger.debug("تشخيص أولي - ناجح")

    def _integrate(self, task_data: Dict) -> Dict:
        """
        دالة تكامل خفيفة جدًا (نصية فقط)
        """
        task_data.setdefault("entities", [])
        task_data.setdefault("summary", {})
        task_data.setdefault("warnings", [])
        task_data.setdefault("metadata", {})

        task_data["metadata"].update({
            "entities_count": len(task_data["entities"]),
            "mood": task_data.get("mood", "neutral"),
            "integration_done": True
        })

        task_data["summary"] = {
            "note": "تم التكامل النصي بنجاح"
        }

        return task_data

    def _post_process(self, task_data: Dict) -> Dict[str, Any]:
        return {"processed": True, "message": "post-processing placeholder"}

    def _render(self, task_data: Dict, is_video: bool = False) -> float:
        return 1.2

    def generate_layer(
        self,
        prompt: str,
        target_size: tuple = (1024, 1024),
        is_video: bool = False,
        as_layer: bool = True,
        force_refresh: bool = False,
        **kwargs
    ) -> GenerationResult:
        """
        تحليل وتحسين وصف كائن عضوي/تقليدي فقط
        لا ينشئ PlaneLayer هنا → يترك ذلك لـ LayerComposer أو المجمع النهائي
        """
        start_time = perf_counter()
        stage_times = {}

        try:
            # 1. تحليل الوصف
            analysis = self._analyze_prompt(prompt)
            
            # 2. استخراج الكيانات الرئيسية + الصفات
            main_subject = analysis.get("main_subject", "creature")
            mood = analysis.get("mood", "neutral")
            entities = analysis.get("entities", [])
            
            # 3. تحسين النص (الجزء الأقوى في هذا المحرك)
            enhanced_dict = self._enhance_traditional_prompt(prompt)
            enhanced_prompt = enhanced_dict["prompt"]
            metadata = enhanced_dict["metadata"]

            # 4. إعداد نتيجة نصية/وصفية فقط
            end_time = perf_counter() - start_time

            return GenerationResult(
                success=True,
                message=f"تم تحسين وصف كائن '{main_subject}' بنجاح",
                total_time=end_time,
                # لا نضع layer هنا بعد الآن
                output_data={
                    "original_prompt": prompt,
                    "enhanced_prompt": enhanced_prompt,
                    "main_subject": main_subject,
                    "entities": entities,
                    "mood": mood,
                    "metadata": metadata,
                    "suggested_for": "organic / traditional / character",
                    "generated_by": "traditional_engine",
                    "prompt_hash": self.memory_manager.get_prompt_hash(prompt) 
                                if hasattr(self.memory_manager, "get_prompt_hash") else None
                },
                specialization=self.specialization,
                is_video=is_video,
                stage_times=stage_times
            )

        except Exception as e:
            return GenerationResult(
                success=False,
                message=f"خطأ أثناء تحسين الوصف: {str(e)}",
                total_time=perf_counter() - start_time,
                stage_times=stage_times
            )
                
    def _extract_creatures(self, text: str) -> List[str]:
        # قائمة كلمات مفتاحية للكائنات
        creature_keywords = {
            "dragon", "elf", "orc", "goblin",
            "girl", "boy", "woman", "man", "child", "baby", "horse", "dragon", "lion", "wolf",
            "cat", "dog", "bird", "fish"
        }

        words = text.split()
        entities = set()
        for word in words:
            clean = word.strip(".,!?;:()[]{}'\"")
            if clean in creature_keywords:
                entities.add(clean)

        return list(entities)

    def _detect_mood(self, text: str) -> str:
        mood_indicators = {
            "غامض": "mysterious", "ظلام": "dark", "ضباب": "foggy", "رعب": "horror",
            "هادئ": "calm", "جميل": "beautiful", "رقيق": "delicate", "ساحر": "enchanted",
            "ملحمي": "epic", "قوي": "powerful", "مهيب": "majestic"
        }

        words = text.split()
        for word in words:
            if word in mood_indicators:
                return mood_indicators[word]
        return "neutral"

    def _suggest_lighting(self, text: str) -> str:
        if "ليل" in text or "night" in text:
            return "moonlight, dramatic shadows"
        elif "صباح" in text or "morning" in text:
            return "soft golden light, warm tones"
        return "natural daylight"

# ────────────────────────────────────────────────
#              اختبار سريع (اختياري)
# ────────────────────────────────────────────────

if __name__ == "__main__":
    print("traditional_design_engine.py تم تحميله كـ __main__")
    engine = traditionalDesignEngine()
    print("تم إنشاء الكائن بنجاح")
    print("generate_layer موجود؟", hasattr(engine, "generate_layer"))
    print("═" * 70)
    print("اختبار Traditional Design Engine")
    print("═" * 70)

    engine = traditionalDesignEngine()

    # prompt مناسب للـ traditional
    engine.receive_input("a majestic dragon creature in enchanted misty forest with glowing aura and organic flow")

    # أضف مهام بسيطة
    engine.add_task("main_creature", complexity=4.8)
    engine.add_task("forest_background", complexity=3.5)
    engine.add_task("aura_effect", complexity=2.7)

    result = engine.generate_layer("test prompt")

    print("\nنتيجة التوليد:")
    print(f"نجاح: {result.success}")
    print(f"رسالة: {result.message}")
    print(f"الوقت الكلي: {result.total_time:.2f} ث")
    if result.output_data and "preview_path" in result.output_data:
        print(f"مسار المعاينة: {result.output_data['preview_path']}")