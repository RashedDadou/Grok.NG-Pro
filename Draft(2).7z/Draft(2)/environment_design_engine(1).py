# environment_design_engine.py
"""
محرك التوليد الخاص بالتصاميم البيئية / الطبيعية
...
"""
import os
from typing import Dict, Any, List, Optional
from copy import deepcopy
from time import perf_counter
from PIL import Image, ImageDraw
from numpy._core.defchararray import lower
from Image_generation import CoreImageGenerationEngine, GenerationResult, perf_counter   # ← أضف GenerationResult هنا

import logging
import numpy as np
import matplotlib.pyplot as plt
from pathlib import Path
from datetime import datetime
from layer_engine import LayerEngine  # أو المسار الصحيح
from typing import Tuple  # لو مش موجود
from numpy import random
from html import entities

import math
import random

from memory_manager import GenerativeMemoryManager

logger = logging.getLogger(__name__)


class environment_design_engine(LayerEngine, CoreImageGenerationEngine):
    def __init__(self):
        super().__init__()

        # ─── الحالة الأساسية ────────────────────────────────
        self.input_port: List[str] = []
        self.tasks: List[Dict[str, Any]] = []
        self.render_time: Optional[float] = None
        self.last_task_data: Optional[Dict[str, Any]] = None

        # ─── التخصص (نسخة مستقلة) ─────────────────────────────
        from copy import deepcopy
        self.specialization = deepcopy(self._get_specialization_config())

        # ─── إدارة الذاكرة ──────────────────────────────────────
        self.memory_manager = GenerativeMemoryManager()

        # ─── تهيئة الـ units بشكل مركزي ومنظم ────────────────────
        units = self.specialization.setdefault("units", {})

        # الكلمات المشتركة مرة واحدة فقط
        common_keywords = [
            "environment", "cyber", "cyberpunk", "neon", "hologram", "spaceship",
            "drone", "robot", "tech", "sci-fi", "high-tech", "glow", "circuit",
            "grid", "matrix", "digital", "virtual", "augmented"
        ]

        # المراحل
        stages = ["nlp", "integration", "post_processing", "rendering"]

        for stage in stages:
            unit = units.setdefault(stage, {})
            unit["refreshed"] = False
            unit["validate_keywords"] = common_keywords[:]  # نسخة مستقلة

        # ربط الدوال (غيّر الأسماء حسب اللي عندك فعليًا)
        units["nlp"]["function"]          = self._analyze_prompt
        units["integration"]["function"]  = self._integrate_environment
        units["post_processing"]["function"] = self._post_process_environment
        units["rendering"]["function"]    = self._render_environment

        # إضافات إضافية للتخصص (لو مش موجودة في _get_specialization_config)
        self.specialization.setdefault("description", "تصاميم بيئية، مناطق طبيعية، أشجار، نباتات، تأثيرات ضوء وظل، جبال، مياه، سايبربانك، نيون")
        self.specialization.setdefault("name", "environment_design")
        self.specialization.setdefault("rendering_style", "environmental")
    
    def generate_layer(
        self,
        prompt: str,
        target_size: Tuple[int, int] = (1024, 1024),
        is_video: bool = False,
        as_layer: bool = True,
        force_refresh: bool = False,
        **kwargs
    ) -> GenerationResult:
        """الواجهة الجديدة المفضلة – prompt مباشر بدون input_port"""
        logger.info(f"[Core Layer] generate_layer called with direct prompt: {prompt[:70]}...")
        return self._run_generation(
            prompt=prompt,
            target_size=target_size,
            is_video=is_video,
            as_layer=as_layer,
            force_refresh=force_refresh,
            **kwargs
        )

    def generate_image(
        self,
        force_refresh: bool = False,
        as_layer: bool = True,
        target_size: Tuple[int, int] = (1024, 1024),
        reset_input_after: bool = True,
        is_video: bool = False,
        **kwargs
    ) -> GenerationResult:
        """الواجهة القديمة للتوافق – تجمع من input_port"""
        if not self.input_port:
            return GenerationResult(
                success=False,
                message="لا يوجد prompt في input_port",
                total_time=0.0,
                stage_times={},
                specialization=self.specialization.get("name", "unknown")
            )

        full_prompt = " ".join(self.input_port).strip()
        logger.info(f"[Core Image] generate_image called – collected prompt: {full_prompt[:70]}...")

        result = self._run_generation(
            prompt=full_prompt,
            target_size=target_size,
            is_video=is_video,
            as_layer=as_layer,
            force_refresh=force_refresh,
            **kwargs
        )

        if reset_input_after:
            self.input_port.clear()

        return result
    
    def add_task(self, task_name: str, complexity: float = 1.0, dependencies: Optional[List[str]] = None):
        if not hasattr(self, "tasks"):
            self.tasks = []
        self.tasks.append({"name": task_name, "complexity": complexity, "dependencies": dependencies or []})

    def get_tasks(self) -> List[Dict]:
        return getattr(self, "tasks", [])
    
    def receive_input(self, prompt: str) -> bool:
        if not isinstance(prompt, str) or not prompt.strip():
            logger.warning("Prompt غير صالح أو فارغ")
            return False

        stripped = prompt.strip()
        self.append_prompt_chunk(stripped)
        logger.info(f"[Environment] received: {stripped[:60]}...")
        return True

    def append_prompt_chunk(self, chunk: str):
        if not hasattr(self, "input_port"):
            self.input_port = []
        self.input_port.append(chunk)
        logger.debug(f"Input chunk appended: {chunk[:50]}...")
        
    def _get_specialization_config(self) -> Dict[str, Any]:
        return {
            "name": "environment_design",
            "rendering_style": "environmental",
            "description": "تصاميم بيئية، مناطق طبيعية، أشجار، نباتات، تأثيرات ضوء وظل، جبال، مياه...",
            "validate_keywords": [
                "environment", "cyber", "cyberpunk", "neon", "hologram", "spaceship",
                "drone", "robot", "tech", "sci-fi", "high-tech", "glow", "circuit",
                "grid", "matrix", "digital", "virtual", "augmented"
            ],
            "units": {
                "nlp": {
                    "function": self._analyze_prompt,
                    "refreshed": False
                },
                "rendering": {
                    "function": self._render_environment,
                    "refreshed": False
                },
                "integration": {
                    "function": self._integrate_environment,
                    "refreshed": False
                },
                "post_processing": {
                    "function": self._post_process_environment,
                    "refreshed": False
                }
            }
        }

    def _render_environment(self, task_data: Dict, is_video: bool = False) -> float:
        """
        مرحلة الـ rendering الخاصة بالتصاميم البيئية.
        تقوم بإنشاء المعاينة أو الإطارات المتحركة، وتقيس الوقت الحقيقي للعملية بأكملها.
        
        Parameters:
            task_data (Dict): البيانات المحللة من الـ prompt
            is_video (bool): هل نريد فيديو (GIF) أم صورة ثابتة
        
        Returns:
            float: الوقت الفعلي الذي استغرقته عملية الرسم/التوليد (بالثواني)
        """
        t_start = perf_counter()  # بداية القياس الدقيق

        try:
            # استدعاء الدالة المتخصصة في إنشاء الصورة / الإطارات
            preview_path = self._create_simple_image(task_data, is_video=is_video)

            if preview_path:
                logger.info(f"[environment Render] تم إنشاء المعاينة بنجاح → {preview_path}")
            else:
                logger.warning("[environment Render] لم يتم إرجاع مسار معاينة (ربما فشل داخلي)")

        except Exception as render_err:
            logger.exception("[environment Render] خطأ أثناء إنشاء المعاينة")
            preview_path = None

        # ─── نهاية القياس والتسجيل ──────────────────────────────────────────────
        render_time = perf_counter() - t_start

        mode = "فيديو (GIF)" if is_video else "صورة ثابتة"
        complexity = sum(t.get("complexity", 0) for t in self.tasks)

        logger.info(
            f"[environment Render] تعقيد: {complexity:.1f} | "
            f"وقت حقيقي لـ {mode}: {render_time:.3f} ث | "
            f"mood: {task_data.get('mood', 'غير محدد')}"
        )

        # إرجاع الوقت الحقيقي (يستخدم في stage_times في generate_image)
        return render_time

    def _integrate_environment(self, task_data: Dict) -> Dict:
        """
        تكامل طبقات البيئة بناءً على المهام الموجودة في self.tasks
        (التي تم إنشاؤها تلقائيًا بواسطة _post_analyze_add_tasks)
        """
        logger.info("===== بدء _integrate_environment =====")
        logger.debug(f"عدد المهام الحالية: {len(self.tasks)}")

        planes = []
        interactions = []

        refreshed = self.specialization["units"].get("integration", {}).get("refreshed", False)
        total_complexity = sum(t.get("complexity", 0) for t in self.tasks)

        # ─── خريطة أساسية للخصائص (يمكن توسيعها بسهولة) ────────────────────────
        base_plane_props = {
            # أساسيات
            "ground":        {"z": 0.0,  "color": "#2a3f2a", "force": 0.60, "mass": 2.8},
            "sky":           {"z": 0.8,  "color": "#4a6a9a", "force": 0.40, "mass": 1.5},
            "horizon":       {"z": 0.4,  "color": "#88aaff", "force": 0.50, "mass": 1.9},

            # طبيعة
            "mountains":     {"z": 0.2,  "color": "#5a6a7a", "force": 0.65, "mass": 3.0},
            "trees":         {"z": 0.3,  "color": "#1a4a1a", "force": 0.55, "mass": 2.4},
            "forest_canopy": {"z": 0.35, "color": "#0f3a0f", "force": 0.58, "mass": 2.6},
            "water":         {"z": 0.25, "color": "#1a4a7a", "force": 0.70, "mass": 2.5},
            "sand_dunes":    {"z": 0.15, "color": "#c9a875", "force": 0.50, "mass": 2.2},

            # جو / تأثيرات
            "clouds":        {"z": 0.7,  "color": "#d0e0ff", "force": 0.45, "mass": 1.2},
            "fog":           {"z": 0.6,  "color": "#c0d0d0", "force": 0.75, "mass": 0.9},
            "rain":          {"z": 0.55, "color": "#aaccff", "force": 0.80, "mass": 0.8},
            "stars":         {"z": 0.9,  "color": "#ffffff", "force": 0.35, "mass": 1.0},
            "nebula":        {"z": 0.85, "color": "#663399", "force": 0.50, "mass": 1.3},

            # تكنولوجي
            "cityscape":     {"z": 0.1,  "color": "#1a0033", "force": 0.70, "mass": 2.8},
            "neon_glow":     {"z": 0.5,  "color": "#00ffff", "force": 0.90, "mass": 0.9},
        }

        # ─── 1. إنشاء طبقات من المهام الموجودة ───────────────────────────────────
        for task in self.tasks:
            name_lower = task["name"].lower()
            config = base_plane_props.get(name_lower)

            # إذا ما لقينا تطابق دقيق → نعطي قيم افتراضية معقولة
            if not config:
                # محاولة تخمين z و color بناءً على اسم المهمة
                if "sky" in name_lower or "stars" in name_lower or "nebula" in name_lower:
                    z = 0.7 + random.uniform(0, 0.2)
                    color = "#334466"
                elif "ground" in name_lower or "sand" in name_lower or "dunes" in name_lower:
                    z = 0.0
                    color = "#8b7355"
                elif "water" in name_lower or "ocean" in name_lower:
                    z = 0.2
                    color = "#1e4a7a"
                else:
                    z = 0.4
                    color = "#666688"

                plane = {
                    "label": task["name"],
                    "z": z,
                    "color": color,
                    "force": 0.55,
                    "mass": 1.8,
                    "complexity": task.get("complexity", 2.0),
                }
            else:
                plane = {
                    "label": task["name"],
                    "z": config["z"],
                    "color": config["color"],
                    "force": config["force"],
                    "mass": config["mass"],
                    "complexity": task.get("complexity", 2.5),
                }

            planes.append(plane)
            logger.debug(f"أُضيفت طبقة: {plane['label']} (z={plane['z']})")

        # ─── 2. تفاعلات بسيطة (اختياري) ─────────────────────────────────────────
        if len(planes) >= 2:
            for i in range(len(planes)):
                for j in range(i + 1, len(planes)):
                    strength = 0.2 + (planes[i]["force"] * planes[j]["force"]) * 0.15
                    interactions.append({
                        "from": planes[i]["label"],
                        "to": planes[j]["label"],
                        "strength": round(strength, 2)
                    })

        # ─── 3. تحديث task_data ────────────────────────────────────────────────────
        task_data["planes"] = planes
        task_data["plane_interactions"] = interactions
        task_data["integration_summary"] = {
            "layers_count": len(planes),
            "interactions_count": len(interactions),
            "total_complexity": total_complexity,
            "avg_force": round(sum(p["force"] for p in planes) / len(planes), 2) if planes else 0.0
        }

        # وقت تقديري معدل
        est_time = 0.30 + len(planes)*0.11 + len(interactions)*0.04 + total_complexity*0.20
        task_data["integration_time"] = round(est_time, 2)

        logger.info(
            f"[Environment Integrate] → {len(planes)} طبقة | {len(interactions)} تفاعل | "
            f"تعقيد: {total_complexity:.1f} | وقت تقريبي: {est_time:.2f} ث"
        )

        return task_data

    def _post_analyze_add_tasks(self, task_data: dict) -> None:
        """
        تحويل الكيانات المستخرجة والمزاج إلى مهام تصميم بيئية فرعية
        مع تعقيد افتراضي واعتماديات بسيطة.
        """
        logger.info("===== بدء _post_analyze_add_tasks (Environment) =====")
        logger.debug(f"Entities: {task_data.get('entities', [])} | Mood: {task_data.get('mood', 'neutral')}")

        # ─── خريطة التعقيد الأساسية لمهام البيئة ────────────────────────────────
        env_task_complexity = {
            # طبقات أساسية
            "ground":          2.8,
            "sky":             2.2,
            "horizon":         2.5,
            "mountains":       3.4,
            "hills":           2.9,
            "trees":           3.1,
            "forest_canopy":   3.6,
            "water":           3.3,
            "ocean_waves":     3.5,
            "sand_dunes":      3.0,
            "rocks":           2.7,

            # جو / تأثيرات
            "clouds":          2.4,
            "fog":             2.6,
            "mist":            2.3,
            "rain":            3.2,
            "storm":           3.8,
            "stars":           2.1,
            "nebula":          3.0,
            "aurora":          3.7,
            "sunset":          2.9,
            "moonlight":       2.5,

            # تكنولوجي / cyber
            "cityscape":       3.5,
            "skyscrapers":     3.9,
            "neon_glow":       3.2,
            "holograms":       3.4,
            "flying_vehicles": 3.6,
        }

        added_count = 0
        added_tasks = []

        entities = [e.lower() for e in task_data.get("entities", [])]
        mood = task_data.get("mood", "neutral")

        if not entities:
            logger.info("لا توجد entities → لن تُضاف مهام تلقائية")
            return

        # ─── 1. إضافة مهمة رئيسية بناءً على أبرز entity ────────────────────────
        main_env = None
        for e in entities:
            if e in env_task_complexity:
                main_env = e
                break
            # fallback ذكي جزئي
            for key in env_task_complexity:
                if key in e or e in key:
                    main_env = key
                    break
            if main_env:
                break

        if main_env:
            complexity = env_task_complexity.get(main_env, 3.0)
            # تعديل طفيف حسب المزاج
            if mood in ["epic", "mysterious"]:
                complexity *= 1.15
            elif mood == "calm":
                complexity *= 0.9

            if not any(t["name"].lower() == main_env for t in self.tasks):
                self.add_task(
                    task_name=main_env.capitalize(),
                    complexity=round(complexity, 1),
                    dependencies=[]
                )
                added_count += 1
                added_tasks.append(main_env.capitalize())

        # ─── 2. إضافة مهام فرعية تلقائية حسب النوع والمزاج ──────────────────────
        sub_tasks = []

        # مهام شبه مشتركة
        if any(e in entities for e in ["forest", "trees", "jungle"]):
            sub_tasks.extend(["ground", "trees", "forest_canopy"])
        if any(e in entities for e in ["mountain", "جبل", "peak"]):
            sub_tasks.extend(["ground", "mountains", "sky"])
        if any(e in entities for e in ["desert", "صحراء", "sand", "dune"]):
            sub_tasks.extend(["ground", "sand_dunes", "sky"])
        if any(e in entities for e in ["ocean", "sea", "water", "بحر"]):
            sub_tasks.extend(["water", "horizon", "sky"])
        if any(e in entities for e in ["space", "galaxy", "stars", "nebula"]):
            sub_tasks.extend(["stars", "nebula", "sky"])

        # تأثيرات جوية حسب المزاج أو الكلمات
        if mood in ["mysterious", "epic"] or any(w in task_data.get("raw_prompt", "").lower() for w in ["fog", "mist", "ضباب"]):
            sub_tasks.append("fog")
        if mood == "stormy" or "storm" in entities or "rain" in entities:
            sub_tasks.append("rain")
            sub_tasks.append("storm")

        # cyber-specific
        if any(e in entities for e in ["cybercity", "cityscape", "neon_glow"]):
            sub_tasks.extend(["cityscape", "neon_glow", "horizon"])

        # ─── 3. إضافة المهام الفرعية مع تجنب التكرار ────────────────────────────
        for sub in sub_tasks:
            sub_lower = sub.lower()
            if not any(t["name"].lower() == sub_lower for t in self.tasks):
                comp = env_task_complexity.get(sub_lower, 2.5)
                # زيادة طفيفة إذا كان المزاج معقد
                if mood in ["epic", "mysterious", "stormy"]:
                    comp *= 1.12

                self.add_task(
                    task_name=sub.capitalize(),
                    complexity=round(comp, 1),
                    dependencies=[main_env.capitalize()] if main_env else []
                )
                added_count += 1
                added_tasks.append(sub.capitalize())

        # ─── تسجيل النتيجة ────────────────────────────────────────────────────────
        if added_count > 0:
            logger.info(f"تم إضافة {added_count} مهمة بيئية تلقائيًا: {added_tasks}")
        else:
            logger.info("لم تُضف مهام جديدة (كلها موجودة أو entities فارغة)")
       
    def generate_image(
        self,
        force_refresh: bool = False,
        as_layer: bool = True,
        target_size: tuple = (1024, 1024),
        reset_input_after: bool = True,
        is_video: bool = False,
        **kwargs
    ) -> GenerationResult:
        start_total = perf_counter()
        stage_times = {}

        try:
            if not self.input_port:
                return GenerationResult(
                    success=False,
                    message="لا يوجد prompt في المنفذ",
                    total_time=0.0,
                    stage_times={},
                    specialization=self.specialization["name"],
                    output_data={}
                )

            full_prompt = " ".join(self.input_port).strip()
            logger.info(f"[Env generate_image] prompt: {full_prompt[:70]}... | as_layer={as_layer} | video={is_video}")

            # ─── أولاً: التحليل (هنا بيتم تعريف task_data) ────────────────────────────
            t_analyze = perf_counter()
            if force_refresh or not hasattr(self, 'last_task_data'):
                task_data = self._analyze_prompt(full_prompt)
                self._post_analyze_add_tasks(task_data)
                self.last_task_data = task_data
            else:
                task_data = self.last_task_data
            stage_times["analyze"] = perf_counter() - t_analyze

            # ─── ثانيًا: التنظيف والـ refresh باستخدام memory_manager (بعد task_data) ───
            if self.memory_manager.check_for_creepy(full_prompt, task_data):
                recovered = self.memory_manager.auto_recovery_on_creepy(full_prompt, "environment_design")
                if recovered:
                    task_data = recovered
                task_data = self.memory_manager.refresh_memory(full_prompt, task_data, "environment_design")
                logger.info("[Env] تم refresh الذاكرة بسبب creepy detection")

            # ─── ثالثًا: Rendering ────────────────────────────────────────────────────────
            t_render = perf_counter()
            render_time, preview_path = self._render(task_data, is_video=is_video)
            stage_times["render"] = render_time

            if not preview_path:
                raise RuntimeError("فشل إنشاء طبقة")

            total_time = perf_counter() - start_total

            result = GenerationResult(
                success=True,
                message=f"تم إنشاء طبقة بنجاح ({self.specialization['name']})" + (" - فيديو GIF" if is_video else ""),
                total_time=total_time,
                stage_times=stage_times,
                specialization=self.specialization["name"],
                output_data={
                    "preview_path": str(Path(preview_path).absolute()),
                    "layer_type": "background" if "environment" in self.specialization["name"] else "midground" if "geometric" in self.specialization["name"] else "foreground",
                    "is_transparent": True,
                    "is_video": is_video,
                    "prompt_used": full_prompt
                }
            )

            logger.info(f"[{self.specialization['name']}] نجح → {preview_path} | وقت كلي: {total_time:.2f} ث")

            if reset_input_after:
                self.input_port.clear()

            return result

        except Exception as e:
            logger.exception(f"[{self.specialization['name']} generate_image] فشل")
            total_time = perf_counter() - start_total
            return GenerationResult(
                success=False,
                message=f"فشل توليد طبقة: {str(e)}",
                total_time=total_time,
                stage_times=stage_times,
                specialization=self.specialization["name"],
                output_data={}
            )
        
    def _post_process(self, task_data: Dict) -> Dict[str, Any]:
        # حساب الوقت التقريبي (أو أي منطق عندك)
        duration = 8.8  # أو أي قيمة

        logger.info(f"[Traditional Post-process] وقت تقريبي: {duration:.1f}s")

        return {
            "success": True,
            "duration_seconds": duration,
            "summary": "Traditional post-processing completed",
            "warnings": [],
            "metadata": {
                "mood": task_data.get("mood", "unknown"),
                "entities_count": len(task_data.get("entities", []))
            }
        }

    def generate_temp_reference(self, prompt_dict: dict) -> str | None:
        """
        توليد صورة مرجعية مؤقتة بسيطة (placeholder / layout / depth-like)
        - تستخدم فقط لمساعدة Final_Generation في تغيير الزاوية
        - تحفظ مؤقتًا وتُسجّل في self.temp_files للحذف لاحقًا
        """
        import time
        import os
        from PIL import Image, ImageDraw

        try:
            timestamp = int(time.time() * 1000)
            temp_path = f"temp_env_ref_{timestamp}.png"

            width, height = prompt_dict.get("target_size", (1024, 1024))

            img = Image.new("RGB", (width, height), color=(10, 15, 30))
            draw = ImageDraw.Draw(img)

            # رسم تخطيط بسيط جدًا (يمكن تحسينه لاحقًا بـ depth أو canny)
            draw.rectangle([(0, height//2), (width, height)], fill=(30, 50, 70))  # أرض
            draw.line((0, height//3, width, height//3), fill="cyan", width=8)     # خط أفق
            draw.ellipse((width//4, height//4, width*3//4, height*3//4), outline="white", width=5)

            img.save(temp_path, "PNG")
            logger.info(f"[Temp Ref] تم حفظ: {temp_path}")

            if not hasattr(self, 'temp_files'):
                self.temp_files = []
            self.temp_files.append(temp_path)

            return temp_path

        except Exception as e:
            logger.error(f"فشل توليد مرجع: {e}")
            return None

# ────────────────────────────────────────────────
#              تنفيذ اختياري للـ preview
# ────────────────────────────────────────────────

    def _analyze_prompt(self, prompt: str) -> Dict[str, Any]:
        if not prompt or not isinstance(prompt, str):
            logger.warning("Prompt فارغ أو غير صالح")
            prompt = ""

        lower = prompt.lower()

        # ─── كشف الكيانات بطريقة منظمة وغير مكررة ────────────────────────────────
        entities = set()

        # كلمات كاملة (دقيقة)
        words = set(lower.split())

        # ─── Cybercity / مدينة مستقبلية ────────────────────────────────────────────
        cybercity_indicators = {
            "city", "cybercity", "megacity", "skyscraper", "cityscape",
            "ناطحات", "مدينة", "سايبر", "سكاي سكريبر"
        }
        if any(w in words for w in cybercity_indicators) or "cyber" in lower:
            entities.add("cybercity")

        # ─── Neon / Glow / Holographic ───────────────────────────────────────────────
        neon_indicators = {
            "neon", "glow", "hologram", "holo", "billboard", "نيون", "توهج", "هولوغرام"
        }
        if any(ind in lower for ind in neon_indicators):
            entities.add("neon_glow")

        # ─── مركبات فضائية / سفن ──────────────────────────────────────────────────
        spaceship_indicators = {
            "spaceship", "ship", "craft", "ufo", "سفينة", "مركبة فضائية"
        }
        if any(w in words for w in spaceship_indicators):
            entities.add("spaceship")

        # ─── روبوتات / ميكانيكية ──────────────────────────────────────────────────
        robotics_indicators = {
            "drone", "robot", "android", "mech", "درون", "روبوت", "ميكا"
        }
        if any(w in words for w in robotics_indicators):
            entities.add("robotics")

        # ─── تحديد المزاج (mood) ───────────────────────────────────────────────────
        if any(w in lower for w in ["cyber", "cyberpunk", "punk", "سايبر", "بانك"]):
            mood = "cyberpunk"
        elif any(w in lower for w in ["sleek", "tech", "environment", "نظيف", "تكنولوجي"]):
            mood = "sleek_tech"
        elif any(w in lower for w in ["mysterious", "enchanted", "سحري", "غامض"]):
            mood = "mysterious"
        elif any(w in lower for w in ["calm", "peaceful", "هادئ"]):
            mood = "calm"
        else:
            mood = "neutral"

        # ─── بناء النتيجة ──────────────────────────────────────────────────────────
        result = {
            "entities": list(entities),
            "style": "environmental",
            "mood": mood,
            "main_element": entities.pop() if entities else "generic_background",
            "raw_prompt": prompt,
            "analysis_timestamp": datetime.now().isoformat(),
        }

        logger.info(
            f"[Environment Analyze] entities={result['entities']!r} | "
            f"mood={mood} | main={result['main_element']}"
        )

        # ─── الاستدعاء الجديد: إضافة المهام التلقائية ─────────────────────────────
        self._post_analyze_add_tasks(result)

        return result
        complexity = sum(t.get("complexity", 0) for t in self.tasks)
        base_time = complexity * 0.7

        logger.info(f"[environment Post-process] وقت تقريبي: {base_time:.1f}s")
        return base_time   

    def _integrate(self, task_data: Dict) -> Dict:
        # تهيئة الحقول المتوقعة لو مش موجودة
        task_data.setdefault("entities", [])
        task_data.setdefault("planes", [])
        task_data.setdefault("summary", {})
        task_data.setdefault("warnings", [])
        task_data.setdefault("metadata", {})
        # تحديث metadata بمعلومات إضافية
        task_data["metadata"].update({
            "integration_time": task_data.get("integration_time", 0.0),
            "planes_count": len(task_data["planes"]),
            "entities_count": len(task_data["entities"])
        })

    def _post_process_environment(self, task_data: Dict) -> float:
        complexity = sum(t.get("complexity", 0) for t in self.tasks)
        base_time = complexity * 0.7

        logger.info(f"[environment Post-process] وقت تقريبي: {base_time:.1f}s")
        return base_time

    def _render(self, task_data: Dict, is_video: bool = False) -> tuple[float, Optional[str]]:
        """
        مرحلة الـ rendering الرئيسية لمحرك البيئة.
        تنتج طبقة خلفية (background layer) وليس صورة نهائية كاملة.
        
        Returns:
            tuple[float, Optional[str]]: 
                - الوقت الفعلي للعملية (ثواني)
                - مسار الطبقة المُنشأة (أو None إذا فشل)
        """
        t_start = perf_counter()
        preview_path = None

        try:
            logger.debug("[Environment Render] بدء توليد طبقة الخلفية...")

            # ─── دعم أفضل للفيديو (حتى لو placeholder حاليًا) ─────────────────────
            if is_video:
                logger.info("[Environment Render] طلب فيديو → سيتم توليد GIF بسيط (placeholder)")
                # هنا يمكن توسيع لاحقًا لعدد إطارات أكبر أو حركة أقوى
                n_frames = 16  # عدد إطارات افتراضي للـ GIF
            else:
                n_frames = 1

            preview_path = self._create_simple_image(
                task_data=task_data,
                is_video=is_video,
                transparent_bg=False,          # الخلفية عادة غير شفافة (background)
                target_size=(1024, 1024),
                layer_opacity=255              # كاملة لأنها الطبقة الأساسية
            )

            if preview_path and Path(preview_path).exists():
                suffix = "GIF" if is_video else "PNG"
                logger.info(f"[Environment Render] تم إنشاء طبقة {suffix} بنجاح → {preview_path}")
            else:
                logger.warning("[Environment Render] فشل في إنشاء مسار طبقة صالح")

        except Exception as e:
            logger.exception("[Environment Render] خطأ أثناء توليد طبقة الخلفية")
            preview_path = None

        render_time = perf_counter() - t_start

        # تسجيل واضح
        mode = "فيديو (GIF)" if is_video else "طبقة خلفية ثابتة"
        time_str = f"{render_time:.3f} ث" if render_time >= 0.02 else f"{render_time:.4f} ث (سريع)"
        path_str = preview_path or "فشل"
        logger.info(f"[Environment Render] {mode} | وقت: {time_str} | مسار: {path_str}")

        return render_time, preview_path

    def _create_simple_image(
        self,
        task_data: Dict,
        is_video: bool = False,
        transparent_bg: bool = False,
        target_size: tuple = (1024, 1024),
        layer_opacity: int = 255
    ) -> Optional[str]:
        """
        إنشاء طبقة خلفية بيئية بناءً على الـ entities والـ mood
        """
        try:
            from PIL import Image, ImageDraw
            import random
            import math
            from pathlib import Path
            from datetime import datetime

            width, height = target_size
            n_frames = 12 if is_video else 1
            frames = []

            entities_set = set(str(e).lower() for e in task_data.get("entities", []))
            raw = task_data.get("raw_prompt", "").lower()
            mood = task_data.get("mood", "neutral")

            for frame in range(n_frames):
                # ─── اختيار لون خلفية أساسي ───────────────────────────────
                if transparent_bg:
                    img = Image.new("RGBA", (width, height), (0, 0, 0, 0))
                    base_color = (0, 0, 0, 0)
                else:
                    img = Image.new("RGB", (width, height), (8, 8, 24))
                    base_color = (8, 8, 24)

                draw = ImageDraw.Draw(img)

                # ─────────────────────────────────────────────────────────────
                # حالات متعددة مرتبة حسب الأولوية الشائعة
                # ─────────────────────────────────────────────────────────────

                if "cyberpunk" in entities_set or "neon_glow" in entities_set or "cybercity" in entities_set:
                    # ─── Cyberpunk / Neon City ───────────────────────────────
                    img = Image.new("RGB", (width, height), (6, 0, 20))
                    # أفقي نيون
                    for y in range(40, height, random.randint(90, 180)):
                        a = random.randint(90, 220)
                        draw.line((0, y, width, y), fill=(0, 255, 240, a), width=2)
                    # رأسي نيون
                    for x in range(60, width, random.randint(110, 220)):
                        a = random.randint(80, 190)
                        draw.line((x, 0, x, height), fill=(255, 60, 220, a), width=1)
                    # جسيمات / نقاط نيون
                    for _ in range(80):
                        x = random.randint(0, width)
                        y = (random.randint(0, height) + frame * 6) % height
                        sz = random.uniform(1.2, 5)
                        draw.ellipse((x-sz, y-sz, x+sz, y+sz), fill=(0, 255, 255, 160))

                elif "space" in entities_set or "galaxy" in entities_set or "stars" in entities_set or "nebula" in raw:
                    # ─── Space / Galaxy / Night Sky ──────────────────────────
                    img = Image.new("RGB", (width, height), (3, 0, 12))
                    # نجوم صغيرة كثيرة
                    for _ in range(600):
                        x, y = random.randint(0, width), random.randint(0, height)
                        sz = random.uniform(0.6, 2.1)
                        br = random.randint(140, 255)
                        draw.point((x, y), fill=(br, br, br))
                    # نجوم أكبر (قليلة)
                    for _ in range(18):
                        x, y = random.randint(0, width), random.randint(0, height)
                        sz = random.uniform(2.5, 5.5)
                        draw.ellipse((x-sz, y-sz, x+sz, y+sz), fill=(255, 245, 220))
                    # سديم خفيف (2-5 مناطق)
                    for _ in range(random.randint(2, 5)):
                        cx = random.randint(100, width-100)
                        cy = random.randint(100, height-100)
                        for r in range(80, 380, 45):
                            a = int(35 + 25 * math.sin(frame*0.08 + r*0.015))
                            draw.ellipse((cx-r, cy-r, cx+r, cy+r), outline=(90, 40, 220, max(0,a)))

                elif "desert" in entities_set or "صحراء" in raw or "sand" in raw or "dune" in raw:
                    # ─── Desert / Sand Dunes ─────────────────────────────────
                    # تدرج رملي
                    for y in range(height):
                        t = y / height
                        r = int(180 + 40 * t)
                        g = int(140 + 60 * t)
                        b = int(60 + 30 * t)
                        draw.line((0, y, width, y), fill=(r, g, b))
                    # كثبان رملية (منحنيات بسيطة)
                    for _ in range(6):
                        base_x = random.randint(-200, width + 200)
                        base_y = height - random.randint(80, 300)
                        points = []
                        for i in range(0, width + 400, 80):
                            x = base_x + i
                            wave = math.sin(i * 0.008 + frame * 0.04) * 35
                            points.append((x, base_y + wave + math.sin(i * 0.015) * 60))
                        if len(points) >= 2:
                            draw.polygon(points + [(width, height), (0, height)], fill=(210, 170, 100))

                elif "mountain" in entities_set or "جبل" in raw or "peak" in raw:
                    # ─── Mountains ───────────────────────────────────────────
                    img = Image.new("RGB", (width, height), (20, 30, 50))
                    # سماء تدرج
                    for y in range(height // 2):
                        t = y / (height // 2)
                        draw.line((0, y, width, y), fill=(40 - int(20*t), 50 - int(25*t), 90 - int(40*t)))
                    # جبال متعددة
                    for _ in range(5):
                        x = random.randint(-100, width + 100)
                        h = random.randint(300, height - 100)
                        pts = [(x-180, height), (x, height - h), (x+180, height)]
                        gray = random.randint(60, 110)
                        draw.polygon(pts, fill=(gray, gray, gray))
                        # ثلج في القمة (اختياري)
                        if random.random() > 0.4:
                            snow_h = h * random.uniform(0.18, 0.35)
                            draw.polygon([
                                (x-80, height - h + snow_h),
                                (x, height - h),
                                (x+80, height - h + snow_h)
                            ], fill=(230, 230, 240))

                elif "ocean" in entities_set or "sea" in entities_set or "underwater" in entities_set or "بحر" in raw:
                    # ─── Ocean / Underwater ──────────────────────────────────
                    img = Image.new("RGB", (width, height), (0, 20, 60))
                    # تدرج مائي
                    for y in range(height):
                        t = y / height
                        b = int(60 + 140 * t)
                        g = int(20 + 60 * t)
                        draw.line((0, y, width, y), fill=(0, g, b))
                    # موجات سطحية
                    for _ in range(40):
                        x = random.randint(0, width)
                        y = random.randint(0, height // 4)
                        sz = random.randint(30, 120)
                        a = random.randint(30, 90)
                        draw.ellipse((x-sz, y-sz, x+sz, y+sz), outline=(200, 240, 255, a), width=2)

                elif "rain" in entities_set or "storm" in entities_set or "مطر" in raw:
                    # ─── Rain / Storm ────────────────────────────────────────
                    for _ in range(180):
                        x = random.randint(0, width)
                        y_start = random.randint(-200, height)
                        y_end = y_start + random.randint(40, 140) + frame * 8
                        thick = random.randint(1, 3)
                        draw.line((x, y_start % height, x, y_end % height), fill=(180, 190, 220, 160), width=thick)

                elif "forest" in entities_set or "غابة" in raw or "jungle" in raw:
                    # ─── Forest ──────────────────────────────────────────────
                    img = Image.new("RGB", (width, height), (10, 25, 15))
                    for _ in range(35):
                        x = random.randint(-60, width + 60)
                        h = random.randint(320, height - 60)
                        g = random.randint(50, 110)
                        draw.polygon([
                            (x-110, height), (x, height - h), (x+110, height)
                        ], fill=(20, g, 20))
                    # ضباب / fog خفيف
                    for _ in range(30):
                        x = random.randint(0, width)
                        y = random.randint(0, height // 2)
                        r = random.randint(140, 400)
                        draw.ellipse((x-r, y-r, x+r, y+r), fill=(220, 240, 220, 35))

                else:
                    # ─── Fallback عام (سماء داكنة + عناصر بسيطة) ───────────
                    for y in range(0, height, 160):
                        draw.line((0, y, width, y), fill=(50, 40, 90, 100), width=4)

                frames.append(img)

            # ─── حفظ الإطار/الصورة النهائية ────────────────────────────────
            ts = datetime.now().strftime("%Y%m%d_%H%M%S_%f")[:-3]
            suffix = "bg_layer" if transparent_bg else "env"
            ext = "gif" if is_video and len(frames) > 1 else "png"
            path = f"env_{suffix}_{ts}.{ext}"

            if is_video and len(frames) > 1:
                frames[0].save(path, save_all=True, append_images=frames[1:],
                            duration=140, loop=0, optimize=True)
            else:
                final = frames[0]
                if layer_opacity < 255:
                    if final.mode != "RGBA":
                        final = final.convert("RGBA")
                    alpha = Image.new("L", final.size, layer_opacity)
                    final.putalpha(alpha)
                final.save(path, quality=89, optimize=True)

            logger.info(f"[Environment] حفظ → {path}")
            return str(path)

        except Exception as e:
            logger.exception("فشل _create_simple_image")
            return None
        
# ────────────────────────────────────────────────
#              اختبار سريع (اختياري)
# ────────────────────────────────────────────────
if __name__ == "__main__":
    engine = environment_design_engine()   # ← هنا ما فيش حاجة لاستيراد إضافي

    engine.receive_input("cyberpunk cityscape with neon lights, flying cars, holographic billboards and towering skyscrapers")
    engine.add_task("main_cityscape", complexity=4.5)
    engine.add_task("neon_glow", complexity=3.2)
    engine.add_task("flying_vehicles", complexity=3.8, dependencies=["main_cityscape"])

    result = engine.generate_image(force_refresh=True)

    print("\nنتيجة environment:")
    print(f"نجاح: {result.success}")
    print(f"رسالة: {result.message}")
    print(f"الوقت الكلي: {result.total_time:.2f} ث")
    if result.output_data and "preview_path" in result.output_data:
        print(f"مسار المعاينة: {result.output_data['preview_path']}")