Overview: memory_manager.py 

contains the GenerativeMemoryManager class, an intelligent memory system specifically designed for image generation engines (such as Traditional/Geometric/Futuristic). Its primary purpose is to: protect the system from creepy content filtering; reduce unnecessary recalculations through intelligent refresh decisions; preserve session context memory to support incremental updates; and track performance and cleanup statistics.

Key Features in Detail:
Feature
Description
Main Benefit
1
Advanced multi-layered creepy filtering: - Detects creepy words (English + Arabic + spelling derivatives) - Severity levels - Cleans prompts, entities, and moods - Forced cleanup before saving and retrieving
Prevents unwanted content from reaching the render stage
2
Centralized and intelligent refresh decisions
The should_refresh_stages function decides which stage needs to be refreshed based on:
• Fast heuristic score
• Creepy detection
• Quality Entities and Planes
• force_refresh and maximum attempts
Reduces full recalculation → Improves performance and user experience in streaming
3
Recovers previous safe memory
If creepy_level is high → Attempts to recover a clean previous cache copy with additional cleanup
Protects against recurring issues and maintains session continuity
4
Merge old + new memory (refresh_memory)
- Merges while preserving the original order
- Safely removes duplicates (dict.fromkeys)
- Final cleanup after merging
Supports incremental refresh without loss of context or layer order
5
Simple caching + LRU support (currently partial)
- Saves based on prompt hash
- access_order for usage tracking
- Maximum size (max_cache_size)
Reduces execution time when reusing the same prompt or similar context
6
Supports external file for creepy words
- Loads creepy_keywords.json if available
- Fallback to an internal list if the file is missing
Easy maintenance and expansion (add new languages/words without modification) Code)
7
Accurate Statistics and Tracking
- filtered_count
- recovered_count
- cache_hits
- last_cleanup
Helps with monitoring, debugging, and long-term performance optimization
8
Multi-Stage Forced Cleanup
- _sanitize_task_data
Applied before saving, before merging, and before restoring
Ensures no creepy remnants are leaked, even if there was an error in a previous stage