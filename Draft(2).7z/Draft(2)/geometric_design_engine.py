# geometric_design_engine.py
"""
محرك التوليد الخاص بالتصاميم الهندسية
(أشكال، أنماط، تناظر، هياكل رياضية، تصاميم دقيقة ومتكررة...)
"""

import random
from unicodedata import name
import matplotlib.pyplot as plt
import numpy as np
from pathlib import Path
from datetime import datetime
from typing import Dict, Any, List, Optional
from Core_Image_Generation_Engine import CoreImageGenerationEngine, GenerationResult, perf_counter
import logging

from layer_engine import LayerEngine  # أو المسار الصحيح
from typing import Tuple  # لو مش موجود

from memory_manager import GenerativeMemoryManager

logger = logging.getLogger(__name__)


class geometric_design_engine(LayerEngine, CoreImageGenerationEngine):
    def __init__(self):
        super().__init__()

        # ─── الحالة الأساسية ────────────────────────────────
        self.input_port: List[str] = []
        self.tasks: List[Dict[str, Any]] = []
        self.render_time: Optional[float] = None
        self.last_task_data: Optional[Dict[str, Any]] = None

        # ─── التخصص (نسخة مستقلة) ─────────────────────────────
        from copy import deepcopy
        self.specialization = deepcopy(self._get_specialization_config())

        # ─── إدارة الذاكرة ──────────────────────────────────────
        self.memory_manager = GenerativeMemoryManager()

        # ─── تهيئة الـ units بشكل مركزي ومنظم ────────────────────
        units = self.specialization.setdefault("units", {})

        # الكلمات المشتركة مرة واحدة فقط
        common_keywords = [
            "shape", "structure", "design", "pattern",
            "form", "symmetry", "polygon", "grid", "fractal",
            "hex", "honeycomb", "hexagonal", "spiral", "golden"
        ]

        # المراحل اللي عايزين نضبطها
        stages = ["nlp", "integration", "post_processing", "rendering"]

        for stage in stages:
            unit = units.setdefault(stage, {})
            unit["refreshed"] = False
            unit["validate_keywords"] = common_keywords[:]  # نسخة مستقلة لكل واحد

        # ربط الدوال (لو موجودة في الكلاس)
        units["nlp"]["function"]          = self._analyze_prompt
        units["integration"]["function"]  = self._integrate_geometric
        units["post_processing"]["function"] = self._post_process_geometric
        units["rendering"]["function"]    = self._render_geometric

        # إضافات إضافية للتخصص (لو مش موجودة في _get_specialization_config)
        self.specialization.setdefault("description", "تصاميم هندسية، أشكال، تناظر، أنماط متكررة، هياكل رياضية")
        self.specialization.setdefault("name", "geometric_design")
        self.specialization.setdefault("rendering_style", "geometric")
          
    def add_task(self, task_name: str, complexity: float = 1.0, dependencies: Optional[List[str]] = None):
        if not hasattr(self, "tasks"):
            self.tasks = []
        self.tasks.append({"name": task_name, "complexity": complexity, "dependencies": dependencies or []})

    def get_tasks(self) -> List[Dict]:
        return getattr(self, "tasks", [])
    
    def validate_input(self, input_data: str) -> bool:
        lower = input_data.lower()
        keywords = self.specialization.get("validate_keywords", [])
        if not keywords:
            logger.debug("validate_keywords غير موجودة بعد → قبول مؤقتاً")
            return True
        matched = any(kw in lower for kw in keywords)
        if not matched:
            logger.warning(f"لم يُطابق أي كلمة مفتاحية في: {lower[:60]}...")
        return matched

    def receive_input(self, prompt: str) -> bool:
        """
        تلقي prompt جديد مع التحقق الأساسي + validate للتخصص (اختياري)
        """
        if not isinstance(prompt, str) or not prompt.strip():
            logger.warning("Prompt غير صالح أو فارغ")
            return False

        stripped = prompt.strip()

        # استدعاء الـ super لو موجود (للتوافق مع CoreImageGenerationEngine)
        if hasattr(super(), 'receive_input'):
            if not super().receive_input(stripped):
                return False

        # validate للتخصص (اختياري – لو عايز تفعّله في كل engine)
        if hasattr(self, 'specialization') and "validate_keywords" in self.specialization.get("units", {}).get("nlp", {}):
            keywords = self.specialization["units"]["nlp"]["validate_keywords"]
            if not any(kw.lower() in stripped.lower() for kw in keywords):
                logger.warning(f"الإدخال لا يطابق كلمات التخصص → رفض")
                return False

        # إضافة الـ prompt بعد التحقق
        self.append_prompt_chunk(stripped)
        logger.info(f"[{self.specialization.get('name', 'unknown')}] received: {stripped[:60]}...")
        return True

    def generate_layer(
        self,
        prompt: str,
        target_size: Tuple[int, int] = (1024, 1024),
        is_video: bool = False,
        as_layer: bool = True,
        force_refresh: bool = False,
        **kwargs
    ) -> GenerationResult:
        """الواجهة الجديدة المفضلة – prompt مباشر بدون input_port"""
        logger.info(f"[Core Layer] generate_layer called with direct prompt: {prompt[:70]}...")
        return self._run_generation(
            prompt=prompt,
            target_size=target_size,
            is_video=is_video,
            as_layer=as_layer,
            force_refresh=force_refresh,
            **kwargs
        )

    def generate_image(
        self,
        force_refresh: bool = False,
        as_layer: bool = True,
        target_size: Tuple[int, int] = (1024, 1024),
        reset_input_after: bool = True,
        is_video: bool = False,
        **kwargs
    ) -> GenerationResult:
        """الواجهة القديمة للتوافق – تجمع من input_port"""
        if not self.input_port:
            return GenerationResult(
                success=False,
                message="لا يوجد prompt في input_port",
                total_time=0.0,
                stage_times={},
                specialization=self.specialization.get("name", "unknown")
            )

        full_prompt = " ".join(self.input_port).strip()
        logger.info(f"[Core Image] generate_image called – collected prompt: {full_prompt[:70]}...")

        result = self._run_generation(
            prompt=full_prompt,
            target_size=target_size,
            is_video=is_video,
            as_layer=as_layer,
            force_refresh=force_refresh,
            **kwargs
        )

        if reset_input_after:
            self.input_port.clear()

        return result

    def _get_specialization_config(self) -> Dict[str, Any]:
        return {
            "name": "geometric_design",
            "rendering_style": "geometric",
            "description": "تصاميم هندسية، أشكال، تناظر، أنماط متكررة، هياكل رياضية",
            "validate_keywords": [
                "shape", "structure", "design", "pattern",
                "form", "symmetry", "polygon", "grid", "fractal",
                "hex", "honeycomb", "hexagonal", "spiral", "golden"
            ],
            "units": {
                "nlp": {"function": self._analyze_prompt, "refreshed": False},
                "integration": {"function": self._integrate_geometric, "refreshed": False},
                "post_processing": {"function": self._post_process_geometric, "refreshed": False},
                "rendering": {"function": self._render_geometric, "refreshed": False},
            }
        }

    def validate_input(self, input_data: str) -> bool:
        lower = input_data.lower().strip()
        keywords = self.specialization.get("validate_keywords", [])

        # حماية: إذا لم تكن الكلمات جاهزة بعد → نقبل مؤقتاً
        if not keywords:
            logger.debug("validate_keywords غير جاهزة بعد → قبول مؤقت")
            return True

        matched = any(kw.lower() in lower for kw in keywords)

        if not matched:
            logger.info(f"لم يُطابق أي كلمة مفتاحية (من {len(keywords)} كلمة)")

        return matched

    def _render_geometric(self, task_data: Dict, is_video: bool = False) -> float:
        """
        مرحلة الـ rendering للتصاميم الهندسية
        (عادة أسرع لأنها تعتمد على حسابات دقيقة ومتكررة)
        """
        complexity = sum(t.get("complexity", 0.0) for t in self.tasks)
        base_time = complexity * 0.9

        if is_video:
            base_time *= 2.5  # تكلفة أقل نسبياً بسبب التكرار

        symmetry = task_data.get("symmetry_level", "medium")
        mode = "فيديو" if is_video else "صورة"

        logger.info(
            f"[Geometric Render] تعقيد: {complexity:.1f} | "
            f"وقت تقريبي: {base_time:.1f}s | {mode} | تناظر: {symmetry}"
        )

        return base_time

    def _integrate_geometric(self, task_data: Dict) -> Dict:
        """
        تكامل طبقات التصميم الهندسي بناءً على المهام الموجودة في self.tasks
        (التي تم توليدها تلقائيًا بواسطة _post_analyze_add_tasks)
        """
        logger.info("===== بدء _integrate_geometric =====")
        logger.debug(f"عدد المهام الحالية: {len(self.tasks)}")

        planes = []
        interactions = []

        total_complexity = sum(t.get("complexity", 0) for t in self.tasks)

        # ─── خريطة خصائص أساسية للمهام الهندسية (يمكن توسيعها) ────────────────
        base_plane_props = {
            "base shape":      {"z": 0.5, "color": "#ffffff", "force": 0.70, "mass": 1.8},
            "circle":          {"z": 0.4, "color": "#88ccff", "force": 0.65, "mass": 1.5},
            "polygon":         {"z": 0.5, "color": "#ff88cc", "force": 0.75, "mass": 1.9},
            "triangle":        {"z": 0.45, "color": "#ffff88", "force": 0.60, "mass": 1.6},
            "square":          {"z": 0.5, "color": "#88ff88", "force": 0.68, "mass": 1.7},
            "hexagon":         {"z": 0.5, "color": "#cc88ff", "force": 0.72, "mass": 1.8},

            "grid pattern":    {"z": 0.6, "color": "#4444ff", "force": 0.55, "mass": 1.4},
            "tile pattern":    {"z": 0.55, "color": "#ff4444", "force": 0.58, "mass": 1.5},
            "honeycomb":       {"z": 0.5, "color": "#ffcc88", "force": 0.62, "mass": 1.6},

            "mirror axis":     {"z": 0.5, "color": "#aaaaaa", "force": 0.80, "mass": 1.3},
            "radial symmetry": {"z": 0.5, "color": "#ffaa00", "force": 0.85, "mass": 1.4},
            "spiral curve":    {"z": 0.4, "color": "#ffd700", "force": 0.75, "mass": 1.5},
            "golden spiral":   {"z": 0.4, "color": "#d4a017", "force": 0.78, "mass": 1.6},

            "metallic shader": {"z": 0.6, "color": "#b0c4de", "force": 0.70, "mass": 1.7},
            "glow effect":     {"z": 0.7, "color": "#ffffff", "force": 0.90, "mass": 1.2},
            "wireframe":       {"z": 0.65, "color": "#00ffcc", "force": 0.60, "mass": 1.3},
        }

        # ─── 1. إنشاء طبقات من المهام الموجودة ───────────────────────────────────
        for task in self.tasks:
            name_lower = task["name"].lower()
            config = base_plane_props.get(name_lower)

            if config:
                plane = {
                    "label": task["name"],
                    "z": config["z"],
                    "color": config["color"],
                    "force": config["force"],
                    "mass": config["mass"],
                    "complexity": task.get("complexity", 2.5),
                }
            else:
                # fallback عام لأي مهمة غير معروفة
                plane = {
                    "label": task["name"],
                    "z": 0.5 + random.uniform(-0.15, 0.15),
                    "color": "#9999ff",
                    "force": 0.65,
                    "mass": 1.6,
                    "complexity": task.get("complexity", 2.5),
                }

            planes.append(plane)
            logger.debug(f"أُضيفت طبقة هندسية: {plane['label']} (z={plane['z']:.2f})")

        # ─── 2. تفاعلات بسيطة (اختياري حاليًا) ───────────────────────────────────
        if len(planes) >= 2:
            for i in range(len(planes)):
                for j in range(i + 1, len(planes)):
                    strength = 0.25 + (planes[i]["force"] * planes[j]["force"]) * 0.15
                    interactions.append({
                        "from": planes[i]["label"],
                        "to": planes[j]["label"],
                        "strength": round(strength, 2)
                    })

        # ─── 3. تحديث task_data ────────────────────────────────────────────────────
        task_data["planes"] = planes
        task_data["plane_interactions"] = interactions
        task_data["integration_summary"] = {
            "layers_count": len(planes),
            "interactions_count": len(interactions),
            "total_complexity": total_complexity,
            "avg_force": round(sum(p["force"] for p in planes) / len(planes), 2) if planes else 0.0
        }

        est_time = 0.35 + len(planes)*0.09 + len(interactions)*0.03 + total_complexity*0.18
        task_data["integration_time"] = round(est_time, 2)

        logger.info(
            f"[Geometric Integrate] → {len(planes)} طبقة | {len(interactions)} تفاعل | "
            f"تعقيد: {total_complexity:.1f} | وقت تقريبي: {est_time:.2f} ث"
        )

        return task_data

    def _post_process_geometric(self, task_data: Dict) -> float:
        """
        التحسين النهائي (sharpen, clean lines, gradient optimization, minimal noise...)
        """
        complexity = sum(t.get("complexity", 0.0) for t in self.tasks)
        base_time = complexity * 0.4

        if task_data.get("symmetry_level") == "high":
            base_time += complexity * 0.05

        if self.specialization["units"].get("post_processing", {}).get("refreshed", False):
            base_time *= 1.05

        logger.info(
            f"[Geometric Post-process] وقت تقريبي: {base_time:.1f}s - "
            f"تناظر عالي: {task_data.get('symmetry_level') == 'high'}"
        )

        return base_time

    def _post_analyze_add_tasks(self, task_data: dict) -> None:
        """
        تحويل الكيانات المستخرجة والمستوى التناظري إلى مهام تصميم هندسي فرعية
        مع تعقيد تقريبي واعتماديات بسيطة.
        """
        logger.info("===== بدء _post_analyze_add_tasks (Geometric) =====")
        logger.debug(f"Entities: {task_data.get('entities', [])} | Symmetry: {task_data.get('symmetry_level', 'medium')}")

        # ─── خريطة تعقيد المهام الهندسية الأساسية ───────────────────────────────
        geo_task_complexity = {
            # أساسيات الشكل
            "base_shape":       2.4,
            "circle":           2.0,
            "polygon":          2.6,
            "triangle":         2.3,
            "square":           2.2,
            "hexagon":          2.8,

            # أنماط وتكرار
            "grid_pattern":     3.0,
            "tile_pattern":     3.2,
            "honeycomb":        3.4,
            "fractal":          4.1,

            # تناظر وحركة
            "mirror_axis":      2.7,
            "radial_symmetry":  3.1,
            "spiral_curve":     3.3,
            "golden_spiral":    3.5,

            # مواد وتأثيرات سطحية
            "metallic_shader":  3.2,
            "glass_shader":     3.0,
            "glow_effect":      2.8,
            "wireframe":        2.5,
        }

        added_count = 0
        added_tasks = []

        entities = [e.lower() for e in task_data.get("entities", [])]
        symmetry = task_data.get("symmetry_level", "medium")

        if not entities:
            logger.info("لا توجد entities هندسية → لن تُضاف مهام تلقائية")
            return

        # ─── 1. مهمة رئيسية (أول شكل أو نمط يتم العثور عليه) ─────────────────────
        main_geo = None
        for e in entities:
            if e in geo_task_complexity:
                main_geo = e
                break
            for key in geo_task_complexity:
                if key in e or e in key:
                    main_geo = key
                    break
            if main_geo:
                break

        if not main_geo:
            main_geo = "base_shape"  # fallback آمن

        complexity = geo_task_complexity.get(main_geo, 2.8)

        # تعديل حسب مستوى التناظر
        if symmetry == "high":
            complexity *= 1.18
        elif symmetry == "low":
            complexity *= 0.92

        if not any(t["name"].lower() == main_geo for t in self.tasks):
            self.add_task(
                task_name=main_geo.capitalize().replace("_", " "),
                complexity=round(complexity, 1),
                dependencies=[]
            )
            added_count += 1
            added_tasks.append(main_geo.capitalize().replace("_", " "))

        # ─── 2. مهام فرعية تلقائية حسب الكيانات والتناظر ────────────────────────
        sub_tasks = ["base_shape"]  # دائمًا موجود كأساس

        if symmetry in ["high", "medium"]:
            sub_tasks.extend(["mirror_axis", "radial_symmetry"])

        if "pattern" in entities or "grid" in entities or "tile" in entities:
            sub_tasks.extend(["grid_pattern", "tile_pattern"])

        if "spiral" in entities or "golden" in task_data.get("raw_prompt", "").lower():
            sub_tasks.append("spiral_curve")
            if "golden" in task_data.get("raw_prompt", "").lower():
                sub_tasks.append("golden_spiral")

        if "hex" in entities or "honeycomb" in entities or "hexagonal" in entities:
            sub_tasks.append("honeycomb")

        if "metallic" in task_data.get("raw_prompt", "").lower() or "shader" in entities:
            sub_tasks.append("metallic_shader")

        if "fractal" in entities:
            sub_tasks.append("fractal")

        # ─── 3. إضافة المهام الفرعية (مع تجنب التكرار) ───────────────────────────
        for sub in sub_tasks:
            sub_lower = sub.lower()
            if not any(t["name"].lower() == sub_lower for t in self.tasks):
                comp = geo_task_complexity.get(sub_lower, 2.6)

                # زيادة طفيفة إذا كان تناظر عالي
                if symmetry == "high":
                    comp *= 1.10

                self.add_task(
                    task_name=sub.capitalize().replace("_", " "),
                    complexity=round(comp, 1),
                    dependencies=[main_geo.capitalize().replace("_", " ")] if main_geo else []
                )
                added_count += 1
                added_tasks.append(sub.capitalize().replace("_", " "))

        # ─── تسجيل النتيجة ────────────────────────────────────────────────────────
        if added_count > 0:
            logger.info(f"تم إضافة {added_count} مهمة هندسية تلقائيًا: {added_tasks}")
        else:
            logger.info("لم تُضف مهام هندسية جديدة")
        
    def generate_image(
        self,
        force_refresh: bool = False,
        as_layer: bool = True,
        target_size: tuple = (1024, 1024),
        reset_input_after: bool = True,
        is_video: bool = False,
        **kwargs
    ) -> GenerationResult:
        start_total = perf_counter()
        stage_times = {}

        try:
            if not self.input_port:
                return GenerationResult(
                    success=False,
                    message="لا يوجد prompt في المنفذ",
                    total_time=0.0,
                    stage_times={},
                    specialization=self.specialization["name"],
                    output_data={}
                )

            full_prompt = " ".join(self.input_port).strip()
            logger.info(f"[{self.specialization['name']} generate_image] prompt: {full_prompt[:70]}... | as_layer={as_layer} | video={is_video}")

            # ─── 1. تحليل الـ prompt (هنا بيتم تعريف task_data) ──────────────────────
            t_analyze = perf_counter()
            if force_refresh or not hasattr(self, 'last_task_data'):
                task_data = self._analyze_prompt(full_prompt)
                self._post_analyze_add_tasks(task_data)  # ← مهم: المهام التلقائية
                self.last_task_data = task_data
            else:
                task_data = self.last_task_data
            stage_times["analyze"] = perf_counter() - t_analyze

            # ─── 2. تنظيف و refresh باستخدام memory_manager (بعد تعريف task_data) ─────
            if self.memory_manager.check_for_creepy(full_prompt, task_data):
                recovered = self.memory_manager.auto_recovery_on_creepy(full_prompt, self.specialization["name"])
                if recovered:
                    task_data = recovered
                task_data = self.memory_manager.refresh_memory(full_prompt, task_data, self.specialization["name"])
                logger.info(f"[{self.specialization['name']}] تم refresh الذاكرة بسبب creepy detection")

            # ─── 3. Rendering ────────────────────────────────────────────────────────────
            t_render = perf_counter()
            render_time, preview_path = self._render(task_data, is_video=is_video)
            stage_times["render"] = render_time

            if not preview_path:
                raise RuntimeError("فشل إنشاء طبقة")

            total_time = perf_counter() - start_total

            result = GenerationResult(
                success=True,
                message=f"تم إنشاء طبقة بنجاح ({self.specialization['name']})" + (" - فيديو GIF" if is_video else ""),
                total_time=total_time,
                stage_times=stage_times,
                specialization=self.specialization["name"],
                output_data={
                    "preview_path": str(Path(preview_path).absolute()),
                    "layer_type": "background" if "environment" in self.specialization["name"] else "midground" if "geometric" in self.specialization["name"] else "foreground",
                    "is_transparent": True,
                    "is_video": is_video,
                    "prompt_used": full_prompt
                }
            )

            logger.info(f"[{self.specialization['name']}] نجح → {preview_path} | وقت كلي: {total_time:.2f} ث")

            if reset_input_after:
                self.input_port.clear()

            return result

        except Exception as e:
            logger.exception(f"[{self.specialization['name']} generate_image] فشل")
            total_time = perf_counter() - start_total
            return GenerationResult(
                success=False,
                message=f"فشل توليد طبقة: {str(e)}",
                total_time=total_time,
                stage_times=stage_times,
                specialization=self.specialization["name"],
                output_data={}
            )
        
    def _save_preview(self, specialization: str, task_data: dict, is_video: bool = False) -> str:
        import matplotlib.pyplot as plt
        import numpy as np
        from pathlib import Path

        output_path = Path(f"{specialization}_output.{'gif' if is_video else 'png'}")

        try:
            fig, ax = plt.subplots(figsize=(8, 6))
            ax.set_facecolor('#0a0a1f')
            ax.text(0.5, 0.5, 
                    f"{specialization.upper()}\nPrompt: {task_data.get('raw_prompt', 'N/A')}\nTime: {self.render_time:.1f}s",
                    ha='center', va='center', fontsize=14, color='white')
            ax.axis('off')

            if specialization == "traditional_design":
                ax.add_patch(plt.Circle((0.5, 0.6), 0.2, color='sienna', alpha=0.7))   # creature placeholder
                ax.add_patch(plt.Rectangle((0, 0), 1, 0.4, color='darkgreen', alpha=0.6))  # nature ground

            plt.savefig(output_path, dpi=120, bbox_inches='tight', facecolor=fig.get_facecolor())
            plt.close(fig)
            logging.info(f"Image saved as {output_path}")
            return str(output_path)
        except Exception as e:
            logging.error(f"Failed to save preview: {e}")
            return "failed_to_generate_preview"

    def check_improvement_needed(self, specialization: str, stage: str) -> bool:
        spec = self.specializations[specialization]
        tasks = spec["tasks"]
        if not tasks:
                return False
        total_complexity = sum(t["complexity"] for t in tasks)
        return len(tasks) > 1 or total_complexity > 6.0

    def append_prompt_chunk(self, chunk: str):
        """إضافة جزء من الـ prompt للمنفذ"""
        self.input_port.append(chunk.strip())
        logger.debug(f"[Geometric] appended chunk: {chunk[:50]}...")
# ────────────────────────────────────────────────
#              تنفيذ اختياري للـ preview
# ────────────────────────────────────────────────

    def _analyze_prompt(self, prompt: str) -> Dict[str, Any]:
        logger.info(f"[Geometric] تحليل الـ prompt: {prompt[:80]}{'...' if len(prompt)>80 else ''}")

        lower_prompt = prompt.lower()
        words = set(lower_prompt.split())

        entities = []
        if any(w in words for w in ["shape", "polygon", "circle", "square", "triangle"]):
            entities.append("shape")
        if any(w in words for w in ["pattern", "repeat", "tile", "grid"]):
            entities.append("pattern")
        if "symmetry" in words or "symmetrical" in words or "mirror" in words:
            entities.append("symmetry")
        if any(w in words for w in ["structure", "form", "architecture", "fractal"]):
            entities.append("structure")

        symmetry_level = "high" if "symmetry" in entities else "medium" if "pattern" in entities else "low"

        return {
            "entities": entities,
            "style": "geometric",
            "symmetry_level": symmetry_level,
            "main_element": entities[0] if entities else "abstract_form",
            "raw_prompt": prompt
        }

    def _integrate(self, task_data: Dict) -> Dict:
        """
        تكامل بسيط للمهام الهندسية (placeholder)
        """
        task_data.setdefault("planes", [])
        task_data.setdefault("summary", {"layers_count": len(self.tasks)})
        return task_data
 
    def _post_process(self, task_data: Dict) -> Dict[str, Any]:
        entities_count = len(task_data.get("entities", []))
        symmetry_bonus = 0.3 if task_data.get('symmetry_level') == 'high' else 0.0
        duration = 0.4 + entities_count * 0.15 + symmetry_bonus

        logger.info(
            f"[Geometric Post-process] وقت تقريبي: {duration:.1f}s - "
            f"تناظر عالي: {task_data.get('symmetry_level') == 'high'}"
        )

        return {
            "success": True,
            "duration_seconds": duration,
            "summary": f"Geometric post-processing complete | entities: {entities_count}",
            "warnings": [],
            "metadata": {
                "symmetry_level": task_data.get("symmetry_level", "medium")
            }
        }
    
    def _render(self, task_data: Dict, is_video: bool = False) -> tuple[float, Optional[str]]:
        """
        مرحلة الـ rendering الرئيسية لمحرك التصاميم الهندسية.
        تنتج طبقة midground (أشكال، أنماط، هياكل) وليس صورة نهائية كاملة.
        
        Returns:
            tuple[float, Optional[str]]: 
                - الوقت الفعلي للعملية (ثواني)
                - مسار الطبقة المُنشأة (أو None إذا فشل)
        """
        t_start = perf_counter()
        preview_path = None

        try:
            logger.debug("[Geometric Render] بدء توليد طبقة هندسية...")

            # دعم بسيط للفيديو (يمكن توسيعه لاحقًا)
            if is_video:
                logger.info("[Geometric Render] طلب فيديو → GIF بسيط (دوران/نبض)")
            else:
                logger.debug("[Geometric Render] صورة ثابتة")

            preview_path = self._create_simple_image(
                task_data=task_data,
                is_video=is_video,
                transparent_bg=True,           # mid-layer غالبًا شفاف
                target_size=(1024, 1024),
                layer_opacity=245              # شبه شفافة قليلاً للدمج الجميل
            )

            if preview_path and Path(preview_path).exists():
                suffix = "GIF" if is_video else "PNG"
                logger.info(f"[Geometric Render] تم إنشاء طبقة {suffix} بنجاح → {preview_path}")
            else:
                logger.warning("[Geometric Render] فشل إنشاء مسار طبقة صالح")

        except Exception as e:
            logger.exception("[Geometric Render] خطأ أثناء توليد الطبقة الهندسية")
            preview_path = None

        render_time = perf_counter() - t_start

        # تسجيل واضح
        mode = "فيديو (GIF)" if is_video else "طبقة هندسية ثابتة"
        time_str = f"{render_time:.3f} ث" if render_time >= 0.02 else f"{render_time:.4f} ث (سريع)"
        path_str = preview_path or "فشل"
        logger.info(f"[Geometric Render] {mode} | وقت: {time_str} | مسار: {path_str}")

        return render_time, preview_path

    def _create_simple_image(
        self,
        task_data: Dict,
        is_video: bool = False,
        transparent_bg: bool = False,
        target_size: tuple = (1024, 1024),
        layer_opacity: int = 255
    ) -> Optional[str]:
        try:
            from PIL import Image, ImageDraw
            import math
            import random
            from pathlib import Path
            from datetime import datetime

            width, height = target_size
            frames = []
            n_frames = 12 if is_video else 1

            entities = set(str(e).lower() for e in task_data.get("entities", []))
            symmetry = task_data.get("symmetry_level", "medium")
            prompt_lower = task_data.get("raw_prompt", "").lower()

            for f in range(n_frames):
                if transparent_bg:
                    img = Image.new("RGBA", (width, height), (0, 0, 0, 0))
                else:
                    img = Image.new("RGB", (width, height), (12, 10, 25))

                draw = ImageDraw.Draw(img)

                center_x, center_y = width // 2, height // 2

                # ─── 1. أنماط هندسية / شبكة / تناظر ────────────────────────────────
                if "pattern" in entities or "grid" in entities or "symmetry" in entities:
                    step = 60 if symmetry == "high" else 90
                    for x in range(0, width, step):
                        draw.line((x, 0, x, height), fill=(80, 120, 200, 120), width=1)
                    for y in range(0, height, step):
                        draw.line((0, y, width, y), fill=(80, 120, 200, 120), width=1)

                # ─── 2. دوامة ذهبية / spiral (شائعة في sacred geometry) ────────────
                if "spiral" in entities or "golden" in prompt_lower:
                    golden = (1 + math.sqrt(5)) / 2
                    theta = np.linspace(0, 10 * math.pi, 400)
                    r = 0.08 * np.exp(theta / golden)
                    angle_offset = f * 0.4 if is_video else 0
                    x = r * np.cos(theta + angle_offset) + center_x
                    y = r * np.sin(theta + angle_offset) + center_y
                    for i in range(len(x)-1):
                        draw.line((x[i], y[i], x[i+1], y[i+1]), fill=(255, 215, 0), width=2)

                # ─── 3. شكل سيارة بسيط / هيكل ميكانيكي (placeholder) ───────────────
                if "car" in prompt_lower or "vehicle" in entities or "سيارة" in prompt_lower:
                    # جسم السيارة
                    draw.rectangle((center_x-180, center_y+20, center_x+180, center_y+120), fill=(60, 70, 90))
                    # سقف/زجاج
                    draw.polygon([
                        (center_x-140, center_y+20),
                        (center_x+140, center_y+20),
                        (center_x+100, center_y-30),
                        (center_x-100, center_y-30)
                    ], fill=(40, 50, 70))
                    # عجلات
                    for dx in [-120, 120]:
                        draw.ellipse((center_x+dx-50, center_y+80, center_x+dx+50, center_y+180), fill=(20, 20, 30))
                        draw.ellipse((center_x+dx-30, center_y+100, center_x+dx+30, center_y+160), fill=(100, 100, 120))

                # ─── 4. تناظر عالي (mirrored effect) ────────────────────────────────
                if symmetry == "high":
                    # مرآة رأسية بسيطة
                    draw.line((center_x, 0, center_x, height), fill=(200, 180, 255, 80), width=3)

                # ─── جسيمات/نقاط لامعة للإحساس بالدقة الهندسية ───────────────────
                for _ in range(40):
                    x = random.randint(0, width)
                    y = random.randint(0, height)
                    sz = random.uniform(1.5, 4)
                    draw.ellipse((x-sz, y-sz, x+sz, y+sz), fill=(220, 240, 255, 140))

                frames.append(img)

            # ─── حفظ ────────────────────────────────────────────────────────────────
            ts = datetime.now().strftime("%Y%m%d_%H%M%S_%f")[:-3]
            suffix = "mid_layer" if transparent_bg else "geometric"
            path = f"geometric_{suffix}_{ts}.{'gif' if is_video else 'png'}"

            if is_video and len(frames) > 1:
                frames[0].save(path, save_all=True, append_images=frames[1:], duration=120, loop=0)
            else:
                final = frames[0]
                if layer_opacity < 255:
                    if final.mode != "RGBA":
                        final = final.convert("RGBA")
                    alpha = Image.new("L", final.size, layer_opacity)
                    final.putalpha(alpha)
                final.save(path, quality=90)

            logger.info(f"[Geometric] حفظ → {path}")
            return str(path)

        except Exception as e:
            logger.exception("[Geometric _create_simple_image] فشل")
            return None
    
# ────────────────────────────────────────────────
#              اختبار سريع (اختياري)
# ────────────────────────────────────────────────
if __name__ == "__main__":
    eng = geometric_design_engine()
    eng.receive_input("golden spiral sacred geometry metallic gold")
    res = eng.generate_image(as_layer=False)
    print(res)
    engine = geometric_design_engine()

    engine.receive_input("symmetrical hexagonal pattern with golden ratio spiral and mirrored grid structure")
    engine.add_task("base_hexagon", complexity=2.8)
    engine.add_task("spiral_overlay", complexity=3.2, dependencies=["base_hexagon"])
    engine.add_task("mirror_symmetry", complexity=2.5, dependencies=["base_hexagon"])

    result: GenerationResult = engine.generate_image(force_refresh=True)

    print("\nنتيجة التوليد:")
    print(f"نجاح: {result.success}")
    print(f"رسالة: {result.message}")
    print(f"الوقت الكلي: {result.total_time:.2f} ث")
    print(f"أوقات المراحل: {result.stage_times}")
    print(f"التخصص: {result.specialization}")
    print(f"بيانات الإخراج: {result.output_data}")
    print(f"المهام النهائية: {engine.get_tasks()}")
    print(f"البيانات النهائية للمهام: {engine.last_task_data}")