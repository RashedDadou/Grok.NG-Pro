# في traditional_design_engine.py

from typing import Dict, Any, Optional, List
from datetime import datetime
from PIL import Image, ImageDraw
import random
import logging
import math
from pathlib import Path
from time import perf_counter
from PIL import Image, ImageDraw, ImageFont

from layer_engine import LayerEngine  # أو المسار الصحيح
from typing import Tuple  # لو مش موجود

# الاستيراد الوحيد المهم (من الكور)
from Core_Image_Generation_Engine import CoreImageGenerationEngine
from memory_manager import GenerativeMemoryManager
from Image_generation import GenerationResult

print("تم تحميل traditional_design_engine.py")

logger = logging.getLogger(__name__)

from typing import List, Dict, Any, Optional
from copy import deepcopy

class traditional_design_engine(LayerEngine, CoreImageGenerationEngine):
    def __init__(self):
        super().__init__()

        # ─── الحالة الأساسية ────────────────────────────────
        self.input_port: List[str] = []
        self.tasks: List[Dict[str, Any]] = []
        self.render_time: Optional[float] = None
        self.last_task_data: Optional[Dict[str, Any]] = None

        # ─── التخصص (نسخة مستقلة) ─────────────────────────────
        from copy import deepcopy
        self.specialization = deepcopy(self._get_specialization_config())

        # ─── إدارة الذاكرة ──────────────────────────────────────
        self.memory_manager = GenerativeMemoryManager()

        # ─── تهيئة الـ units بشكل مركزي ومنظم ────────────────────
        units = self.specialization.setdefault("units", {})

        # الكلمات المشتركة مرة واحدة فقط
        common_keywords = [
            "creature", "animal", "monster", "beast", "character", "person", "human",
            "girl", "boy", "woman", "man", "child", "baby",
            "horse", "dragon", "lion", "wolf", "cat", "dog", "bird", "fish",
            "angel", "demon", "fairy", "elf", "orc", "goblin",
            "فتاة", "ولد", "امرأة", "رجل", "طفل", "حصان", "تنين"
        ]

        # المراحل
        stages = ["nlp", "integration", "post_processing", "rendering"]

        for stage in stages:
            unit = units.setdefault(stage, {})
            unit["refreshed"] = False
            unit["validate_keywords"] = common_keywords[:]  # نسخة مستقلة

        # ربط الدوال (غيّر الأسماء حسب اللي عندك)
        units["nlp"]["function"]          = self._analyze_prompt
        units["integration"]["function"]  = self._integrate_traditional
        units["post_processing"]["function"] = self._post_process_traditional
        units["rendering"]["function"]    = self._render

        # إضافات إضافية للتخصص
        self.specialization.setdefault("description", "تصاميم تقليدية عضوية، كائنات حية، شخصيات، حيوانات، مخلوقات أسطورية، تفاصيل تشريحية وعاطفية")
        self.specialization.setdefault("name", "traditional_design")
        self.specialization.setdefault("rendering_style", "organic")

    def receive_input(self, prompt: str) -> bool:
        """
        تلقي prompt جديد مع التحقق الأساسي + validate للتخصص (اختياري)
        """
        if not isinstance(prompt, str) or not prompt.strip():
            logger.warning("Prompt غير صالح أو فارغ")
            return False

        stripped = prompt.strip()

        # استدعاء الـ super لو موجود (للتوافق مع CoreImageGenerationEngine)
        if hasattr(super(), 'receive_input'):
            if not super().receive_input(stripped):
                return False

        # validate للتخصص (اختياري – لو عايز تفعّله في كل engine)
        if hasattr(self, 'specialization') and "validate_keywords" in self.specialization.get("units", {}).get("nlp", {}):
            keywords = self.specialization["units"]["nlp"]["validate_keywords"]
            if not any(kw.lower() in stripped.lower() for kw in keywords):
                logger.warning(f"الإدخال لا يطابق كلمات التخصص → رفض")
                return False

        # إضافة الـ prompt بعد التحقق
        self.append_prompt_chunk(stripped)
        logger.info(f"[{self.specialization.get('name', 'unknown')}] received: {stripped[:60]}...")
        return True

    def generate_layer(
        self,
        prompt: str,
        target_size: Tuple[int, int] = (1024, 1024),
        is_video: bool = False,
        as_layer: bool = True,
        force_refresh: bool = False,
        **kwargs
    ) -> GenerationResult:
        """الواجهة الجديدة المفضلة – prompt مباشر بدون input_port"""
        logger.info(f"[Core Layer] generate_layer called with direct prompt: {prompt[:70]}...")
        return self._run_generation(
            prompt=prompt,
            target_size=target_size,
            is_video=is_video,
            as_layer=as_layer,
            force_refresh=force_refresh,
            **kwargs
        )

    def generate_image(
        self,
        force_refresh: bool = False,
        as_layer: bool = True,
        target_size: Tuple[int, int] = (1024, 1024),
        reset_input_after: bool = True,
        is_video: bool = False,
        **kwargs
    ) -> GenerationResult:
        """الواجهة القديمة للتوافق – تجمع من input_port"""
        if not self.input_port:
            return GenerationResult(
                success=False,
                message="لا يوجد prompt في input_port",
                total_time=0.0,
                stage_times={},
                specialization=self.specialization.get("name", "unknown")
            )

        full_prompt = " ".join(self.input_port).strip()
        logger.info(f"[Core Image] generate_image called – collected prompt: {full_prompt[:70]}...")

        result = self._run_generation(
            prompt=full_prompt,
            target_size=target_size,
            is_video=is_video,
            as_layer=as_layer,
            force_refresh=force_refresh,
            **kwargs
        )

        if reset_input_after:
            self.input_port.clear()

        return result

    def append_prompt_chunk(self, chunk: str):
        self.input_port.append(chunk)

    def add_task(self, task_name: str, complexity: float = 1.0, dependencies: Optional[List[str]] = None):
        if not hasattr(self, "tasks"):
            self.tasks = []
        self.tasks.append({"name": task_name, "complexity": complexity, "dependencies": dependencies or []})
        
    def get_tasks(self) -> List[Dict]:
        return getattr(self, "tasks", [])
  
    def generate_image(
        self,
        force_refresh: bool = False,
        as_layer: bool = True,           # افتراضي True لأن هذا المحرك ينتج طبقات
        target_size: tuple = (1024, 1024),
        reset_input_after: bool = True,
        **kwargs
    ) -> GenerationResult:
        """
        الواجهة الرئيسية لتوليد طبقة الكائن الحي (foreground layer).
        
        Returns:
            GenerationResult مع مسار الطبقة في output_data["preview_path"]
            → لا ينتج صورة كاملة، بل طبقة شفافة للدمج في Final_Generation.py
        """
        start = perf_counter()
        stage_times = {}

        try:
            if not self.input_port:
                return GenerationResult(
                    success=False,
                    message="لا يوجد prompt في المنفذ",
                    total_time=0.0,
                    stage_times={},
                    specialization="traditional_design",
                    output_data={}
                )

            full_prompt = " ".join(self.input_port).strip()
            logger.info(f"[Traditional generate_image] بدء مع prompt: {full_prompt[:80]}...")

            if not self.validate_input(full_prompt):
                logger.warning("الـ prompt غير مناسب للتصميم التقليدي → محاولة توليد طبقة عامة")
                # يمكن تعديل هذا السلوك لاحقًا (مثلاً: إضافة مهام تلقائية أو تعديل الـ prompt)
                # حالياً سنحاول توليد طبقة عامة حتى لو كان الـ prompt غير مثالي
    
            # ─── 1. تحليل الـ prompt (إذا لم يتم من قبل) ──────────────────────
            t_analyze = perf_counter()
            if not hasattr(self, 'last_task_data') or force_refresh:
                task_data = self._analyze_prompt(full_prompt)
                self.last_task_data = task_data
            else:
                task_data = self.last_task_data
            stage_times["analyze"] = perf_counter() - t_analyze

            # ─── 2. الـ rendering (إنتاج الطبقة) ────────────────────────────────
            t_render = perf_counter()
            render_time, preview_path = self._render(task_data, is_video=False)
            stage_times["render"] = render_time

            # نفترض أن _render يحفظ المسار في self.last_layer_path
            # (أو يمكن تعديل _render لترجع المسار بدل float فقط)
            preview_path = getattr(self, 'last_layer_path', preview_path)

            if not preview_path or not Path(preview_path).exists():
                raise RuntimeError("لم يتم إنشاء مسار طبقة صالح")

            total_time = perf_counter() - start

            result = GenerationResult(
                success=True,
                message="تم إنشاء طبقة الكائن الحي بنجاح (foreground layer)",
                total_time=total_time,
                stage_times=stage_times,
                specialization="traditional_design",
                output_data={
                    "preview_path": preview_path,
                    "layer_type": "foreground",
                    "is_transparent": True,
                    "prompt_used": full_prompt
                }
            )

            logger.info(f"[Traditional] نجح → طبقة محفوظة في: {preview_path}")
            logger.info(f"الوقت الكلي: {total_time:.2f} ث | render: {render_time:.2f} ث")

            if reset_input_after:
                self.input_port.clear()

            return result

        except Exception as e:
            logger.exception("[Traditional generate_image] فشل")
            total_time = perf_counter() - start

            return GenerationResult(
                success=False,
                message=f"فشل توليد الطبقة: {str(e)}",
                total_time=total_time,
                stage_times=stage_times,
                specialization="traditional_design",
                output_data={}
            )
            
    def _get_specialization_config(self) -> Dict[str, Any]:
         return {
            "name": "traditional_design",
            "rendering_style": "organic",
            "units": {
                "nlp": {"function": self._analyze_prompt, "refreshed": False},
                "integration": {"function": self._integrate_traditional, "refreshed": False},
                "post_processing": {"function": self._post_process_traditional, "refreshed": False},
                "rendering": {"function": self._render, "refreshed": False},
            }
        }

    def validate_input(self, input_data: str) -> bool:
        """التحقق الخاص بالتخصص التقليدي"""
        lower = input_data.lower()
        keywords = self.specialization.get("validate_keywords", [])
        return any(kw in lower for kw in keywords)

    def _post_analyze_add_tasks(self, task_data: dict) -> None:
        """
        تحويل الكيانات المستخرجة (كائنات حية فقط) إلى مهام تصميم فرعية
        مع تعقيد افتراضي يناسب تصميم الشخصيات / الحيوانات / المخلوقات
        """
        logger.info("===== داخل _post_analyze_add_tasks (تلقائي - Traditional Creature فقط) =====")
        logger.info(f"Entities المتاحة: {task_data.get('entities', [])} | mood: {task_data.get('mood', 'neutral')}")

        # ────────────────────────────────────────────────────────────────
        # خريطة التعقيد — فقط للكائنات الحية وأجزائها
        # القيم تعبر عن "جهد التصميم النسبي" (placeholder)
        # ────────────────────────────────────────────────────────────────
        entity_to_complexity = {
            # الكيان الرئيسي
            "creature":     3.5,
            "humanoid":     4.2,
            "human":        4.5,
            "person":       4.3,
            "animal":       3.2,
            
            # أجزاء / جوانب التصميم الفرعية (يمكن توسيعها كثيرًا لاحقًا)
            "head":         2.8,
            "face":         3.1,
            "expression":   2.9,
            "eyes":         2.4,
            "hair":         2.7,
            "body":         3.0,
            "pose":         2.6,
            "clothing":     3.4,    # أعلى لو كانت شخصية بشرية
            "wings":        3.3,
            "tail":         2.5,
            "horns":        2.8,
            "glow/aura":    2.2,
            "accessories":  2.0,
        }

        added_count = 0
        added_tasks = []

        entities = task_data.get("entities", [])

        if not entities or "creature" not in entities:
            logger.info("لا يوجد كائن حي → لن تُضاف مهام")
            return

        # ─── 1. إضافة المهمة الرئيسية (الكائن ككل) ───────────────────────
        main_entity = "humanoid" if "humanoid" in entities else \
                    "animal"   if "animal"   in entities else \
                    "creature"

        if not any(t["name"].lower() == main_entity for t in self.tasks):
            self.add_task(
                task_name=main_entity.capitalize(),
                complexity=entity_to_complexity.get(main_entity, 3.5),
                dependencies=[]
            )
            added_count += 1
            added_tasks.append(main_entity)

        # ─── 2. إضافة مهام فرعية تلقائية بناءً على النوع والمزاج ────────
        mood = task_data.get("mood", "neutral")

        sub_tasks = []

        # مهام أساسية شبه دائمة لأي كائن
        sub_tasks.extend(["head", "body", "pose"])

        # مهام إضافية حسب النوع
        if "humanoid" in entities or "human" in entities or "person" in entities:
            sub_tasks.extend(["face", "expression", "eyes", "hair", "clothing"])
        
        if "animal" in entities:
            sub_tasks.extend(["eyes", "tail"])  # يمكن إضافة "ears", "paws" لاحقًا

        # مهام خاصة بالمزاج
        if mood == "mysterious":
            sub_tasks.append("glow/aura")
        if mood == "epic":
            sub_tasks.extend(["glow/aura", "pose"])  # الـ pose الملحمي أصعب

        # ─── 3. إضافة المهام الفرعية (مع تجنب التكرار) ────────────────────
        for sub in sub_tasks:
            sub_lower = sub.lower()
            if not any(t["name"].lower() == sub_lower for t in self.tasks):
                complexity = entity_to_complexity.get(sub_lower, 2.5)
                # زيادة طفيفة لو كان المزاج معقد
                if mood in ["mysterious", "epic"]:
                    complexity *= 1.15

                self.add_task(
                    task_name=sub.capitalize(),
                    complexity=round(complexity, 1),
                    dependencies=[main_entity.capitalize()]  # تعتمد على المهمة الرئيسية
                )
                added_count += 1
                added_tasks.append(sub)

        # ─── تسجيل النتيجة ──────────────────────────────────────────────────
        if added_count > 0:
            logger.info(f"تم إضافة {added_count} مهمة تلقائيًا: {added_tasks}")
        else:
            logger.info("لم تُضف مهام جديدة (جميعها موجودة مسبقًا)")
                    
    def _render_traditional(self, task_data: Dict, is_video: bool = False) -> float:
        """
        مرحلة الـ rendering للتصاميم التقليدية
        (محاكاة وقت أطول لأنها أكثر تعقيداً عضوياً)
        """
        complexity = sum(t.get("complexity", 0) for t in self.tasks)
        base_time = complexity * 1.2

        if is_video:
            base_time *= 3.0  # تكلفة أعلى للفيديو في التصاميم العضوية

        logger.info(f"[Traditional Render] تعقيد: {complexity:.1f} → وقت تقريبي: {base_time:.1f}s "
                    f"{'(فيديو)' if is_video else '(صورة)'}")
        return base_time

    def _integrate_traditional(self, task_data: Dict) -> Dict:  # ← غيّر float → Dict
        """
        تكامل الطبقات في النمط التقليدي العضوي
        تعتمد بشكل أساسي على المهام الموجودة في self.tasks
        """
        logger.info("===== داخل _integrate_traditional المتخصص =====")
        logger.info(f"Entities من task_data: {task_data.get('entities', [])}")
        logger.info(f"عدد المهام الحالية: {len(self.tasks)}")
        logger.info(f"Refreshed: {self.specialization['units'].get('integration', {}).get('refreshed', False)}")
        
        # ─── 1. الاعتماد على self.tasks كمصدر رئيسي ───────────────────────────────
        tasks = self.tasks
        if not tasks:
            logger.warning("لا توجد مهام → تكامل افتراضي بسيط")
            task_data["planes"] = []
            task_data["plane_interactions"] = []
            task_data["integration_summary"] = {"layers": 0, "interactions": 0, "total_complexity": 0.0}
            task_data["integration_time"] = 0.35  # احتفظ بالوقت داخل القاموس
            return task_data

        # حساب تعقيد كلي + متوسط
        total_complexity = sum(t.get("complexity", 1.0) for t in tasks)
        avg_complexity = total_complexity / len(tasks)

        # ─── 2. محاولة استيراد PlaneLayer (مع حماية) ───────────────────────────────
        try:
            from plane_layer import PlaneLayer
        except ImportError:
            logger.error("فشل استيراد PlaneLayer → لا طبقات حقيقية")
            task_data["planes"] = []
            task_data["plane_interactions"] = []
            task_data["integration_summary"] = {"layers": 0, "interactions": 0, "total_complexity": total_complexity}
            task_data["integration_time"] = 0.4 + total_complexity * 0.3
            return task_data

        # ─── 3. إنشاء الطبقات بناءً على المهام ──────────────────────────────────
        planes = []
        refreshed = self.specialization['units'].get('integration', {}).get('refreshed', False)

        # قاموس تحويل اسم المهمة → إعدادات PlaneLayer
        task_to_plane_config = {
            "creature":     {"label": "Creature_Core", "color": "saddlebrown", "force": 0.70, "mass": 1.4},
            "animal":       {"label": "Animal_Form",   "color": "chocolate",   "force": 0.65, "mass": 1.3},
            "nature":       {"label": "Ground_Base",   "color": "darkgreen",   "force": 0.75, "mass": 2.0},
            "forest":       {"label": "Nature_Flow",   "color": "forestgreen", "force": 0.55, "mass": 1.25},
            "environment":  {"label": "Env_Backdrop",  "color": "olivedrab",   "force": 0.50, "mass": 1.8},
            # يمكن توسيعه
        }

        for task in tasks:
            name_lower = task["name"].lower()
            config = task_to_plane_config.get(name_lower)
            if config or refreshed:
                # موقع افتراضي (يمكن تحسينه لاحقًا)
                pos = [len(planes) * 1.2, -0.5 + len(planes) * 0.6, 0.0]
                plane = PlaneLayer(
                    position=pos,
                    force=config["force"] if config else 0.45,
                    label=config["label"] if config else f"Task_{task['name']}",
                    color=config["color"] if config else "sienna",
                    mass=config["mass"] if config else 1.0
                )
                planes.append(plane)

        # إضافة طبقات إضافية عند refreshed
        if refreshed:
            for i in range(2, 5):
                pos = [1.5 + i * 0.8, 0.6 + i * 0.3, 0.0]
                aura = PlaneLayer(pos, 0.35 + i*0.1, f"Aura_{i}", "lightgoldenrodyellow", 0.85)
                planes.append(aura)

        # ─── 4. حساب التفاعلات + حركة بسيطة (مثال) ────────────────────────────────
        interactions = []
        import numpy as np

        for i, p1 in enumerate(planes):
            for p2 in planes[i+1:]:
                dist = p1.distance_to(p2) if hasattr(p1, 'distance_to') else 1.0
                raw = p1.force * p2.force / (dist + 1e-5)   # بديل بسيط لو ما فيش raw_interaction
                x2 = raw ** 2

                interactions.append({
                    "from": p1.label,
                    "to": p2.label,
                    "distance": round(dist, 3),
                    "raw": round(raw, 4),
                    "x2_effect": round(x2, 4)
                })

                # حركة خفيفة (اختياري)
                if x2 > 0.5:
                    direction = np.array(p2.position) - np.array(p1.position)
                    norm = np.linalg.norm(direction)
                    if norm > 1e-8:
                        direction /= norm
                        force_mag = x2 * 0.03
                        p1.apply_force(direction * force_mag, dt=0.1)
                        p2.apply_force(-direction * force_mag * 0.8, dt=0.1)

        # ─── 5. حفظ النتائج في task_data للمراحل اللاحقة ────────────────────────
        task_data["planes"] = [
            {
                "label": p.label,
                "position": p.position,
                "force": p.force,
                "color": p.color,
                "mass": p.mass,
                "trail": getattr(p, "trail", []) if hasattr(p, "trail") else []
            } for p in planes
        ]
        task_data["plane_interactions"] = interactions
        task_data["integration_summary"] = {
            "layers": len(planes),
            "interactions": len(interactions),
            "total_complexity": total_complexity,
            "avg_complexity": avg_complexity
        }

        # ─── 6. وقت تقديري واقعي أكثر ──────────────────────────────────────────
        duration = (
            0.20 +                      # وقت أساسي
            len(planes) * 0.09 +        # لكل طبقة
            len(interactions) * 0.035 + # لكل تفاعل
            total_complexity * 0.25     # وزن التعقيد
        )

        # احتفظ بالوقت داخل task_data بدلاً من إرجاعه منفصلاً
        task_data["integration_time"] = duration

        logger.info(
            f"[Traditional Integrate] {len(planes)} طبقة | {len(interactions)} تفاعل | "
            f"تعقيد كلي: {total_complexity:.1f} | وقت مقاس: {duration:.2f} ث"
        )

        return task_data   # ← هذا التغيير الوحيد المهم

    def _post_process_traditional(self, task_data: Dict) -> float:
        """
        التحسين النهائي (bloom, grain, color grading عضوي...)
        """
        complexity = sum(t.get("complexity", 0) for t in self.tasks)
        base_time = complexity * 0.5
        dynamic = complexity * 0.1 if task_data.get("mood") == "mysterious" else 0

        if self.specialization["units"].get("post_processing", {}).get("refreshed", False):
            base_time *= 1.1

        total = base_time + dynamic
        logger.info(f"[Traditional Post-process] وقت تقريبي: {total:.1f}s")
        return total

    # ────────────────────────────────────────────────
    #              تنفيذ اختياري للـ preview
    # ────────────────────────────────────────────────

    def _save_preview(self, specialization: str, task_data: dict, is_video: bool = False) -> str:
        import matplotlib.pyplot as plt
        import numpy as np
        from pathlib import Path

        output_path = Path(f"{specialization}_output.{'gif' if is_video else 'png'}")

        try:
            fig, ax = plt.subplots(figsize=(8, 6))
            ax.set_facecolor('#0a0a1f')
            ax.text(0.5, 0.5, 
                    f"{specialization.upper()}\nPrompt: {task_data.get('raw_prompt', 'N/A')}\nTime: {self.render_time:.1f}s",
                    ha='center', va='center', fontsize=14, color='white')
            ax.axis('off')

            if specialization == "traditional_design":
                ax.add_patch(plt.Circle((0.5, 0.6), 0.2, color='sienna', alpha=0.7))   # creature placeholder
                ax.add_patch(plt.Rectangle((0, 0), 1, 0.4, color='darkgreen', alpha=0.6))  # nature ground

            plt.savefig(output_path, dpi=120, bbox_inches='tight', facecolor=fig.get_facecolor())
            plt.close(fig)
            logging.info(f"Image saved as {output_path}")
            return str(output_path)
        except Exception as e:
            logging.error(f"Failed to save preview: {e}")
            return "failed_to_generate_preview"

    def check_improvement_needed(self, specialization: str, stage: str) -> bool:
        spec = self.specializations[specialization]
        tasks = spec["tasks"]
        if not tasks:
            return False
        total_complexity = sum(t["complexity"] for t in tasks)
        return len(tasks) > 1 or total_complexity > 6.0

    # ────────────────────────────────────────────────────────────────
    #              الـ Overrides الضرورية (في نهاية الكلاس)
    # ────────────────────────────────────────────────────────────────
    # هذه الدوال تضمن أن المحرك يستخدم النسخ المتخصصة بدلاً من النسخ العامة في الكور

    def _analyze_prompt(self, prompt: str) -> Dict[str, Any]:
        """
        تحليل النص المدخل (prompt) لاستخراج الكيانات الرئيسية (كائنات حية فقط) والمزاج.
        لا يتعامل مع الخلفيات أو البيئة → هذه مسؤولية محركات أخرى.
        
        Returns:
            Dict[str, Any]: قاموس يحتوي على الكيانات، الأسلوب، المزاج، والنص الأصلي
        """
        logger.info(f"[Traditional] تحليل الـ prompt: {prompt[:80]}{'...' if len(prompt)>80 else ''}")

        try:
            if not prompt or not isinstance(prompt, str):
                raise ValueError("الـ prompt فارغ أو غير صالح")

            lower_prompt = prompt.lower()

            entities = []

            # ────────────────────────────────────────────────
            # كلمات مفتاحية للكائنات الحية فقط (بشر + حيوانات + مخلوقات)
            # ────────────────────────────────────────────────
            creature_keywords = {
                # إنجليزي
                "creature", "animal", "monster", "beast", "character", "person", "human",
                "girl", "boy", "woman", "man", "child", "baby",
                "horse", "dragon", "lion", "wolf", "cat", "dog", "bird", "fish",
                "angel", "demon", "fairy", "elf", "orc", "goblin",
                # عربي
                "فتاة", "ولد", "صبي", "بنت", "امرأة", "رجل", "طفل", "رضيع",
                "حصان", "تنين", "أسد", "ذئب", "قط", "كلب", "طائر", "سمكة",
                "ملاك", "شيطان", "جنية", "إلف", "أورك", "غوبلن",
                "كائن", "وحش", "مخلوق", "شخصية", "إنسان"
            }

            # ────────────────────────────────────────────────
            # مزاج / أجواء (مفيد لتصميم الكائن: إضاءة، تعبيرات، ألوان...)
            # ────────────────────────────────────────────────
            mood_keywords = {
                # غامض / سحري / مخيف
                "dark", "enchanted", "mystical", "سحرية", "غامض", "ظلام", "ضبابي", "مخيف", "رعب",
                # هادئ / جميل / نقي
                "calm", "peaceful", "beautiful", "نقي", "هادئ", "جميل", "رقيق",
                # قوي / ملحمي
                "epic", "powerful", "majestic", "ملحمي", "قوي", "مهيب"
            }

            # ─── الكشف عن الكيانات ───────────────────────────────────────
            if any(kw in lower_prompt for kw in creature_keywords):
                entities.append("creature")

                # يمكن توسيع التصنيف لاحقًا إذا أردت دقة أكبر
                if any(kw in lower_prompt for kw in ["human", "person", "إنسان", "فتاة", "girl", "ولد", "boy", "امرأة", "رجل"]):
                    entities.append("humanoid")
                if any(kw in lower_prompt for kw in ["horse", "حصان", "dragon", "تنين", "lion", "أسد"]):
                    entities.append("animal")

            # ─── تحديد المزاج (نأخذ أول تطابق قوي) ──────────────────────
            mood = "neutral"
            for m in ["mysterious", "calm", "epic"]:
                keys = [k for k in mood_keywords if m in k or k in lower_prompt]
                if keys:
                    mood = m
                    break

            # ─── بناء النتيجة ─────────────────────────────────────────────
            task_data = {
                "entities": entities,
                "style": "organic",
                "mood": mood,
                "main_subject": entities[0] if entities else "unknown",
                "raw_prompt": prompt,
                "is_relevant": bool(entities)  # ← جديد: هل يوجد كائن حي فعلاً؟
            }

            logger.info(f"[Traditional NLP] entities={entities} | mood={mood} | relevant={task_data['is_relevant']}")

            # إضافة المهام التلقائية (ستُعدل لاحقًا لتركز على الكائن فقط)
            self._post_analyze_add_tasks(task_data)

            return task_data

        except Exception as e:
            logger.exception(f"[Traditional NLP Error] {e}")
            
            fallback = {
                "entities": [],
                "style": "organic",
                "mood": "neutral",
                "main_subject": "unknown",
                "raw_prompt": prompt or "prompt فارغ",
                "is_relevant": False,
                "analysis_failed": True,
                "error_message": str(e)
            }
            
            try:
                self._post_analyze_add_tasks(fallback)
            except:
                pass
                
            return fallback
    
    def _integrate(self, task_data: Dict) -> Dict:
        # تهيئة الحقول المتوقعة لو مش موجودة
        task_data.setdefault("entities", [])
        task_data.setdefault("planes", [])
        task_data.setdefault("summary", {})
        task_data.setdefault("warnings", [])
        task_data.setdefault("mood", "neutral")          # خاص بالـ traditional
        task_data.setdefault("lighting_layers", 1)       # خاص بالـ traditional

        # باقي منطق التكامل الخاص بك (مثال)
        if "creature" in task_data["entities"]:
            task_data["planes"].append({"type": "foreground", "subject": "horse and girl"})

        task_data["summary"] = {"layers_count": len(task_data["planes"])}
        return task_data
    
    def _post_process(self, task_data: Dict) -> Dict[str, Any]:
        # حساب الوقت التقريبي (أو أي منطق عندك)
        duration = 8.8  # أو أي قيمة

        logger.info(f"[Traditional Post-process] وقت تقريبي: {duration:.1f}s")

        return {
            "success": True,
            "duration_seconds": duration,
            "summary": "Traditional post-processing completed",
            "warnings": [],
            "metadata": {
                "mood": task_data.get("mood", "unknown"),
                "entities_count": len(task_data.get("entities", []))
            }
        }

    def _render(self, task_data: Dict, is_video: bool = False) -> tuple[float, Optional[str]]:
        """
        مرحلة الـ rendering الرئيسية لمحرك التصميم التقليدي.
        Returns: (render_time, preview_path) أو (وقت, None) لو فشل
        """
        t0 = perf_counter()

        preview_path = None
        try:
            logger.debug("[Traditional Render] بدء إنشاء طبقة الكائن...")

            preview_path = self._create_simple_image(
                specialization=self.specialization.get("name", "traditional"),
                task_data=task_data,
                is_video=is_video
            )

            if preview_path and Path(preview_path).exists():
                mode = "GIF" if is_video else "PNG"
                logger.info(f"[Traditional Render] تم إنشاء طبقة {mode} بنجاح → {preview_path}")
            else:
                logger.warning("[Traditional Render] لم يتم إنشاء مسار صالح")
                raise RuntimeError("فشل في إنشاء مسار الطبقة (preview_path فارغ أو غير موجود)")

        except Exception as e:
            logger.exception("[Traditional _render] فشل في إنشاء المعاينة")
            preview_path = None

        render_time = perf_counter() - t0
        self.render_time = render_time  # حفظ للوصول السريع لاحقًا

        # تسجيل واضح
        mode_str = "فيديو (GIF)" if is_video else "طبقة ثابتة"
        time_str = f"{render_time:.3f} ث" if render_time >= 0.02 else f"{render_time:.4f} ث (سريع)"
        path_str = preview_path or "فشل"
        logger.info(f"[Traditional Render] {mode_str} | وقت: {time_str} | مسار: {path_str}")

        return render_time, preview_path
    
    def _create_simple_image(
        self,
        specialization: str,
        task_data: Dict,
        width: int = 640,
        height: int = 480,
        transparent_bg: bool = True,       # دائمًا شفافة كطبقة
        layer_opacity: int = 255,          # نترك التحكم للـ composite لاحقًا
        is_video: bool = False
    ) -> Optional[str]:
        """
        إنشاء طبقة شفافة تحتوي فقط على الكائن الحي (placeholder بسيط بـ PIL)
        لا ترسم خلفية أو بيئة — هذه مسؤولية محركات أخرى
        """
        from PIL import Image, ImageDraw
        from pathlib import Path
        import random

        output_path = Path(f"{specialization}_creature_layer_{int(random.random()*1000000)}.png")

        try:
            # ─── دائمًا طبقة شفافة ─────────────────────────────────────────────
            img = Image.new("RGBA", (width, height), (0, 0, 0, 0))
            draw = ImageDraw.Draw(img)

            entities = task_data.get("entities", [])
            mood = task_data.get("mood", "neutral")

            if not entities or "creature" not in entities:
                # لو مفيش كائن → نرجع طبقة فارغة (شفافة تمامًا)
                logger.info("[Traditional Render] لا يوجد كائن حي → طبقة فارغة")
                img.save(output_path, "PNG", optimize=True)
                return str(output_path)

            # ─── مركز الصورة للكائن ────────────────────────────────────────────
            center_x = width // 2
            center_y = height // 2 + 60   # شوية تحت المنتصف عشان يبان طبيعي

            # ─── ألوان أساسية حسب المزاج ──────────────────────────────────────
            body_color = (220, 220, 240)      # افتراضي فاتح
            skin_color = (250, 215, 175)
            hair_color = (180, 140, 100)
            eye_color = (0, 0, 0)

            if mood == "mysterious":
                body_color = (140, 120, 180)   # بنفسجي غامق
                skin_color = (200, 180, 220)
                hair_color = (60, 40, 80)
            elif mood == "epic":
                body_color = (210, 180, 140)   # ذهبي/برونزي
                skin_color = (240, 210, 160)
                hair_color = (120, 80, 40)

            # ─── رسم الكائن حسب النوع (بسيط جدًا حاليًا) ──────────────────────
            if "humanoid" in entities or "girl" in str(task_data).lower() or "فتاة" in str(task_data).lower():
                # ─── فتاة / شخص بسيط ───────────────────────────────────────────
                # جسم
                draw.ellipse((center_x-60, center_y-120, center_x+60, center_y+80), fill=body_color)
                # رأس
                draw.ellipse((center_x-45, center_y-160, center_x+45, center_y-80), fill=skin_color)
                # شعر (مستطيل مبسط + دوائر)
                draw.rectangle((center_x-50, center_y-170, center_x+50, center_y-110), fill=hair_color)
                draw.ellipse((center_x-50, center_y-170, center_x+50, center_y-130), fill=hair_color)
                # عيون
                draw.ellipse((center_x-18, center_y-135, center_x-8, center_y-125), fill=eye_color)
                draw.ellipse((center_x+8, center_y-135, center_x+18, center_y-125), fill=eye_color)

            elif "horse" in str(task_data).lower() or "حصان" in str(task_data).lower():
                # ─── حصان بسيط ──────────────────────────────────────────────────
                # جسم
                draw.ellipse((center_x-100, center_y-40, center_x+100, center_y+100), fill=body_color)
                # رأس
                draw.ellipse((center_x+60, center_y-80, center_x+120, center_y-20), fill=body_color)
                # أذنين
                draw.polygon([
                    (center_x+80, center_y-90), (center_x+90, center_y-110),
                    (center_x+100, center_y-85)
                ], fill=body_color)
                draw.polygon([
                    (center_x+100, center_y-90), (center_x+110, center_y-110),
                    (center_x+120, center_y-85)
                ], fill=body_color)
                # عين
                draw.ellipse((center_x+95, center_y-60, center_x+105, center_y-50), fill=(0,0,0))
                # أرجل بسيطة
                for dx in [-70, -30, 30, 70]:
                    draw.rectangle((center_x+dx-12, center_y+60, center_x+dx+12, center_y+140), fill=body_color)

            else:
                # fallback: كائن عام (دائرة + ملحقات)
                draw.ellipse((center_x-80, center_y-80, center_x+80, center_y+80), fill=body_color)
                draw.text((center_x-30, center_y-20), "?", fill=(255,255,255), font_size=60)

            # ─── glow خفيف جدًا حسب المزاج (اختياري) ──────────────────────────
            if mood in ["mysterious", "epic"]:
                glow_color = (200, 180, 255, 60) if mood == "mysterious" else (255, 220, 120, 70)
                for r in range(90, 150, 20):
                    draw.ellipse(
                        (center_x-r, center_y-r, center_x+r, center_y+r),
                        outline=glow_color, width=8
                    )

            # ─── حفظ ─────────────────────────────────────────────────────────────
            if is_video:
                logger.warning("[Traditional] GIF غير مدعوم حاليًا → حفظ PNG")
            
            img.save(output_path, "PNG", optimize=True)
            logger.info(f"[Traditional Creature Layer] تم الحفظ: {output_path}")

            return str(output_path)

        except Exception as e:
            logger.exception("[Traditional _create_simple_image] فشل")
            return None
    
# ────────────────────────────────────────────────
#              اختبار سريع (اختياري)
# ────────────────────────────────────────────────

if __name__ == "__main__":
    print("traditional_design_engine.py تم تحميله كـ __main__")
    engine = traditional_design_engine()
    print("تم إنشاء الكائن بنجاح")
    print("generate_image موجود؟", hasattr(engine, "generate_image"))
    print("═" * 70)
    print("اختبار Traditional Design Engine")
    print("═" * 70)

    engine = traditional_design_engine()

    # prompt مناسب للـ traditional
    engine.receive_input("a majestic dragon creature in enchanted misty forest with glowing aura and organic flow")

    # أضف مهام بسيطة
    engine.add_task("main_creature", complexity=4.8)
    engine.add_task("forest_background", complexity=3.5)
    engine.add_task("aura_effect", complexity=2.7)

    result = engine.generate_image(is_video=False, force_refresh=True)

    print("\nنتيجة التوليد:")
    print(f"نجاح: {result.success}")
    print(f"رسالة: {result.message}")
    print(f"الوقت الكلي: {result.total_time:.2f} ث")
    if result.output_data and "preview_path" in result.output_data:
        print(f"مسار المعاينة: {result.output_data['preview_path']}")