import matplotlib.pyplot as plt

fig, ax = plt.subplots()
ax.text(0.5, 0.5, "اختبار ناجح", ha='center', va='center', fontsize=30, color='red')
plt.savefig("test_success.png", dpi=100)
print("تم حفظ test_success.png")
plt.close(fig)