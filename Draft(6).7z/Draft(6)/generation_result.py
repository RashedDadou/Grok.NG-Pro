# generation_result.py

from dataclasses import dataclass, field
from typing import Dict, Optional, Any

@dataclass
class GenerationResult:
    success: bool
    message: str
    total_time: float
    stage_times: Dict[str, float]
    specialization: str
    is_video: bool = False
    output_data: Optional[Dict] = None
    mode: Optional[str] = None

    def __post_init__(self):
        if self.stage_times is None:
            self.stage_times = {}