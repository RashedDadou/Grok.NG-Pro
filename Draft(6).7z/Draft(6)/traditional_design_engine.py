# في traditional_design_engine.py

from dataclasses import dataclass, field   # ← أضف dataclass لو مش موجود
from typing import Dict, Any, Optional, List
from datetime import datetime
from PIL import Image, ImageDraw
import random
import logging
import math
from pathlib import Path
from time import perf_counter
from PIL import Image, ImageDraw, ImageFont

from layer_engine import LayerEngine  # أو المسار الصحيح
from typing import Tuple  # لو مش موجود

# الاستيراد الوحيد المهم (من الكور)
from Core_Image_Generation_Engine import CoreImageGenerationEngine
from memory_manager import GenerativeMemoryManager
from Image_generation import CoreImageGenerationEngine  # ← استيراد النواة
from generation_result import GenerationResult

print("تم تحميل traditional_design_engine.py")

logger = logging.getLogger(__name__)

from typing import List, Dict, Any, Optional
from copy import deepcopy

@dataclass
class TraditionalDesignResult:
    success: bool
    enhanced_prompt: str
    metadata: Dict[str, Any]
    layer_type: str = "foreground"
    message: str = ""
    design_time_seconds: float = 0.0
    
class traditionalDesignEngine (LayerEngine, CoreImageGenerationEngine):
    """
    محرك متخصص في تحليل وتحسين وصف الكائنات التقليدية / العضوية فقط.
    الإخراج الرئيسي: dict نصي محسن + metadata
    لا يتدخل في توليد الصور النهائية (دور Final_Generation)
    """

    def __init__(self):
        super().__init__()
        self.specialization = {
            "name": "traditional_design",
            "type": "foreground",
            "description": "تصميم شخصيات ومخلوقات عضوية، تفاصيل تشريحية، تعبيرات عاطفية"
        }
        self.memory_manager = GenerativeMemoryManager()
        self.memory_manager.context_type = "traditional"
        logger.info("[TraditionalEngine] تم التهيئة – تصميم نصي فقط (foreground)")
        
    def _get_specialization_config(self) -> Dict[str, Any]:
        return {"name": "environment", "description": "تصميم البيئة"}

    def _analyze_prompt(self, prompt: str) -> Dict[str, Any]:
        return {"entities": prompt.split(), "style": "environment"}

    def _enhance_traditional_prompt(self, prompt: str) -> Dict[str, Any]:
        lower = prompt.lower()

        metadata = {
            "entities": self._extract_creatures(lower),
            "mood": self._detect_mood(lower),
            "lighting": self._suggest_lighting(lower),
            "anatomy": "highly detailed anatomy, realistic proportions, emotional expression",
            "details": "intricate skin texture, individual hair strands, fabric folds, subtle imperfections",
            "timestamp": datetime.now().isoformat()
        }

        enhanced = (
            f"{prompt}, {metadata['anatomy']}, {metadata['details']}, "
            f"{metadata['mood']} atmosphere, {metadata['lighting']}, "
            "masterpiece, best quality, ultra detailed, cinematic, 8k"
        )

        return {"prompt": enhanced, "metadata": metadata}

    def receive_input(self, prompt: str) -> bool:
        """
        تلقي prompt جديد مع التحقق الأساسي
        (حذف التحقق من validate_keywords لأنه كان جزءًا من pipeline قديمة)
        """
        if not isinstance(prompt, str) or not prompt.strip():
            logger.warning("Prompt غير صالح أو فارغ")
            return False

        stripped = prompt.strip()
        self.append_prompt_chunk(stripped)
        logger.info(f"[{self.specialization.get('name', 'unknown')}] received: {stripped[:60]}...")
        return True
    
    def _cleanup_temp_files(self):
        """
        حذف أي ملفات مؤقتة تم إنشاؤها (اختياري، حسب الحاجة)
        """
        for file_path in self.temp_files:
            try:
                Path(file_path).unlink()
                logger.info(f"تم حذف الملف المؤقت: {file_path}")
            except Exception as e:
                logger.warning(f"فشل حذف الملف المؤقت {file_path}: {e}")
        self.temp_files.clear()

    def append_prompt_chunk(self, chunk: str):
        """
        إضافة جزء من الـ prompt إلى المنفذ (بسيط ونظيف)
        """
        if not hasattr(self, "input_port"):
            self.input_port = []
        self.input_port.append(chunk.strip())
        logger.debug(f"Input chunk appended: {chunk[:50]}...")
        
    def add_task(self, task_name: str, complexity: float = 1.0, dependencies: Optional[List[str]] = None):
        """
        إضافة مهمة وصفية بسيطة (اختياري – للتتبع فقط، مش بصري)
        """
        if not hasattr(self, "tasks"):
            self.tasks = []
        self.tasks.append({
            "name": task_name,
            "complexity": complexity,
            "dependencies": dependencies or []
        })
        logger.debug(f"Added task: {task_name} (complexity: {complexity})")

        if not hasattr(self, "tasks"):
            self.tasks = []
        self.tasks.append({"name": task_name, "complexity": complexity, "dependencies": dependencies or []})
  
    def design(self, description: str, **kwargs) -> TraditionalDesignResult:
        start = datetime.now()
        result = self._enhance_traditional_prompt(description)

        return TraditionalDesignResult(
            success=True,
            enhanced_prompt=result["prompt"],
            metadata=result["metadata"],
            design_time_seconds=(datetime.now() - start).total_seconds()
        )
    
    def generate_image(
        self,
        force_refresh: bool = False,
        as_layer: bool = True,
        target_size: Tuple[int, int] = (1024, 1024),
        reset_input_after: bool = True,
        is_video: bool = False,
        **kwargs
    ) -> GenerationResult:
        """
        الواجهة القديمة للتوافق – تجمع من input_port
        → تم تنظيفها: ترجع dict نصي محسن فقط (لا صورة، لا حفظ، لا render)
        """
        start_total = perf_counter()
        stage_times = {"enhance": 0.0}

        try:
            if not self.input_port:
                return GenerationResult(
                    success=False,
                    message="لا يوجد prompt في المنفذ",
                    total_time=0.0,
                    stage_times={},
                    specialization=self.specialization["name"],
                    output_data={}
                )

            full_prompt = " ".join(self.input_port).strip()
            logger.info(f"[Traditional generate_image] prompt: {full_prompt[:70]}...")

            # تحليل وتحسين (نصي فقط)
            t_start = perf_counter()
            enhanced = self._enhance_prompt(full_prompt, force_refresh=force_refresh)
            stage_times["enhance"] = perf_counter() - t_start

            # تنظيف creepy إن وجد
            if self.memory_manager.check_for_creepy(full_prompt, enhanced):
                enhanced = self.memory_manager.refresh_memory(full_prompt, enhanced, "traditional")
                logger.info("[Traditional] تم refresh بسبب creepy detection")

            total_time = perf_counter() - start_total

            result = GenerationResult(
                success=True,
                message="تم تحسين وصف الكائن الحي بنجاح (نصي فقط)",
                total_time=total_time,
                stage_times=stage_times,
                specialization=self.specialization["name"],
                is_video=is_video,
                output_data={
                    "enhanced_prompt": enhanced["prompt"],
                    "metadata": enhanced["metadata"],
                    "layer_type": "foreground",
                    "notes": enhanced.get("enhancement_notes", [])
                }
            )

            logger.info(f"[Traditional] نجح (نصي) | وقت: {total_time:.2f} ث")

            if reset_input_after:
                self.input_port.clear()

            return result

        except Exception as e:
            logger.exception("[Traditional generate_image] فشل")
            return GenerationResult(
                success=False,
                message=f"فشل تحسين الوصف: {str(e)}",
                total_time=perf_counter() - start_total,
                stage_times=stage_times,
                specialization=self.specialization["name"],
                output_data={}
            )

    def generate_layer(self, prompt: str, **kwargs) -> GenerationResult:
        logger.info("[DEBUG-TRADITIONAL] تم استدعاء generate_layer مع prompt: %s", prompt[:100])
        start = datetime.now()
        
        result = self._enhance_traditional_prompt(prompt)
        
        return GenerationResult(
            success=True,
            message="تم تصميم الطبقة التقليدية (نصي فقط)",
            total_time=(datetime.now() - start).total_seconds(),
            specialization=self.specialization["name"],
            output_data={
                "enhanced_prompt": result["prompt"],
                "metadata": result["metadata"],
                "layer_type": "foreground",
                "design_version": "v2.0"
            }
        )
    
    def _extract_creatures(self, text: str) -> list:
        keywords = [
            "فتاة", "ولد", "امرأة", "رجل", "طفل", "حصان", "تنين", "أسد", "ذئب", "قطة", "كلب",
            "girl", "boy", "woman", "man", "child", "horse", "dragon", "lion", "wolf", "cat", "dog"
        ]
        return list(set(kw for kw in keywords if kw in text))

    def _detect_mood(self, text: str) -> str:
        if any(w in text for w in ["غامض", "ظلام", "dark", "mysterious", "creepy"]):
            return "dramatic, mysterious lighting, volumetric god rays"
        if any(w in text for w in ["هادئ", "رقيق", "calm", "peaceful", "serene"]):
            return "soft, ethereal lighting, gentle rim light"
        return "cinematic, dramatic side lighting, golden hour"

    def _suggest_lighting(self, text: str) -> str:
        if "ليل" in text or "night" in text:
            return "moonlight, volumetric fog, strong rim lighting"
        return "soft natural light, subtle rim light, cinematic"

    # ────────────────────────────────────────────────────────────────
    #              الـ Overrides الضرورية (في نهاية الكلاس)
    # ────────────────────────────────────────────────────────────────

    def _analyze_prompt(self, prompt: str) -> Dict[str, Any]:
        """
        تحليل محسن للـ prompt (تركيز على الكائنات العضوية / الشخصيات)
        يرجع dict غني يناسب Final_Generation مباشرة
        """
        if not prompt or not isinstance(prompt, str):
            logger.warning("[Traditional] prompt فارغ أو غير صالح")
            return self._fallback_analysis(prompt, "prompt فارغ أو غير صالح")

        start = perf_counter()
        lower = prompt.lower().strip()

        # ─── استخراج الكيانات بطريقة أذكى ──────────────────────────────
        entities = set()
        creature_keywords = {
            "فتاة", "ولد", "امرأة", "رجل", "طفل", "طفلة", "رضيع", "حصان", "تنين", "أسد", "ذئب",
            "قطة", "كلب", "طائر", "سمكة", "angel", "demon", "fairy", "elf", "orc", "goblin",
            "girl", "boy", "woman", "man", "child", "baby", "horse", "dragon", "lion", "wolf",
            "cat", "dog", "bird", "fish"
        }

        # كشف أكثر ذكاءً (بدل الكلمة الواحدة)
        words = lower.split()
        for word in words:
            clean = word.strip(".,!?;:()[]{}'\"")
            if clean in creature_keywords:
                entities.add(clean)
            elif clean.startswith(("فتاة", "ولد", "امرأ", "رجل", "طفل")):
                entities.add(clean[:4])  # للتعامل مع التصريفات

        # ─── المزاج والجو ────────────────────────────────────────────────
        mood_indicators = {
            "غامض": "mysterious", "ظلام": "dark", "ضباب": "foggy", "رعب": "horror",
            "هادئ": "calm", "جميل": "beautiful", "رقيق": "delicate", "ساحر": "enchanted",
            "ملحمي": "epic", "قوي": "powerful", "مهيب": "majestic"
        }

        mood = "neutral"
        for word in words:
            if word in mood_indicators:
                mood = mood_indicators[word]
                break

        # ─── بناء النتيجة المحسنة ────────────────────────────────────────
        enhanced_prompt = (
            f"{prompt}, highly detailed anatomy, realistic proportions, "
            f"emotional expression, intricate skin texture, individual hair strands, "
            f"{mood} atmosphere, cinematic lighting, masterpiece, ultra detailed, 8k"
        )

        result = {
            "entities": list(entities),
            "main_subject": list(entities)[0] if entities else "unknown",
            "mood": mood,
            "style": "organic, cinematic, detailed character design",
            "enhanced_prompt": enhanced_prompt,
            "confidence": 0.85 if entities else 0.35,
            "is_relevant": bool(entities),
            "raw_prompt": prompt,
            "analysis_time": round(perf_counter() - start, 3),
            "timestamp": datetime.now().isoformat()
        }

        logger.info(
            "[Traditional Analyze] entities=%s | mood=%s | confidence=%.2f | relevant=%s",
            result["entities"], mood, result["confidence"], result["is_relevant"]
        )

        return result

    def _fallback_analysis(self, prompt: str, reason: str) -> Dict[str, Any]:
        """نتيجة احتياطية في حالة الفشل"""
        return {
            "entities": [],
            "main_subject": "unknown",
            "mood": "neutral",
            "style": "organic",
            "enhanced_prompt": prompt,
            "confidence": 0.0,
            "is_relevant": False,
            "raw_prompt": prompt,
            "analysis_time": 0.0,
            "timestamp": datetime.now().isoformat(),
            "error": reason
        }
        
    def _integrate(self, task_data: Dict) -> Dict:
        """
        دالة تكامل خفيفة جدًا (نصية فقط)
        - تهيئة الحقول الأساسية في task_data
        - لا planes، لا تفاعلات، لا PlaneLayer، لا force/mass
        - يمكن حذفها لاحقًا إذا ما كانتش ضرورية
        """
        # تهيئة الحقول المتوقعة (بدون أي شيء بصري)
        task_data.setdefault("entities", [])
        task_data.setdefault("summary", {})
        task_data.setdefault("warnings", [])
        task_data.setdefault("metadata", {})

        # تحديث metadata بمعلومات نصية بسيطة
        task_data["metadata"].update({
            "entities_count": len(task_data["entities"]),
            "mood": task_data.get("mood", "neutral"),
            "integration_done": True
        })

        task_data["summary"] = {
            "note": "تم التكامل النصي بنجاح (لا طبقات بصرية هنا)"
        }

        return task_data

# ────────────────────────────────────────────────
#              اختبار سريع (اختياري)
# ────────────────────────────────────────────────

if __name__ == "__main__":
    print("traditional_design_engine.py تم تحميله كـ __main__")
    engine = traditionalDesignEngine()
    print("تم إنشاء الكائن بنجاح")
    print("generate_image موجود؟", hasattr(engine, "generate_image"))
    print("═" * 70)
    print("اختبار Traditional Design Engine")
    print("═" * 70)

    engine = traditionalDesignEngine()

    # prompt مناسب للـ traditional
    engine.receive_input("a majestic dragon creature in enchanted misty forest with glowing aura and organic flow")

    # أضف مهام بسيطة
    engine.add_task("main_creature", complexity=4.8)
    engine.add_task("forest_background", complexity=3.5)
    engine.add_task("aura_effect", complexity=2.7)

    result = engine.generate_image(is_video=False, force_refresh=True)

    print("\nنتيجة التوليد:")
    print(f"نجاح: {result.success}")
    print(f"رسالة: {result.message}")
    print(f"الوقت الكلي: {result.total_time:.2f} ث")
    if result.output_data and "preview_path" in result.output_data:
        print(f"مسار المعاينة: {result.output_data['preview_path']}")