# geometric_design_engine.py
"""
محرك التوليد الخاص بالتصاميم الهندسية
(أشكال، أنماط، تناظر، هياكل رياضية، تصاميم دقيقة ومتكررة...)
"""

from time import perf_counter
from typing import List, Dict, Optional, Tuple, Any
from datetime import datetime
from PIL import Image, ImageDraw
import numpy as np
import logging
logger = logging.getLogger(__name__)    
import math
import random

from memory_manager import GenerativeMemoryManager
from Image_generation import CoreImageGenerationEngine, perf_counter
from layer_engine import LayerEngine  # أو المسار الصحيح
from layer_plane import PlaneLayer  # أو المسار الصحيح
from generation_result import GenerationResult

class geometric_design_engine(LayerEngine, CoreImageGenerationEngine):
    """
    محرك متخصص في تحليل وتحسين وصف الأشكال الهندسية / الهيكلية فقط.
    الإخراج الرئيسي: dict نصي محسن + metadata
    لا يتدخل في توليد الصور النهائية (دور Final_Generation)
    """

    def __init__(self):
        # الحالة الأساسية المطلوبة فقط
        self.input_port: List[str] = []                     # الوصف المتراكم من المستخدم
        self.last_task_data: Optional[Dict] = None          # لتخزين بيانات المهمة الأخيرة (تحليل الـ prompt)
        self.tasks: List[Dict] = []                        # قائمة المهام الوصفية (اختياري – للتتبع النصي فقط)
        
        # التخصص البسيط والمحدث (لا حاجة لـ units أو وراثة معقدة)
        self.specialization = {
            "name": "geometric_design",
            "description": "تصاميم هندسية، أشكال، تناظر، أنماط متكررة، هياكل رياضية، فركتل، شبكات",
            "keywords": [
                "shape", "structure", "design", "pattern", "form", "symmetry", "polygon", "grid", "fractal",
                "hex", "honeycomb", "hexagonal", "spiral", "golden", "geometry", "abstract"
            ]
        }

        # قائمة لتتبع أي ملفات مرجعية مؤقتة ينشئها المحرك (اختياري)
        self.temp_files: List[str] = []
        self.last_task_data = None  # لتخزين بيانات المهمة الأخيرة (تحليل الـ prompt)
        self.tasks = []  # قائمة المهام الوصفية (اختياري – للتتبع النصي فقط)
        self.input_port = []  # لتخزين أجزاء الـ prompt المتراكمة
        self.memory_manager = GenerativeMemoryManager()  # لإدارة الذاكرة والتعامل مع creepy content
        
        logger.info("[GeometricEngine] تم تهيئة المحرك بنجاح – وضع نصي فقط")
          
    def _get_specialization_config(self) -> Dict[str, Any]:
        return {"name": "environment", "description": "تصميم البيئة"}

    def _analyze_prompt(self, prompt: str) -> Dict[str, Any]:
        return {"entities": prompt.split(), "style": "environment"}

    def _integrate(self, task_data: Dict) -> float:
        return 0.6

    def _post_process(self, task_data: Dict) -> Dict[str, Any]:
        return {"processed": True}

    def _render(self, task_data: Dict, is_video: bool = False) -> float:
        return 1.5

    def receive_input(self, prompt: str) -> bool:
        """
        تلقي prompt جديد مع التحقق الأساسي فقط
        (حذف validate_keywords لأنه كان جزء من النظام القديم)
        """
        if not isinstance(prompt, str) or not prompt.strip():
            logger.warning("Prompt غير صالح أو فارغ")
            return False

        stripped = prompt.strip()
        self.append_prompt_chunk(stripped)
        logger.info(f"[{self.specialization.get('name', 'unknown')}] received: {stripped[:60]}...")
        return True

    def append_prompt_chunk(self, chunk: str):
        """
        إضافة جزء من الـ prompt إلى المنفذ (بسيط ونظيف)
        """
        if not hasattr(self, "input_port"):
            self.input_port = []
        self.input_port.append(chunk.strip())
        logger.debug(f"Input chunk appended: {chunk[:50]}...")
        
    def add_task(self, task_name: str, complexity: float = 1.0, dependencies: Optional[List[str]] = None):
        """
        إضافة مهمة وصفية بسيطة (اختياري – للتتبع النصي فقط، مش بصري)
        """
        if not hasattr(self, "tasks"):
            self.tasks = []
        self.tasks.append({
            "name": task_name,
            "complexity": complexity,
            "dependencies": dependencies or []
        })
        logger.debug(f"Added task: {task_name} (complexity: {complexity})")
        
    def get_tasks(self) -> List[Dict]:
        """
        إرجاع قائمة المهام الوصفية (اختياري)
        """
        return getattr(self, "tasks", [])

    def generate_layer(
        self,
        prompt: str,
        target_size: Tuple[int, int] = (1024, 1024),
        is_video: bool = False,
        as_layer: bool = True,
        force_refresh: bool = False,
        **kwargs
    ) -> GenerationResult:
        """
        الواجهة المفضلة الجديدة – prompt مباشر
        ترجع dict نصي محسن فقط (لا صورة، لا render)
        """
        logger.info(f"[{self.specialization.get('name', 'unknown')}] generate_layer called with prompt: {prompt[:70]}...")

        start = perf_counter()
        enhanced = self._enhance_prompt(prompt, force_refresh=force_refresh)  # دالة تحسين نصية (موجودة سابقًا أو تضاف)

        result = GenerationResult(
            success=True,
            message="تم تحسين الوصف بنجاح (نصي فقط)",
            total_time=perf_counter() - start,
            stage_times={"enhance": perf_counter() - start},
            specialization=self.specialization["name"],
            is_video=is_video,
            output_data={
                "enhanced_prompt": enhanced["prompt"],
                "metadata": enhanced["metadata"],
                "layer_type": "midground" if "geometric" in self.specialization["name"] else "unknown"
            }
        )

        return result

    def generate_image(
        self,
        force_refresh: bool = False,
        as_layer: bool = True,
        target_size: Tuple[int, int] = (1024, 1024),
        reset_input_after: bool = True,
        is_video: bool = False,
        **kwargs
    ) -> GenerationResult:
        """
        الواجهة القديمة للتوافق – تجمع من input_port
        ترجع نفس نتيجة generate_layer (نصي فقط)
        """
        if not self.input_port:
            return GenerationResult(
                success=False,
                message="لا يوجد prompt في input_port",
                total_time=0.0,
                stage_times={},
                specialization=self.specialization["name"]
            )

        full_prompt = " ".join(self.input_port).strip()
        logger.info(f"[{self.specialization.get('name', 'unknown')}] generate_image called – prompt: {full_prompt[:70]}...")

        result = self.generate_layer(
            prompt=full_prompt,
            target_size=target_size,
            is_video=is_video,
            as_layer=as_layer,
            force_refresh=force_refresh,
            **kwargs
        )

        if reset_input_after:
            self.input_port.clear()

        return result

    def generate_image(
        self,
        force_refresh: bool = False,
        as_layer: bool = True,
        target_size: Tuple[int, int] = (1024, 1024),
        reset_input_after: bool = True,
        is_video: bool = False,
        **kwargs
    ) -> GenerationResult:
        """
        الواجهة القديمة للتوافق – تجمع الـ prompt من input_port
        → تم تنظيفها تمامًا: ترجع dict نصي محسن فقط (لا صورة، لا حفظ، لا render)
        """
        start_total = perf_counter()
        stage_times = {"enhance": 0.0}

        try:
            if not self.input_port:
                return GenerationResult(
                    success=False,
                    message="لا يوجد prompt في المنفذ",
                    total_time=0.0,
                    stage_times={},
                    specialization=self.specialization["name"],
                    output_data={}
                )

            full_prompt = " ".join(self.input_port).strip()
            logger.info(f"[{self.specialization['name']} generate_image] prompt: {full_prompt[:70]}...")

            # 1. تحليل وتحسين النص فقط (بدون أي render أو حفظ)
            t_start = perf_counter()
            enhanced = self._enhance_prompt(full_prompt, force_refresh=force_refresh)
            stage_times["enhance"] = perf_counter() - t_start

            # 2. تنظيف creepy إن وجد (نصي فقط)
            if self.memory_manager.check_for_creepy(full_prompt, enhanced):
                enhanced = self.memory_manager.refresh_memory(full_prompt, enhanced, self.specialization["name"])
                logger.info(f"[{self.specialization['name']}] تم refresh بسبب creepy detection")

            total_time = perf_counter() - start_total

            result = GenerationResult(
                success=True,
                message="تم تحسين الوصف بنجاح (نصي فقط)",
                total_time=total_time,
                stage_times=stage_times,
                specialization=self.specialization["name"],
                is_video=is_video,
                output_data={
                    "enhanced_prompt": enhanced["prompt"],
                    "metadata": enhanced["metadata"],
                    "notes": enhanced.get("enhancement_notes", []),
                    "layer_type": "midground" if "geometric" in self.specialization["name"] else "unknown"
                }
            )

            logger.info(f"[{self.specialization['name']}] نجح (نصي) | وقت: {total_time:.2f} ث")

            if reset_input_after:
                self.input_port.clear()

            return result

        except Exception as e:
            logger.exception(f"[{self.specialization['name']} generate_image] فشل")
            return GenerationResult(
                success=False,
                message=f"فشل تحسين الوصف: {str(e)}",
                total_time=perf_counter() - start_total,
                stage_times=stage_times,
                specialization=self.specialization["name"],
                output_data={}
            )
            
    def append_prompt_chunk(self, chunk: str):
        """
        إضافة جزء من الـ prompt إلى المنفذ (بسيط ونظيف)
        - محتفظ بها لأنها لا تتعارض مع الرؤية الجديدة
        """
        if not hasattr(self, "input_port"):
            self.input_port = []
        self.input_port.append(chunk.strip())
        logger.debug(f"[{self.specialization.get('name', 'unknown')}] appended chunk: {chunk[:50]}...")

# ────────────────────────────────────────────────
#              تنفيذ اختياري للـ preview
# ────────────────────────────────────────────────

    def _analyze_prompt(self, prompt: str) -> Dict[str, Any]:
        """
        تحليل الـ prompt لاستخراج الكيانات الهندسية الرئيسية والتناظر.
        ترجع dict نصي نظيف (entities + symmetry_level + mood + raw_prompt)
        """
        logger.info(f"[Geometric] تحليل الـ prompt: {prompt[:80]}{'...' if len(prompt)>80 else ''}")

        try:
            if not prompt or not isinstance(prompt, str):
                raise ValueError("الـ prompt فارغ أو غير صالح")

            lower_prompt = prompt.lower()
            words = set(lower_prompt.split())

            entities = []

            # كلمات مفتاحية هندسية بسيطة (بدون تعقيد)
            shape_keywords = {"shape", "polygon", "circle", "square", "triangle", "hexagon", "فركتل", "fractal"}
            pattern_keywords = {"pattern", "repeat", "tile", "grid", "honeycomb", "hexagonal"}
            symmetry_keywords = {"symmetry", "symmetrical", "mirror", "radial", "تناظر"}
            structure_keywords = {"structure", "form", "architecture", "spiral", "golden", "هيكل"}

            if any(kw in words or kw in lower_prompt for kw in shape_keywords):
                entities.append("shape")

            if any(kw in words or kw in lower_prompt for kw in pattern_keywords):
                entities.append("pattern")

            if any(kw in words or kw in lower_prompt for kw in symmetry_keywords):
                entities.append("symmetry")

            if any(kw in words or kw in lower_prompt for kw in structure_keywords):
                entities.append("structure")

            # تحديد مستوى التناظر (بسيط جدًا)
            symmetry_level = "high" if "symmetry" in entities else "medium" if "pattern" in entities else "low"

            # مزاج افتراضي بسيط (يمكن توسيعه لاحقًا)
            mood = "abstract" if entities else "neutral"

            # بناء النتيجة النصية فقط
            task_data = {
                "entities": list(set(entities)),  # بدون تكرار
                "style": "geometric",
                "symmetry_level": symmetry_level,
                "mood": mood,
                "main_element": entities[0] if entities else "abstract_form",
                "raw_prompt": prompt,
                "is_relevant": bool(entities),
                "analysis_timestamp": datetime.now().isoformat()
            }

            logger.info(f"[Geometric NLP] entities={task_data['entities']} | symmetry={symmetry_level} | mood={mood}")

            return task_data

        except Exception as e:
            logger.exception(f"[Geometric NLP Error] {e}")

            fallback = {
                "entities": [],
                "style": "geometric",
                "symmetry_level": "low",
                "mood": "neutral",
                "main_element": "unknown",
                "raw_prompt": prompt or "prompt فارغ",
                "is_relevant": False,
                "analysis_failed": True,
                "error_message": str(e)
            }
            return fallback

    def _create_simple_image(
        self,
        task_data: Dict,
        is_video: bool = False,
        transparent_bg: bool = False,
        target_size: tuple = (1024, 1024),
        layer_opacity: int = 255
    ) -> Optional[str]:
        try:
            from PIL import Image, ImageDraw
            import math
            import random
            from pathlib import Path
            from datetime import datetime

            width, height = target_size
            frames = []
            n_frames = 12 if is_video else 1

            entities = set(str(e).lower() for e in task_data.get("entities", []))
            symmetry = task_data.get("symmetry_level", "medium")
            prompt_lower = task_data.get("raw_prompt", "").lower()

            for f in range(n_frames):
                if transparent_bg:
                    img = Image.new("RGBA", (width, height), (0, 0, 0, 0))
                else:
                    img = Image.new("RGB", (width, height), (12, 10, 25))

                draw = ImageDraw.Draw(img)

                center_x, center_y = width // 2, height // 2

                # ─── 1. أنماط هندسية / شبكة / تناظر ────────────────────────────────
                if "pattern" in entities or "grid" in entities or "symmetry" in entities:
                    step = 60 if symmetry == "high" else 90
                    for x in range(0, width, step):
                        draw.line((x, 0, x, height), fill=(80, 120, 200, 120), width=1)
                    for y in range(0, height, step):
                        draw.line((0, y, width, y), fill=(80, 120, 200, 120), width=1)

                # ─── 2. دوامة ذهبية / spiral (شائعة في sacred geometry) ────────────
                if "spiral" in entities or "golden" in prompt_lower:
                    golden = (1 + math.sqrt(5)) / 2
                    theta = np.linspace(0, 10 * math.pi, 400)
                    r = 0.08 * np.exp(theta / golden)
                    angle_offset = f * 0.4 if is_video else 0
                    x = r * np.cos(theta + angle_offset) + center_x
                    y = r * np.sin(theta + angle_offset) + center_y
                    for i in range(len(x)-1):
                        draw.line((x[i], y[i], x[i+1], y[i+1]), fill=(255, 215, 0), width=2)

                # ─── 3. شكل سيارة بسيط / هيكل ميكانيكي (placeholder) ───────────────
                if "car" in prompt_lower or "vehicle" in entities or "سيارة" in prompt_lower:
                    # جسم السيارة
                    draw.rectangle((center_x-180, center_y+20, center_x+180, center_y+120), fill=(60, 70, 90))
                    # سقف/زجاج
                    draw.polygon([
                        (center_x-140, center_y+20),
                        (center_x+140, center_y+20),
                        (center_x+100, center_y-30),
                        (center_x-100, center_y-30)
                    ], fill=(40, 50, 70))
                    # عجلات
                    for dx in [-120, 120]:
                        draw.ellipse((center_x+dx-50, center_y+80, center_x+dx+50, center_y+180), fill=(20, 20, 30))
                        draw.ellipse((center_x+dx-30, center_y+100, center_x+dx+30, center_y+160), fill=(100, 100, 120))

                # ─── 4. تناظر عالي (mirrored effect) ────────────────────────────────
                if symmetry == "high":
                    # مرآة رأسية بسيطة
                    draw.line((center_x, 0, center_x, height), fill=(200, 180, 255, 80), width=3)

                # ─── جسيمات/نقاط لامعة للإحساس بالدقة الهندسية ───────────────────
                for _ in range(40):
                    x = random.randint(0, width)
                    y = random.randint(0, height)
                    sz = random.uniform(1.5, 4)
                    draw.ellipse((x-sz, y-sz, x+sz, y+sz), fill=(220, 240, 255, 140))

                frames.append(img)

            # ─── حفظ ────────────────────────────────────────────────────────────────
            ts = datetime.now().strftime("%Y%m%d_%H%M%S_%f")[:-3]
            suffix = "mid_layer" if transparent_bg else "geometric"
            path = f"geometric_{suffix}_{ts}.{'gif' if is_video else 'png'}"

            if is_video and len(frames) > 1:
                frames[0].save(path, save_all=True, append_images=frames[1:], duration=120, loop=0)
            else:
                final = frames[0]
                if layer_opacity < 255:
                    if final.mode != "RGBA":
                        final = final.convert("RGBA")
                    alpha = Image.new("L", final.size, layer_opacity)
                    final.putalpha(alpha)
                final.save(path, quality=90)

            logger.info(f"[Geometric] حفظ → {path}")
            return str(path)

        except Exception as e:
            logger.exception("[Geometric _create_simple_image] فشل")
            return None
    
# ────────────────────────────────────────────────
#              اختبار سريع (اختياري)
# ────────────────────────────────────────────────
if __name__ == "__main__":
    eng = geometric_design_engine()
    eng.receive_input("golden spiral sacred geometry metallic gold")
    res = eng.generate_image(as_layer=False)
    print(res)
    engine = geometric_design_engine()

    engine.receive_input("symmetrical hexagonal pattern with golden ratio spiral and mirrored grid structure")
    engine.add_task("base_hexagon", complexity=2.8)
    engine.add_task("spiral_overlay", complexity=3.2, dependencies=["base_hexagon"])
    engine.add_task("mirror_symmetry", complexity=2.5, dependencies=["base_hexagon"])

    result: GenerationResult = engine.generate_image(force_refresh=True)

    print("\nنتيجة التوليد:")
    print(f"نجاح: {result.success}")
    print(f"رسالة: {result.message}")
    print(f"الوقت الكلي: {result.total_time:.2f} ث")
    print(f"أوقات المراحل: {result.stage_times}")
    print(f"التخصص: {result.specialization}")
    print(f"بيانات الإخراج: {result.output_data}")
    print(f"المهام النهائية: {engine.get_tasks()}")
    print(f"البيانات النهائية للمهام: {engine.last_task_data}")