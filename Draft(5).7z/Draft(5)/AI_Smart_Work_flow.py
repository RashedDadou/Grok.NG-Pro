import time
from typing import List, Dict
import logging
from Plane_Layer import PlaneLayer

# تهيئة السجل (Logging) لتتبع العملية
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

class AISmartWorkflow:
    def __init__(self):
        self.rendering_tasks = []
        self.dependencies = {}                  # task_name → list of dependencies
        self.integration_rules = {}             # tuple(sorted(group)) → priority
        self.plane_definitions = {}             # task_name → {"position": (x,y,z), "size": float}   # أسطح مرجعية تلقائية
        self.render_time = 0.0
        
    def add_task(
        self,
        task_name: str,
        complexity: float,
        dependencies: List[str] = None,
        is_plane: bool = False,
        position: tuple = (0.0, 0.0, 0.0),   # اختياري
        force: float = 1.0,                  # اختياري
    ):
        task = {
            "name": task_name,
            "complexity": complexity,
            "is_plane": is_plane
        }
        self.rendering_tasks.append(task)
        
        deps = dependencies or []
        self.dependencies[task_name] = deps
        
        if is_plane:
            # إنشاء كائن PlaneLayer حقيقي
            self.plane_definitions[task_name] = PlaneLayer(
                position=position,
                force=force,
                label=task_name,           # اسم المهمة كـ label
                mass=1.0                   # أو أي قيمة
            )
        
    def set_integration_rule(self, group: List[str], priority: int):
        """
        تحديد قواعد الدمج الذكي بين مجموعة مهام.
        
        يتم تخزين المجموعة كـ tuple مرتب لضمان عدم التكرار والتوافق.
        الـ priority: كلما كان الرقم أصغر كلما كانت الأولوية أعلى في الدمج.
        يدعم دمج أي مهام (بما فيها الـ Planes إذا أُضيفت سابقًا عبر add_task).
        """
        if not group:
            logging.warning("تم تمرير مجموعة دمج فارغة – سيتم تجاهلها")
            return
        
        sorted_group = tuple(sorted(group))
        self.integration_rules[sorted_group] = priority
    
    def optimize_sequence(self):
        """تحسين التسلسل مع إنشاء الـ Plane أولاً ثم الدمج"""
        optimized_sequence = []
        processed = set()

        # الخطوة 1: معالجة جميع الـ Planes أولاً (أولوية مطلقة)
        for task in self.rendering_tasks:
            if task.get("is_plane") and task["name"] not in processed:
                optimized_sequence.append([task["name"]])
                processed.add(task["name"])

        # الخطوة 2: محاولة دمج المجموعات حسب الأولوية (فقط إذا كانت كل dependencies جاهزة)
        for group_tuple, priority in sorted(self.integration_rules.items(), key=lambda x: x[1]):
            group = list(group_tuple)
            # الشرط الصحيح: هل كل عنصر في المجموعة تم معالجته مسبقًا (في processed)؟
            if all(t in processed for t in group):
                optimized_sequence.append(group)
                processed.update(group)

        # الخطوة 3: إضافة الباقي فرديًا (اللي ما دخل في دمج)
        for task in self.rendering_tasks:
            name = task["name"]
            if name not in processed:
                optimized_sequence.append([name])
                processed.add(name)  # للتأكد من عدم التكرار

        return optimized_sequence

    def render_sequentially(self):
        """تنفيذ التوليد مع إنشاء الـ Plane وتكامل ذكي"""
        sequence = self.optimize_sequence()
        total_time = 0.0

        for step in sequence:
            if len(step) > 1:
                # دمج الأجزاء
                logging.info(f"Rendering integrated group: {', '.join(step)}")
                # جمع التعقيد بأمان (نتجاهل أي task غير موجود أو تالف)
                complexities = [t["complexity"] for t in self.rendering_tasks 
                                if t["name"] in step and isinstance(t.get("complexity"), (int, float))]
                raw_time = sum(complexities)
                render_time = raw_time * 0.9  # خصم 10% للدمج
            else:
                # جزء منفصل أو Plane
                name = step[0]
                task = next((t for t in self.rendering_tasks if t["name"] == name), None)
                
                if task is None:
                    logging.warning(f"Task '{name}' not found in rendering_tasks")
                    render_time = 0.0
                else:
                    comp = task.get("complexity", 0.0)
                    if not isinstance(comp, (int, float)):
                        logging.warning(f"Invalid complexity for '{name}': {comp}")
                        render_time = 0.0
                    else:
                        render_time = comp * 0.8 if task.get("is_plane", False) else comp

            logging.info(f"Processing {', '.join(step)} - Estimated time: {render_time:.1f} seconds")
            time.sleep(render_time)  # محاكاة الوقت
            total_time += render_time

        self.render_time = total_time
        logging.info(f"Total rendering time: {total_time:.1f} seconds")
        return total_time

# ────────────────────────────────────────────────────────────────
# مثال 3: سلسلة Planes طويلة (room → cup → hand → mouth) + دمج الجسم والعيون
# ────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    workflow = AISmartWorkflow()

    # إضافة المهام مع الـ Plane التلقائي
    workflow.add_task("room", complexity=5, dependencies=[])  # الغرفة منفصلة
    workflow.add_task("cup_plane", complexity=2, is_plane=True, dependencies=["room"])  # سطح للفنجان
    workflow.add_task("hand_plane", complexity=2, is_plane=True, dependencies=["cup_plane"])  # سطح لليد
    workflow.add_task("mouth_plane", complexity=2, is_plane=True, dependencies=["hand_plane"])  # سطح للفم
    workflow.add_task("man_body", complexity=5, dependencies=["room", "mouth_plane"])
    workflow.add_task("eye_rigging", complexity=4, dependencies=["mouth_plane", "cup_plane"])

    # تحديد قواعد الدمج الذكي
    workflow.set_integration_rule(["man_body", "eye_rigging"], priority=1)

    # تنفيذ التوليد
    total_time = workflow.render_sequentially()
    print(f"Rendering completed in {total_time:.1f} seconds with Plane and AI.swp.")