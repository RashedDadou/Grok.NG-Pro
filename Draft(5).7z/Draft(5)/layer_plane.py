# layer_plane.py
"""
موديول PlaneLayer – طبقات مرجعية مع تفاعلات فيزيائية/عاطفية مبسطة
يُستخدم كأساس لمحاكاة التدفق (hand → cup → face/mouth) في AI.swp
"""

from __future__ import annotations
import numpy as np
from typing import List, Dict, Any
from typing import Tuple, Union, Optional, List, Dict
import matplotlib.pyplot as plt
    
from environment_design_engine import environment_design_engine
from geometric_design_engine import geometric_design_engine
from traditional_design_engine import traditionalDesignEngine
        
class PlaneLayer:
    def __init__(
        self,
        position: Union[list, tuple, np.ndarray],
        force: float = 1.0,
        depth: float = 1.0,
        label: str = "",
        color: str = "gray",           # للاستخدام في الرسم لاحقًا
        mass: float = 1.0,             # كتلة افتراضية (للحركة المستقبلية)
    ):
        """
        Args:
            position: إحداثيات [x, y, z] أو [x, y]
            force: قوة التأثير / الجاذبية النسبية (كجم أو وحدة تعسفية)
            depth: عمق الطبقة (سم) – يؤثر على "الوزن" أحيانًا
            label: اسم وصفي (hand, cup, mouth, ...)
            color: لون تمثيلي للـ visualization
            mass: كتلة لاستخدامها في حساب التسارع لاحقًا
        """
        self.position = np.array(position, dtype=float)
        if self.position.shape not in ((2,), (3,)):
            raise ValueError("position يجب أن يكون 2 أو 3 أبعاد")

        self.force = float(force)
        self.depth = float(depth)
        self.label = str(label)
        self.color = str(color)
        self.mass = float(mass)

        # لتتبع الحركة في المحاكاة (اختياري)
        self.velocity = np.zeros_like(self.position)
        self.trail: list = [self.position.copy()[:2]]  # فقط x,y للرسم 2D

    def distance_to(self, other: 'PlaneLayer') -> float:
        """المسافة الإقليدية إلى طبقة أخرى"""
        return np.linalg.norm(self.position - other.position)

    def raw_interaction(self, other: 'PlaneLayer') -> float:
        """
        القوة التفاعلية الأساسية (مشابهة لقانون الجاذبية / كولوم المبسط)
        """
        dist = self.distance_to(other)
        return (self.force + other.force) / (dist + 1e-5)

    def x2_effect(self, other: 'PlaneLayer') -> float:
        raw = self.raw_interaction(other)
        return raw ** 2 * 0.5 + raw   # مزيج خطي + تربيعي

    def extract_entities_simple(prompt: str) -> List[str]:
        """تقسيم بسيط جدًا – يمكن تحسينه بـ LLM أو spacy لاحقًا"""
        words = prompt.replace(",", " ").replace(" و ", " ").split()
        entities = [w for w in words if len(w) > 3 and w.lower() not in {"with", "and", "in", "on", "at"}]
        return entities or ["element"]

    def apply_force(self, force_vector: np.ndarray, dt: float = 0.05, damping: float = 0.92):
        acceleration = force_vector / self.mass
        self.velocity += acceleration * dt
        self.velocity *= damping          # ← يقلل السرعة تدريجيًا
        self.position += self.velocity * dt
        self.trail.append(self.position.copy()[:2])
        if len(self.trail) > 80:
            self.trail.pop(0)

    def total_influence_from(self, others: list['PlaneLayer']) -> float:
        return sum(self.x2_effect(other) for other in others)

    def __repr__(self):
        return (f"PlaneLayer({self.label!r} | pos={self.position} | "
                f"force={self.force:.2f} | depth={self.depth:.2f} | {self.color})")

    def __str__(self) -> str:
        return f"{self.label} @ {self.position.round(2)} (force={self.force:.2f})"

class LayerComposer:
    """مسؤول عن تجميع طبقات من المحركات المختلفة + محاكاة التفاعلات الأولية"""

    def __init__(self, engine_registry: dict = None):
        self.engine_registry = engine_registry or {
            "environment": lambda: environment_design_engine(),
            "traditional": lambda: traditional_design_engine(),
            "geometric":   lambda: geometric_design_engine(),
        }
        self.z_levels = {
            "environment": -1.0,
            "geometric":    0.0,
            "traditional":  1.0,
        }

    def compose_from_prompts(
        self,
        prompts: dict[str, str],               # {"environment": "...", "traditional": "...", ...}
        global_seed: int = 42,
        collision_threshold: float = 0.8,
        emotional_amplifier: float = 2.0,
    ) -> List[PlaneLayer]:
        np.random.seed(global_seed)
        layers: List[PlaneLayer] = []

        for name, prompt in prompts.items():
            if name not in self.engine_registry:
                continue

            try:
                engine = self.engine_registry[name]()
                # هنا ممكن نستدعي engine.design(prompt) أو engine.generate_layer(prompt)
                # ونحصل على نتيجة حقيقية بدل التحليل الوهمي
            except Exception as e:
                print(f"فشل محرك {name}: {e}")
                continue

            # مؤقت: التحليل البسيط
            entities = self._extract_entities(prompt)

            base_z = self.z_levels.get(name, 0.0)
            for entity in entities:
                z = base_z + np.random.uniform(-0.12, 0.12)
                layer = PlaneLayer(
                    position=[np.random.uniform(-1.6, 1.6),
                              np.random.uniform(-0.9, 0.9),
                              z],
                    force=1.0 + len(entity) * 0.2,
                    label=f"{name}::{entity[:15]}",
                    # ... باقي الباراميترات
                )
                layers.append(layer)

        layers.sort(key=lambda p: p.position[2])

        # محاكاة التصادمات (يمكن نقلها لكلاس SimulationStep لاحقاً)
        self._apply_initial_collisions(layers, collision_threshold, emotional_amplifier)

        return layers

    def _extract_entities(self, prompt: str) -> list[str]:
        # يمكن تحسينها لاحقاً (regex / LLM / spacy / noun chunking)
        return [w for w in prompt.split() if len(w) > 3 and w.lower() not in {"in", "on", "with", "and"}]

    def _apply_initial_collisions(self, layers: List[PlaneLayer], threshold: float, amp: float):
        for i in range(len(layers)):
            for j in range(i + 1, len(layers)):
                p1, p2 = layers[i], layers[j]
                dist = p1.distance_to(p2)
                if dist < threshold:
                    # نفس منطق التصادم السابق ...
                    pass

# ────────────────────────────────────────────────
# مثال استخدام سريع (للاختبار عند تشغيل الملف مباشرة)
# ────────────────────────────────────────────────

if __name__ == "__main__":

    # إنشاء طبقات
    hand = PlaneLayer([0.0, 0.0, 0.0], force=0.35, label="Hand", color="sienna")
    cup  = PlaneLayer([1.2, 0.3, 0.0], force=0.50, label="Cup",  color="cyan")
    face = PlaneLayer([3.5, 0.0, 0.5], force=0.10, label="Face", color="lightpink")

    # حساب التفاعلات
    hc = hand.x2_effect(cup)
    cf = cup.x2_effect(face)
    total_motion = hc + cf

    print(f"Hand → Cup (x²): {hc:.3f}")
    print(f"Cup → Face (x²): {cf:.3f}")
    print(f"Total motion influence: {total_motion:.3f}")

    # رسم بسيط للمواقع + trail افتراضي
    fig, ax = plt.subplots(figsize=(9, 4))
    for layer in [hand, cup, face]:
        ax.scatter(*layer.position[:2], s=180, c=layer.color, label=layer.label, zorder=10)
        ax.text(*layer.position[:2] + 0.15, layer.label, fontsize=10)

    ax.plot([hand.position[0], cup.position[0]], [hand.position[1], cup.position[1]], '--', c='gray', alpha=0.5)
    ax.plot([cup.position[0], face.position[0]], [cup.position[1], face.position[1]], '--', c='gray', alpha=0.5)

    ax.set_title("Plane.x² Effect – Initial Positions")
    ax.set_xlabel("X")
    ax.set_ylabel("Y")
    ax.legend()
    ax.grid(True, alpha=0.3)
    plt.show()
    
    
    layer_plane = PlaneLayer([0, 0, 0], force=1.0, depth=1.0, label="Example Layer", color="blue")
    print(layer_plane)