# layer_plane.py
"""
موديول PlaneLayer – طبقات مرجعية مع تفاعلات فيزيائية/عاطفية مبسطة
يُستخدم كأساس لمحاكاة التدفق (hand → cup → face/mouth) في AI.swp
"""

import numpy as np
from typing import Tuple, Union, Optional, List, Dict
import matplotlib.pyplot as plt
    
class PlaneLayer:
    """
    طبقة مرجعية (reference plane) تحمل موقعًا في الفضاء، قوة تأثير، وعمق.
    تدعم تفاعلات متسلسلة مع عامل تضخيم (x² effect).
    """

    def __init__(
        self,
        position: Union[list, tuple, np.ndarray],
        force: float = 1.0,
        depth: float = 1.0,
        label: str = "",
        color: str = "gray",           # للاستخدام في الرسم لاحقًا
        mass: float = 1.0,             # كتلة افتراضية (للحركة المستقبلية)
    ):
        """
        Args:
            position: إحداثيات [x, y, z] أو [x, y]
            force: قوة التأثير / الجاذبية النسبية (كجم أو وحدة تعسفية)
            depth: عمق الطبقة (سم) – يؤثر على "الوزن" أحيانًا
            label: اسم وصفي (hand, cup, mouth, ...)
            color: لون تمثيلي للـ visualization
            mass: كتلة لاستخدامها في حساب التسارع لاحقًا
        """
        self.position = np.array(position, dtype=float)
        if self.position.shape not in ((2,), (3,)):
            raise ValueError("position يجب أن يكون 2 أو 3 أبعاد")

        self.force = float(force)
        self.depth = float(depth)
        self.label = str(label)
        self.color = str(color)
        self.mass = float(mass)

        # لتتبع الحركة في المحاكاة (اختياري)
        self.velocity = np.zeros_like(self.position)
        self.trail: list = [self.position.copy()[:2]]  # فقط x,y للرسم 2D

    def distance_to(self, other: 'PlaneLayer') -> float:
        """المسافة الإقليدية إلى طبقة أخرى"""
        return np.linalg.norm(self.position - other.position)

    def raw_interaction(self, other: 'PlaneLayer') -> float:
        """
        القوة التفاعلية الأساسية (مشابهة لقانون الجاذبية / كولوم المبسط)
        """
        dist = self.distance_to(other)
        return (self.force + other.force) / (dist + 1e-5)

    def x2_effect(self, other: 'PlaneLayer') -> float:
        """
        plane.x² effected: التأثير المضاعف (القيمة × 2)
        يمثل التضخيم العاطفي/السينمائي في التسلسل
        """
        return self.raw_interaction(other) * 2.0

    def compose_layers_from_engines(
        env_prompt: str,
        trad_prompt: str,
        geo_prompt: str,
        global_seed: int = 42,
        collision_threshold: float = 0.8,
        emotional_amplifier: float = 2.0  # قوة x² effect
    ) -> List[PlaneLayer]:
        """
        الدالة الرئيسية: تجمع طبقات من المحركات الثلاثة وتضع قطع planes بينها
        
        Args:
            env_prompt: وصف البيئة
            trad_prompt: وصف الكائنات الحية / الشخصيات
            geo_prompt: وصف الأشكال الهندسية / الهياكل
            global_seed: للتكرارية في التوليد
            collision_threshold: عتبة المسافة التي تعتبر تصادم (في وحدات normalized)
            emotional_amplifier: مضاعف التأثير العاطفي (x² effect)

        Returns:
            قائمة PlaneLayer مرتبة حسب العمق (z) وجاهزة للدمج / الرسم
        """
        np.random.seed(global_seed)

        layers: List[PlaneLayer] = []

        # 1. جمع الطبقات من كل محرك
        engines = {
            "environment": EnvironmentDesignEngine(),
            "traditional": TraditionalDesignEngine(),
            "geometric": GeometricDesignEngine()
        }

        prompts = {
            "environment": env_prompt,
            "traditional": trad_prompt,
            "geometric": geo_prompt
        }

        for name, engine in engines.items():
            # افتراض أن كل محرك لديه دالة analyze_and_get_layers
            # (لو مش موجودة، يمكن استبدالها بـ _analyze_prompt + تحويل)
            result = engine._analyze_prompt(prompts[name])  # ← يرجع dict
            
            # تحويل النتيجة إلى PlaneLayer (مثال مبسط – يحتاج تخصيص)
            for entity in result.get("entities", []):
                # موقع افتراضي + قوة حسب نوع المحرك
                z_base = {
                    "environment": 0.0,   # خلفية
                    "geometric": 0.5,     # وسط
                    "traditional": 1.0    # مقدمة
                }[name]

                layer = PlaneLayer(
                    position=[np.random.uniform(-2, 2), np.random.uniform(-1, 1), z_base],
                    force=1.0 + len(entity) * 0.3,
                    depth=1.0,
                    label=f"{name}_{entity}",
                    color="gray",  # يمكن تخصيصه لاحقًا
                    mass=1.0 + len(entity) * 0.2
                )
                layers.append(layer)

        # 2. ترتيب الطبقات حسب العمق (z)
        layers.sort(key=lambda p: p.position[2])

        # 3. وضع قطع planes بين المجسمات (collision & force application)
        for i in range(len(layers)):
            for j in range(i + 1, len(layers)):
                p1 = layers[i]
                p2 = layers[j]

                dist = p1.distance_to(p2)
                if dist < collision_threshold:
                    # تصادم → تطبيق قوة متبادلة + تضخيم عاطفي
                    force_vec = (p2.position - p1.position) / (dist + 1e-6)
                    strength = p1.force * p2.force * emotional_amplifier

                    # تطبيق القوة (محاكاة رد فعل)
                    p1.apply_force(-force_vec * strength, dt=0.1)
                    p2.apply_force(force_vec * strength * 0.8, dt=0.1)

                    print(f"Collision detected: {p1.label} ↔ {p2.label} | dist={dist:.3f} | force={strength:.3f}")

        return layers

    def apply_force(self, force_vector: np.ndarray, dt: float = 0.05):
        """
        تطبيق قوة خارجية → تحديث السرعة والموقع (محاكاة حركة بسيطة)
        """
        acceleration = force_vector / self.mass
        self.velocity += acceleration * dt
        self.position += self.velocity * dt
        # تحديث الـ trail (فقط x,y)
        self.trail.append(self.position.copy()[:2])
        if len(self.trail) > 80:
            self.trail.pop(0)

    def __repr__(self) -> str:
        pos_str = f"[{', '.join(f'{x:.2f}' for x in self.position)}]"
        return f"<PlaneLayer '{self.label}' pos={pos_str} force={self.force:.2f}>"

    def __str__(self) -> str:
        return f"{self.label} @ {self.position.round(2)} (force={self.force:.2f})"


# ────────────────────────────────────────────────
# مثال استخدام سريع (للاختبار عند تشغيل الملف مباشرة)
# ────────────────────────────────────────────────

if __name__ == "__main__":

    # إنشاء طبقات
    hand = PlaneLayer([0.0, 0.0, 0.0], force=0.35, label="Hand", color="sienna")
    cup  = PlaneLayer([1.2, 0.3, 0.0], force=0.50, label="Cup",  color="cyan")
    face = PlaneLayer([3.5, 0.0, 0.5], force=0.10, label="Face", color="lightpink")

    # حساب التفاعلات
    hc = hand.x2_effect(cup)
    cf = cup.x2_effect(face)
    total_motion = hc + cf

    print(f"Hand → Cup (x²): {hc:.3f}")
    print(f"Cup → Face (x²): {cf:.3f}")
    print(f"Total motion influence: {total_motion:.3f}")

    # رسم بسيط للمواقع + trail افتراضي
    fig, ax = plt.subplots(figsize=(9, 4))
    for layer in [hand, cup, face]:
        ax.scatter(*layer.position[:2], s=180, c=layer.color, label=layer.label, zorder=10)
        ax.text(*layer.position[:2] + 0.15, layer.label, fontsize=10)

    ax.plot([hand.position[0], cup.position[0]], [hand.position[1], cup.position[1]], '--', c='gray', alpha=0.5)
    ax.plot([cup.position[0], face.position[0]], [cup.position[1], face.position[1]], '--', c='gray', alpha=0.5)

    ax.set_title("Plane.x² Effect – Initial Positions")
    ax.set_xlabel("X")
    ax.set_ylabel("Y")
    ax.legend()
    ax.grid(True, alpha=0.3)
    plt.show()
    
    
    layer_plane = PlaneLayer([0, 0, 0], force=1.0, depth=1.0, label="Example Layer", color="blue")
    print(layer_plane)