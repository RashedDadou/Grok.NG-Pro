# environment_design_engine.py
"""
محرك تصميم البيئة: مسؤول عن إنشاء طبقة خلفية / بيئية بناءً على وصف نصي
يأخذ وصفاً نصياً (عربي أو إنجليزي أو مختلط) وينتج طبقة بيئية (PlaneLayer) تحتوي على عناصر مثل الإضاءة، الجو، التضاريس، السماء، إلخ
يستخدم تقنيات مختلفة (مثل استدعاء API خارجي، أو توليد إجرائي، أو حتى LLM خفيف لتحسين الوصف) لتحقيق أفضل نتيجة ممكنة
يرجع نتيجة منظمة (EnvironmentDesignResult) تحتوي على الطبقة + البيانات الوصفية المفيدة للتوليد النهائي أو التوثيق
"""

from typing import Dict, Any, Optional, Tuple
from dataclasses import dataclass
# من المفترض أن تكون موجودة في المشروع
from memory_manager import GenerativeMemoryManager
from layer_plane import PlaneLayer


@dataclass
class EnvironmentDesignResult:
    """المخرج المنظم الذي ينتظره المحرك النهائي"""
    success: bool
    layer: Optional[PlaneLayer]               # الطبقة الفعلية (إذا تم إنشاؤها)
    enhanced_description: str                 # الوصف المحسن (للتوثيق أو للـ prompt النهائي)
    metadata: Dict[str, Any]                  # معلومات مساعدة (إضاءة، عمق، طقس، إلخ)
    reference_path: Optional[str] = None      # مسار صورة مرجعية إن وجدت (مؤقتة)
    message: str = ""
    design_time_seconds: float = 0.0

class environment_design_engine:
    """
    مسؤول عن **تصميم البيئة فقط** (إنشاء طبقة خلفية / بيئية)
    لا يهتم بالشخصيات أو الأشياء الأمامية أو التجميع النهائي
    يرجع نتيجة منظمة يفهمها Final_Generation أو Layer Compositor
    """

    def __init__(self):
        self.memory_manager = GenerativeMemoryManager(context_type="environment")
        self.temp_files: list[str] = []

        self.specialization = {
            "domain": "environment",
            "supported_aspects": [
                "lighting", "atmosphere", "weather", "terrain", "sky", "fog", "depth", "color_grading"
            ],
            "typical_output": "background_layer / environment_plane"
        }

    def create_environment(
        self,
        description: str,
        resolution: tuple = (1920, 1080),
        is_looping: bool = False,
        duration_sec: float = 10.0,
        **kwargs
    ):
        """
        الدالة الرئيسية التي تنتج البيئة
        الوصف يأتي جاهزاً
        """
        # مثال على هيكلية منطقية (بدون فرض أي تقنية معينة)
        
        env_type = self._classify_environment(description)
        
        if env_type == "cyberpunk_city":
            return self._generate_cyberpunk_city(description, resolution, **kwargs)
            
        elif env_type == "natural_forest":
            return self._generate_forest_scene(description, resolution, **kwargs)
            
        elif env_type == "space_nebula":
            return self._generate_space_background(description, resolution, **kwargs)
            
        else:
            return self._fallback_generation(description, resolution, **kwargs)

    def _classify_environment(self, desc: str) -> str:
        # تصنيف بسيط جداً (يمكن استبداله بأي طريقة أنت تفضلها)
        lower = desc.lower()
        if "cyber" in lower or "نيون" in lower or "سايبر" in lower:
            return "cyberpunk_city"
        if "غابة" in lower or "forest" in lower:
            return "natural_forest"
        if "فضاء" in lower or "nebula" in lower:
            return "space_nebula"
        return "generic"

    def _generate_cyberpunk_city(self, desc, resolution, **kwargs):
        # هنا تضع الكود الفعلي الذي ينتج البيئة
        # (سواء كان استدعاء API خارجي، أو procedural generation، أو أي شيء)
        raise NotImplementedError("يجب تنفيذ توليد مدينة سايبر")

    def design(
        self,
        description: str,
        target_resolution: Tuple[int, int] = (1024, 768),
        style_hints: Optional[list[str]] = None,
        is_video: bool = False,
        **kwargs
    ) -> EnvironmentDesignResult:
        """
        الواجهة الرئيسية الوحيدة المفضلة
        
        Args:
            description: وصف البيئة (عربي أو إنجليزي أو مختلط)
            target_resolution: الأبعاد المطلوبة
            style_hints: كلمات مفتاحية إضافية (cyberpunk, cinematic, realistic, ...)
            is_video: هل المطلوب بيئة متحركة (مثلاً looping background)
        
        Returns:
            EnvironmentDesignResult منظم يحتوي على الطبقة + البيانات الوصفية
        """
        start_time = perf_counter()

        # 1. تنظيف وتحليل الوصف الأولي
        clean_desc = (description or "").strip()
        if not clean_desc:
            return EnvironmentDesignResult(
                success=False,
                layer=None,
                enhanced_description="",
                metadata={},
                message="وصف البيئة فارغ",
                design_time_seconds=0.0
            )

        analysis = self._analyze_environment_description(clean_desc)

        # 2. تحسين/توسيع الوصف (اختياري – قواعد أو LLM خفيف)
        enhanced = self._build_detailed_environment_prompt(
            clean_desc,
            analysis,
            style_hints or [],
            is_video
        )

        # 3. التصميم الفعلي ← هنا يحدث الإبداع الحقيقي
        design_result = self._execute_environment_design(
            enhanced_prompt=enhanced["prompt"],
            resolution=target_resolution,
            is_video=is_video,
            analysis=analysis,
            **kwargs
        )

        total_time = perf_counter() - start_time

        return EnvironmentDesignResult(
            success=design_result["success"],
            layer=design_result.get("layer"),
            enhanced_description=enhanced["prompt"],
            metadata={
                **analysis,
                **enhanced.get("metadata", {}),
                "design_style": style_hints,
                "is_video": is_video,
                "resolution_used": target_resolution
            },
            reference_path=design_result.get("reference_path"),
            message=design_result.get("message", "تم تصميم البيئة"),
            design_time_seconds=total_time
        )

    def generate_layer(self, prompt: str, **kwargs) -> GenerationResult:
        # ... عملية التوليد ...

        result = GenerationResult(...)  # النتيجة النهائية

        if result.success:
            # 1. إنعاش قبل التخزين
            pre_report = self.memory_manager.refresh_layer_before_and_after_storage(
                layer_result=result,
                layer_name="environment",
                stage="before",
                prompt_hash=self.memory_manager.get_prompt_hash(prompt)
            )

            # 2. التخزين الأصلي
            self.memory_manager.save_raw_layer(
                prompt_hash=...,
                layer_name="environment",
                layer_result=result
            )

            # 3. إنعاش بعد التخزين (اختياري – للتأكد من سلامة الملف بعد الكتابة)
            post_report = self.memory_manager.refresh_layer_before_and_after_storage(
                layer_result=result,
                layer_name="environment",
                stage="after",
                prompt_hash=...
            )

        return result

    def _analyze_environment_description(self, text: str) -> Dict[str, Any]:
        """تحليل خفيف لفهم نوع البيئة والعناصر المهمة"""
        # يمكن توسيعه لاحقاً (keywords, regex, أو حتى LLM صغير)
        lower = text.lower()
        result = {
            "mood": "neutral",
            "key_elements": [],
            "weather": None,
            "time_of_day": None,
            "lighting_type": "natural"
        }

        if any(w in lower for w in ["cyber", "سايبر", "neon", "نيون"]):
            result["mood"] = "cyberpunk"
            result["lighting_type"] = "neon"

        if any(w in lower for w in ["مطر", "rain", "ضباب", "fog"]):
            result["weather"] = "rainy/foggy"

        # ... باقي الحالات

        return result

    def _build_detailed_environment_prompt(self, base: str, analysis: dict, style_hints: list, is_video: bool) -> dict:
        """بناء prompt محسن للتصميم (قد يذهب لـ SD/Flux/أي مولد لاحقاً)"""
        parts = [base]

        if analysis["mood"] != "neutral":
            parts.append(f"{analysis['mood']} atmosphere, strong mood")

        if analysis["weather"]:
            parts.append(f"{analysis['weather']}, wet surfaces, volumetric fog")

        if is_video:
            parts.append("subtle parallax motion, gentle wind, looping background")

        parts.extend(style_hints)
        parts.append("ultra detailed environment background, cinematic, 8k")

        return {
            "prompt": ", ".join(parts),
            "metadata": {"expanded_from": len(base), "added_aspects": len(parts)-1}
        }

    def _execute_environment_design(self, enhanced_prompt: str, resolution: tuple, is_video: bool, analysis: dict, **kwargs) -> dict:
        """
        هنا يحدث التصميم الفعلي.
        في الوقت الحالي: placeholder — يجب استبداله ب:
        • استدعاء مولد صور (SD, Flux, SDXL, ...)
        • أو إنشاء طبقة بـ procedural generation
        • أو توليد بيانات 3D / heightmap / إلخ
        """
        # مثال placeholder بسيط جداً — يجب استبداله
        return {
            "success": True,
            "layer": None,  # ← يجب أن يكون PlaneLayer حقيقي لاحقاً
            "reference_path": None,
            "message": "تصميم placeholder — في انتظار المولد الحقيقي"
        }
        
    def export_design_result(
        self,
        result: GenerationResult,
        export_format: str = "json",
        save_to_disk: bool = False,
        output_dir: str = "exported_designs",
        include_preview: bool = False
    ) -> Dict[str, Any]:
        """
        تصدير نتيجة تصميم البيئة كبيانات محفوظة / قابلة للنقل
        
        Parameters:
            result: كائن GenerationResult الذي أرجعته generate_layer أو generate_image
            export_format: "json" أو "dict" (في المستقبل يمكن إضافة yaml, pickle...)
            save_to_disk: هل نحفظ الملف على القرص؟
            output_dir: المجلد الذي سيتم الحفظ فيه إذا تم تفعيل save_to_disk
            include_preview: هل نضيف مسار المعاينة / الصورة إذا كان موجوداً؟
        
        Returns:
            dict يحتوي على البيانات المنظمة
        """
        if not result or not result.success:
            return {
                "success": False,
                "error": result.message if result else "No result object provided",
                "exported_at": datetime.utcnow().isoformat()
            }

        exported = {
            "success": result.success,
            "specialization": result.specialization,
            "exported_at": datetime.utcnow().isoformat(),
            "total_time_seconds": round(result.total_time, 3),
            "stage_times": result.stage_times,
            "is_video": result.is_video,
            "metadata": result.output_data.get("metadata", {}) if result.output_data else {},
            "notes": result.output_data.get("notes", []) if result.output_data else [],
        }

        # إضافة الـ prompt المحسن إذا وُجد
        if "enhanced_prompt" in result.output_data or "prompt" in result.output_data:
            exported["enhanced_prompt"] = (
                result.output_data.get("enhanced_prompt") or
                result.output_data.get("prompt", "")
            )

        # إضافة مسار المعاينة / الطبقة إذا طُلب وكان موجوداً
        if include_preview and result.output_data:
            for key in ["preview_path", "path", "layer_path", "output_path"]:
                if key in result.output_data and Path(result.output_data[key]).exists():
                    exported["preview_path"] = result.output_data[key]
                    break

        # تحويل إلى الشكل المطلوب
        if export_format.lower() == "json":
            exported_str = json.dumps(exported, ensure_ascii=False, indent=2)
            if save_to_disk:
                Path(output_dir).mkdir(exist_ok=True)
                timestamp = datetime.utcnow().strftime("%Y%m%d_%H%M%S")
                filename = f"env_design_{timestamp}.json"
                full_path = Path(output_dir) / filename
                full_path.write_text(exported_str, encoding="utf-8")
                exported["saved_file"] = str(full_path)
            return {"json": exported_str, **exported}

        # الافتراضي: نرجع dict خام
        if save_to_disk:
            # يمكن توسيع هنا لاحقاً لحفظ dict أو pickle أو غيره
            pass

        return exported
