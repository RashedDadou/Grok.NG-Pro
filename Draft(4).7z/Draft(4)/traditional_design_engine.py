# في traditional_design_engine.py

from typing import Dict, Any, Optional, List
from datetime import datetime
from PIL import Image, ImageDraw
import random
import logging
import math
from pathlib import Path
from time import perf_counter
from PIL import Image, ImageDraw, ImageFont

from layer_engine import LayerEngine  # أو المسار الصحيح
from typing import Tuple  # لو مش موجود

# الاستيراد الوحيد المهم (من الكور)
from Core_Image_Generation_Engine import CoreImageGenerationEngine
from memory_manager import GenerativeMemoryManager
from Image_generation import GenerationResult

print("تم تحميل traditional_design_engine.py")

logger = logging.getLogger(__name__)

from typing import List, Dict, Any, Optional
from copy import deepcopy

class TraditionalDesignEngine (LayerEngine, CoreImageGenerationEngine):
    """
    محرك متخصص في تحليل وتحسين وصف الكائنات التقليدية / العضوية فقط.
    الإخراج الرئيسي: dict نصي محسن + metadata
    لا يتدخل في توليد الصور النهائية (دور Final_Generation)
    """

    def __init__(self):
        # الحالة الأساسية المطلوبة فقط
        self.input_port: List[str] = []                     # الوصف المتراكم من المستخدم
        self.memory_manager = GenerativeMemoryManager()
        
        # التخصص البسيط والمحدث (لا حاجة لـ units أو وراثة معقدة)
        self.specialization = {
            "name": "traditional_design",
            "description": "تصاميم تقليدية عضوية، كائنات حية، شخصيات، حيوانات، مخلوقات أسطورية، تفاصيل تشريحية وعاطفية",
            "keywords": [
                "creature", "animal", "monster", "beast", "character", "person", "human",
                "girl", "boy", "woman", "man", "child", "فتاة", "ولد", "امرأة", "رجل", "طفل",
                "horse", "dragon", "lion", "wolf", "cat", "dog", "bird", "تنين", "حصان"
            ]
        }

        # قائمة لتتبع أي ملفات مرجعية مؤقتة ينشئها المحرك (اختياري)
        self.temp_files: List[str] = []

        logger.info("[TraditionalEngine] تم تهيئة المحرك بنجاح – وضع نصي فقط")

    def receive_input(self, prompt: str) -> bool:
        """
        تلقي prompt جديد مع التحقق الأساسي
        (حذف التحقق من validate_keywords لأنه كان جزءًا من pipeline قديمة)
        """
        if not isinstance(prompt, str) or not prompt.strip():
            logger.warning("Prompt غير صالح أو فارغ")
            return False

        stripped = prompt.strip()
        self.append_prompt_chunk(stripped)
        logger.info(f"[{self.specialization.get('name', 'unknown')}] received: {stripped[:60]}...")
        return True
    
    def generate_layer(
        self,
        prompt: str,
        target_size: Tuple[int, int] = (1024, 1024),
        is_video: bool = False,
        as_layer: bool = True,
        force_refresh: bool = False,
        **kwargs
    ) -> GenerationResult:
        """
        الواجهة المفضلة الجديدة – prompt مباشر
        ترجع dict نصي محسن فقط (لا صورة، لا render)
        """
        logger.info(f"[{self.specialization.get('name', 'unknown')}] generate_layer called with prompt: {prompt[:70]}...")

        start = perf_counter()
        enhanced = self._enhance_prompt(prompt, force_refresh=force_refresh)  # دالة تحسين نصية (موجودة سابقًا أو تضاف)

        result = GenerationResult(
            success=True,
            message="تم تحسين الوصف بنجاح (نصي فقط)",
            total_time=perf_counter() - start,
            stage_times={"enhance": perf_counter() - start},
            specialization=self.specialization["name"],
            is_video=is_video,
            output_data={
                "enhanced_prompt": enhanced["prompt"],
                "metadata": enhanced["metadata"],
                "layer_type": "foreground" if "traditional" in self.specialization["name"] else "unknown"
            }
        )

        return result
    
    def generate_image(
        self,
        force_refresh: bool = False,
        as_layer: bool = True,
        target_size: Tuple[int, int] = (1024, 1024),
        reset_input_after: bool = True,
        is_video: bool = False,
        **kwargs
    ) -> GenerationResult:
        """
        الواجهة القديمة للتوافق – تجمع من input_port
        ترجع نفس نتيجة generate_layer (نصي فقط)
        """
        if not self.input_port:
            return GenerationResult(
                success=False,
                message="لا يوجد prompt في input_port",
                total_time=0.0,
                stage_times={},
                specialization=self.specialization["name"]
            )

        full_prompt = " ".join(self.input_port).strip()
        logger.info(f"[{self.specialization.get('name', 'unknown')}] generate_image called – prompt: {full_prompt[:70]}...")

        result = self.generate_layer(
            prompt=full_prompt,
            target_size=target_size,
            is_video=is_video,
            as_layer=as_layer,
            force_refresh=force_refresh,
            **kwargs
        )

        if reset_input_after:
            self.input_port.clear()

        return result
    
    def append_prompt_chunk(self, chunk: str):
        """
        إضافة جزء من الـ prompt إلى المنفذ (بسيط ونظيف)
        """
        if not hasattr(self, "input_port"):
            self.input_port = []
        self.input_port.append(chunk.strip())
        logger.debug(f"Input chunk appended: {chunk[:50]}...")
        
    def add_task(self, task_name: str, complexity: float = 1.0, dependencies: Optional[List[str]] = None):
        """
        إضافة مهمة وصفية بسيطة (اختياري – للتتبع فقط، مش بصري)
        """
        if not hasattr(self, "tasks"):
            self.tasks = []
        self.tasks.append({
            "name": task_name,
            "complexity": complexity,
            "dependencies": dependencies or []
        })
        logger.debug(f"Added task: {task_name} (complexity: {complexity})")

        if not hasattr(self, "tasks"):
            self.tasks = []
        self.tasks.append({"name": task_name, "complexity": complexity, "dependencies": dependencies or []})
  
    def generate_image(
        self,
        force_refresh: bool = False,
        as_layer: bool = True,
        target_size: Tuple[int, int] = (1024, 1024),
        reset_input_after: bool = True,
        is_video: bool = False,
        **kwargs
    ) -> GenerationResult:
        """
        الواجهة القديمة للتوافق – تجمع من input_port
        → تم تنظيفها: ترجع dict نصي محسن فقط (لا صورة، لا حفظ، لا render)
        """
        start_total = perf_counter()
        stage_times = {"enhance": 0.0}

        try:
            if not self.input_port:
                return GenerationResult(
                    success=False,
                    message="لا يوجد prompt في المنفذ",
                    total_time=0.0,
                    stage_times={},
                    specialization=self.specialization["name"],
                    output_data={}
                )

            full_prompt = " ".join(self.input_port).strip()
            logger.info(f"[Traditional generate_image] prompt: {full_prompt[:70]}...")

            # تحليل وتحسين (نصي فقط)
            t_start = perf_counter()
            enhanced = self._enhance_prompt(full_prompt, force_refresh=force_refresh)
            stage_times["enhance"] = perf_counter() - t_start

            # تنظيف creepy إن وجد
            if self.memory_manager.check_for_creepy(full_prompt, enhanced):
                enhanced = self.memory_manager.refresh_memory(full_prompt, enhanced, "traditional")
                logger.info("[Traditional] تم refresh بسبب creepy detection")

            total_time = perf_counter() - start_total

            result = GenerationResult(
                success=True,
                message="تم تحسين وصف الكائن الحي بنجاح (نصي فقط)",
                total_time=total_time,
                stage_times=stage_times,
                specialization=self.specialization["name"],
                is_video=is_video,
                output_data={
                    "enhanced_prompt": enhanced["prompt"],
                    "metadata": enhanced["metadata"],
                    "layer_type": "foreground",
                    "notes": enhanced.get("enhancement_notes", [])
                }
            )

            logger.info(f"[Traditional] نجح (نصي) | وقت: {total_time:.2f} ث")

            if reset_input_after:
                self.input_port.clear()

            return result

        except Exception as e:
            logger.exception("[Traditional generate_image] فشل")
            return GenerationResult(
                success=False,
                message=f"فشل تحسين الوصف: {str(e)}",
                total_time=perf_counter() - start_total,
                stage_times=stage_times,
                specialization=self.specialization["name"],
                output_data={}
            )

    # ────────────────────────────────────────────────
    #              تنفيذ اختياري للـ preview
    # ────────────────────────────────────────────────

    # ────────────────────────────────────────────────────────────────
    #              الـ Overrides الضرورية (في نهاية الكلاس)
    # ────────────────────────────────────────────────────────────────

    def _analyze_prompt(self, prompt: str) -> Dict[str, Any]:
        """
        تحليل الـ prompt لاستخراج الكيانات الرئيسية (كائنات حية فقط) والمزاج.
        ترجع dict نصي نظيف بدون أي مهام أو planes أو استدعاءات محذوفة.
        """
        logger.info(f"[Traditional] تحليل الـ prompt: {prompt[:80]}{'...' if len(prompt)>80 else ''}")

        try:
            if not prompt or not isinstance(prompt, str):
                raise ValueError("الـ prompt فارغ أو غير صالح")

            lower_prompt = prompt.lower()

            entities = []

            # كلمات مفتاحية للكائنات الحية فقط
            creature_keywords = {
                "creature", "animal", "monster", "beast", "character", "person", "human",
                "girl", "boy", "woman", "man", "child", "baby",
                "horse", "dragon", "lion", "wolf", "cat", "dog", "bird", "fish",
                "angel", "demon", "fairy", "elf", "orc", "goblin",
                "فتاة", "ولد", "امرأة", "رجل", "طفل", "حصان", "تنين"
            }

            mood_keywords = {
                "dark", "enchanted", "mystical", "سحرية", "غامض", "ظلام", "ضبابي", "مخيف", "رعب",
                "calm", "peaceful", "beautiful", "نقي", "هادئ", "جميل", "رقيق",
                "epic", "powerful", "majestic", "ملحمي", "قوي", "مهيب"
            }

            # الكشف عن الكيانات
            for kw in creature_keywords:
                if kw in lower_prompt:
                    entities.append(kw)
                    break  # أول تطابق يكفي (يمكن توسيع لاحقًا)

            # تصنيف إضافي بسيط
            if any(kw in lower_prompt for kw in ["human", "person", "إنسان", "فتاة", "girl", "امرأة"]):
                entities.append("humanoid")

            if any(kw in lower_prompt for kw in ["horse", "حصان", "dragon", "تنين", "lion", "أسد"]):
                entities.append("animal")

            # تحديد المزاج (أول تطابق قوي)
            mood = "neutral"
            for m in ["mysterious", "calm", "epic"]:
                if any(kw in lower_prompt for kw in mood_keywords if m in kw):
                    mood = m
                    break

            # بناء النتيجة النصية فقط
            task_data = {
                "entities": list(set(entities)),  # بدون تكرار
                "style": "organic",
                "mood": mood,
                "main_subject": entities[0] if entities else "unknown",
                "raw_prompt": prompt,
                "is_relevant": bool(entities),
                "analysis_timestamp": datetime.now().isoformat()
            }

            logger.info(f"[Traditional NLP] entities={task_data['entities']} | mood={mood} | relevant={task_data['is_relevant']}")

            return task_data

        except Exception as e:
            logger.exception(f"[Traditional NLP Error] {e}")

            fallback = {
                "entities": [],
                "style": "organic",
                "mood": "neutral",
                "main_subject": "unknown",
                "raw_prompt": prompt or "prompt فارغ",
                "is_relevant": False,
                "analysis_failed": True,
                "error_message": str(e)
            }
            return fallback
        
    def _integrate(self, task_data: Dict) -> Dict:
        """
        دالة تكامل خفيفة جدًا (نصية فقط)
        - تهيئة الحقول الأساسية في task_data
        - لا planes، لا تفاعلات، لا PlaneLayer، لا force/mass
        - يمكن حذفها لاحقًا إذا ما كانتش ضرورية
        """
        # تهيئة الحقول المتوقعة (بدون أي شيء بصري)
        task_data.setdefault("entities", [])
        task_data.setdefault("summary", {})
        task_data.setdefault("warnings", [])
        task_data.setdefault("metadata", {})

        # تحديث metadata بمعلومات نصية بسيطة
        task_data["metadata"].update({
            "entities_count": len(task_data["entities"]),
            "mood": task_data.get("mood", "neutral"),
            "integration_done": True
        })

        task_data["summary"] = {
            "note": "تم التكامل النصي بنجاح (لا طبقات بصرية هنا)"
        }

        return task_data

# ────────────────────────────────────────────────
#              اختبار سريع (اختياري)
# ────────────────────────────────────────────────

if __name__ == "__main__":
    print("traditional_design_engine.py تم تحميله كـ __main__")
    engine = traditional_design_engine()
    print("تم إنشاء الكائن بنجاح")
    print("generate_image موجود؟", hasattr(engine, "generate_image"))
    print("═" * 70)
    print("اختبار Traditional Design Engine")
    print("═" * 70)

    engine = traditional_design_engine()

    # prompt مناسب للـ traditional
    engine.receive_input("a majestic dragon creature in enchanted misty forest with glowing aura and organic flow")

    # أضف مهام بسيطة
    engine.add_task("main_creature", complexity=4.8)
    engine.add_task("forest_background", complexity=3.5)
    engine.add_task("aura_effect", complexity=2.7)

    result = engine.generate_image(is_video=False, force_refresh=True)

    print("\nنتيجة التوليد:")
    print(f"نجاح: {result.success}")
    print(f"رسالة: {result.message}")
    print(f"الوقت الكلي: {result.total_time:.2f} ث")
    if result.output_data and "preview_path" in result.output_data:
        print(f"مسار المعاينة: {result.output_data['preview_path']}")