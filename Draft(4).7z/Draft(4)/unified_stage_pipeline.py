# unified_stage_pipeline.py
"""
نظام إدارة المراحل مع تتبع وصف دقيق أثناء الكتابة + check & refresh ذكي
- المراحل الثلاث (NLP, Integration, Post-processing) تحت إشراف موحد
- Rendering منفصل تمامًا
- تتبع الكتابة الحية + refresh جزئي تلقائي (مع debounce + cache)
"""

import re
import hashlib
import logging
from typing import Dict, Any, Optional, List
from time import perf_counter
from pathlib import Path

from Agent_helper import AITab3, AIHelper

# استيراد المحرك هنا – في أعلى الملف
try:
    from traditional_design_engine import traditional_design_engine
except ImportError:
    traditional_design_engine = None
    print("⚠️  traditional_design_engine غير موجود – بعض الوظائف معطلة")

logger = logging.getLogger(__name__)

class UnifiedStagePipeline:
    """
    نظام إدارة المراحل الموحدة مع دعم:
    - الكتابة التدريجية (streaming / live typing)
    - debounce و auto-refresh ذكي
    - caching للمراحل
    - حدود آمنة للذاكرة
    """

    def __init__(self, engine: Any = None):
        self.engine = engine
        self.logger = logging.getLogger("UnifiedStagePipeline")

        if self.engine is None:
            self.logger.warning("تم تمرير engine=None → وضع fallback مفعّل")

        # ─── حالة الـ prompt الحالية ───────────────────────────────────────
        self.current_prompt: str = ""
        self.tracked_words: List[str] = []
        self.completed_words: List[str] = []

        # ─── حدود وقائية (مهمة جداً للـ real-time) ──────────────────────────
        self.MAX_CHARS = 2500           # ~400–600 كلمة تقريباً
        self.MAX_WORDS = 450
        self.MIN_WORDS_FOR_CHECK = 3
        self.AUTO_REFRESH_TRIGGER_WORDS = 5

        # ─── توقيت و debounce ────────────────────────────────────────────────
        self.last_input_time: float = 0.0
        self.debounce_delay: float = 1.8          # ثواني
        self.last_processed_hash: str = ""

        # ─── كاش وتتبع المراحل ──────────────────────────────────────────────
        self.stage_cache: Dict[str, Dict[str, Any]] = {}
        self.stage_times: Dict[str, float] = {}
        self.last_refresh_stage: Optional[str] = None
        self.last_refresh_reason: Optional[str] = None

        # ─── المكونات الفرعية ───────────────────────────────────────────────
        self.helper = AIHelper(self)
        self.tab3 = AITab3(self.helper)

        # ربط المحركات الافتراضية (يمكن تعديلها لاحقاً)
        if self.engine is not None:
            self.tab3.attach_engine("traditional", self.engine)
            self.tab3.attach_engine("geometric", self.engine)
        else:
            self.logger.warning("لم يتم ربط أي محرك → traditional & geometric غير متاحين")

    # ────────────────────────────────────────────────────────────────
    #                إدارة الـ prompt الحي (live input)
    # ────────────────────────────────────────────────────────────────

    def append_to_prompt(self, char_or_text: str) -> None:
        """
        إضافة حرف أو نص جزئي إلى الـ prompt الحالي مع تطبيق الحدود الآمنة
        """
        if not char_or_text:
            return

        self.current_prompt += char_or_text
        self.last_input_time = perf_counter()

        # 1. تطبيق حد الحروف (الأسرع)
        if len(self.current_prompt) > self.MAX_CHARS:
            self.current_prompt = self.current_prompt[-self.MAX_CHARS:]
            self.logger.debug("تم قص current_prompt إلى %d حرف (حد أقصى)", self.MAX_CHARS)

        # 2. تطبيق حد الكلمات (أثقل قليلاً لكن أكثر دقة)
        words = self.current_prompt.split()
        if len(words) > self.MAX_WORDS:
            self.current_prompt = " ".join(words[-self.MAX_WORDS:])
            self.logger.debug("تم قص current_prompt إلى %d كلمة (حد أقصى)", self.MAX_WORDS)

        # 3. تحديث tracked_words (اختياري – يمكن إزالته إذا لم يُستخدم)
        # self.tracked_words = words

    def should_process_now(self) -> bool:
        """
        هل حان الوقت لمعالجة الـ prompt الحالي؟ (debounce logic)
        """
        if not self.current_prompt.strip():
            return False

        now = perf_counter()
        elapsed = now - self.last_input_time

        if elapsed < self.debounce_delay:
            self.logger.debug("debounce → ما زال الكتابة مستمرة (%.2f ث)", elapsed)
            return False

        # مقارنة hash لمعرفة إذا تغير شيء فعلياً
        current_hash = hashlib.md5(self.current_prompt.encode('utf-8')).hexdigest()
        if current_hash == self.last_processed_hash:
            self.logger.debug("لا تغيير في الـ prompt → لا حاجة للمعالجة")
            return False

        self.last_processed_hash = current_hash
        return True

    # ────────────────────────────────────────────────────────────────
    #                   Refresh ومعالجة المراحل
    # ────────────────────────────────────────────────────────────────

    def _get_refresh_key(self, stage: str, prompt: str) -> str:
        """مفتاح كاش موحد"""
        return f"{stage}:{hashlib.md5(prompt.encode('utf-8')).hexdigest()}"

    def _refresh_stage(self, stage: str, prompt: Optional[str] = None) -> Dict[str, Any]:
        """
        تنفيذ refresh لمرحلة واحدة مع استخدام الكاش إن أمكن
        """
        prompt = prompt or self.current_prompt
        if not prompt or not prompt.strip():
            self.logger.warning("محاولة refresh بدون prompt صالح لـ %s", stage)
            return {}

        cache_key = self._get_refresh_key(stage, prompt)

        if cache_key in self.stage_cache:
            self.logger.debug("cache hit لـ %s", stage)
            return self.stage_cache[cache_key].copy()

        self.logger.info("تنفيذ refresh جديد لـ %s | prompt: %s...", 
                         stage, prompt[:70] + ("..." if len(prompt) > 70 else ""))

        try:
            if stage == "nlp":
                result = self._safe_call_unit("nlp", prompt) or {}
            elif stage == "integration":
                result = self._safe_call_unit("integration", {"raw_prompt": prompt}) or {}
            elif stage == "post_processing":
                result = self._safe_call_unit("post_processing", {"raw_prompt": prompt}) or {}
            else:
                self.logger.warning("مرحلة غير مدعومة: %s", stage)
                return {}

            if not isinstance(result, dict):
                self.logger.warning("%s أرجع نوع غير dict → تحويل إلى {}", stage)
                result = {}

            # حفظ في الكاش
            self.stage_cache[cache_key] = result.copy()
            self.last_refresh_stage = stage
            self.last_refresh_reason = "manual or auto refresh"

            return result

        except Exception as e:
            self.logger.error("خطأ أثناء refresh %s: %s", stage, e, exc_info=False)
            return {}

    def refresh_stage(self, stage: str, force: bool = False) -> Dict[str, Any]:
        """
        واجهة عامة لإعادة تنشيط مرحلة معينة
        """
        if not force and stage in self.stage_cache:
            # يمكن إضافة منطق أكثر ذكاءً لاحقاً (مثلاً التحقق من عمر الكاش)
            return self.stage_cache.get(stage, {})

        return self._refresh_stage(stage)

    # ────────────────────────────────────────────────────────────────
    #                   الدخول الرئيسي للكتابة الحية
    # ────────────────────────────────────────────────────────────────

    def on_char(self, char: str) -> Optional[str]:
        """
        تُستدعى مع كل حرف يُدخل من الواجهة (قبل الضغط على Enter).
        
        المهام الرئيسية:
        - إضافة الحرف إلى current_prompt
        - تطبيق حدود الأمان (MAX_CHARS)
        - كشف نهاية كلمة محتملة
        - مزامنة completed_words مع دعم التعديل/الحذف
        - تجاهل الكلمات التافهة في التحقق التلقائي
        - تفعيل auto-check + refresh جزئي بعد debounce فقط عند تغيير حقيقي
        
        Returns:
            Optional[str]: مسار معاينة إذا تم إنشاؤها، أو None
        """
        if not char:
            return None

        # 1. إضافة الحرف فوراً
        self.current_prompt += char

        # 2. تطبيق الحد الأقصى للحروف (حماية سريعة وخفيفة)
        if len(self.current_prompt) > self.MAX_CHARS:
            self.current_prompt = self.current_prompt[-self.MAX_CHARS:]
            self.logger.debug("قُصّ current_prompt إلى الحد الأقصى: %d حرف", self.MAX_CHARS)

        # 3. الكشف عن نهاية كلمة محتملة فقط (لتوفير المعالجة)
        if not (char.isspace() or char in ".,!?;:\n\r\t)]}"):
            return None  # لا نعالج إلا عند انتهاء كلمة محتمل

        # 4. استخراج الكلمات الحالية (نظيفة)
        current_words = [w.strip() for w in self.current_prompt.split() if w.strip()]

        # 5. مزامنة completed_words بذكاء (دعم الحذف والتعديل)
        prev_completed = self.completed_words
        min_common = min(len(current_words), len(prev_completed))

        if current_words[:min_common] == prev_completed[:min_common]:
            # السيناريو الطبيعي: إضافة كلمات جديدة فقط
            new_words = current_words[min_common:]
            for word in new_words:
                if not word:
                    continue

                clean_word = word.lower().strip(".,!?;:()[]{}")
                trivial_words = {
                    "the", "and", "or", "in", "on", "at", "to", "of", "a", "an", "is", "it",
                    "في", "على", "من", "إلى", "و", "أو", "مع", "ب", "ل", "ف", "ك", "هو", "هي"
                }

                self.completed_words.append(word)
                self.logger.debug("كلمة جديدة مضافة: %r | إجمالي: %d", word, len(self.completed_words))

                # تجاهل الكلمات التافهة في التحقق التلقائي
                if clean_word in trivial_words:
                    self.logger.debug("كلمة تافهة (%s) → لن تُفعّل auto-check", clean_word)
                    continue

                # إذا وصلنا إلى كلمة غير تافهة → نتحقق فوراً
                break  # نكتفي بأول كلمة غير تافهة جديدة

        else:
            # تغيير كبير (حذف، تعديل وسطي، backspace كثير...)
            self.logger.debug("تغيير كبير في النص → إعادة بناء completed_words")
            self.completed_words = current_words[:]

        # 6. قرار التحقق التلقائي (auto-check)
        if len(self.completed_words) < self.min_words_for_check:
            return None

        now = perf_counter()
        if now - self.last_input_time < self.debounce_delay:
            self.logger.debug("debounce نشط (%.2f ث < %.2f)", now - self.last_input_time, self.debounce_delay)
            return None

        # 7. نأخذ نافذة أخيرة فقط (توفير معالجة + تركيز على السياق الحديث)
        window_size = min(12, len(self.completed_words))  # نافذة معقولة
        partial_text = " ".join(self.completed_words[-window_size:])

        # 8. التحقق من التغيير الفعلي عبر hash
        current_hash = hashlib.md5(partial_text.encode('utf-8')).hexdigest()
        if current_hash == self.last_processed_hash:
            self.logger.debug("لا تغيير جوهري في النافذة الأخيرة → تجاهل")
            return None

        # 9. تحديث الحالة وتفعيل المعالجة
        self.last_input_time = now
        self.last_processed_hash = current_hash

        self.logger.info("تفعيل auto-check بعد كتابة كلمة جديدة | نافذة: %d كلمة | hash: %s...",
                        window_size, current_hash[:12])

        # 10. تنفيذ التحقق والـ refresh الجزئي إن لزم
        return self._maybe_auto_check_and_refresh(partial_text)

    # ─── تتبع الوصف الدقيقة أثناء الكتابة ──────────────────────────────
    def _safe_call_unit(
        self,
        unit_name: str,
        data: Any = None
    ) -> Dict[str, Any]:  # غيرت Optional → Dict لأننا دائمًا نرجع dict (حتى لو fallback)
        """
        استدعاء آمن لوحدة (stage/unit) داخل الـ engine.
        يرجع دائمًا dict حتى في حالة الفشل → يسهل التعامل في الأعلى.
        """
        if self.engine is None:
            logger.error(f"لا يوجد engine متاح → لا يمكن تنفيذ '{unit_name}'")
            return {
                "success": False,
                "error": "No engine instance available",
                "fallback": True,
                "stage": unit_name,
                "returned": None
            }

        # 1. التحقق من وجود الدالة
        if not hasattr(self.engine, "_call_unit"):
            logger.error(f"المحرك لا يحتوي على الدالة '_call_unit' → لا يمكن تنفيذ '{unit_name}'")
            return {
                "success": False,
                "error": "Engine missing _call_unit method",
                "fallback": True,
                "stage": unit_name,
                "missing_method": "_call_unit"
            }

        call_method = getattr(self.engine, "_call_unit")

        # 2. التحقق من أنها قابلة للاستدعاء
        if not callable(call_method):
            logger.error(f"'_call_unit' موجود لكنه غير قابل للاستدعاء (نوع: {type(call_method).__name__})")
            return {
                "success": False,
                "error": "_call_unit attribute is not callable",
                "fallback": True,
                "stage": unit_name,
                "invalid_type": str(type(call_method))
            }

        # 3. محاولة التنفيذ الفعلي
        try:
            result = call_method(unit_name, data)

            # 4. معالجة أنواع النتائج المختلفة (legacy & modern)
            if result is None:
                logger.warning(f"الوحدة '{unit_name}' أرجعت None → معاملة كفشل نسبي")
                return {
                    "success": False,
                    "warning": "Unit returned None",
                    "stage": unit_name,
                    "returned": None
                }

            if isinstance(result, (int, float)):
                # دعم legacy engines اللي كانت ترجع وقت التنفيذ فقط
                logger.info(f"Legacy mode: '{unit_name}' أرجع عدد (يُعامل كنجاح): {result}")
                return {
                    "success": True,
                    "duration_seconds": float(result),
                    "legacy": True,
                    "stage": unit_name,
                    "raw_result": result
                }

            if not isinstance(result, dict):
                logger.warning(
                    f"الوحدة '{unit_name}' أرجعت نوع غير متوقع: {type(result).__name__} → "
                    f"تحويل إلى dict افتراضي"
                )
                return {
                    "success": True,  # نعتبرها نجاح نسبي عشان ما نقطعش السلسلة
                    "stage": unit_name,
                    "raw_result": result,
                    "warning": f"Unexpected return type: {type(result).__name__}",
                    "normalized": True
                }

            # النتيجة dict → مثالية
            # نضيف بعض metadata إضافي لو مفيد
            result.setdefault("success", True)          # default لو ما حددهاش
            result.setdefault("stage", unit_name)
            result.setdefault("processed_at", perf_counter())

            return result

        except TypeError as te:
            # غالبًا عدد/نوع الباراميترات غلط
            logger.error(f"خطأ في تمرير الباراميترات لـ '{unit_name}': {te}")
            return {
                "success": False,
                "error": f"TypeError in call signature: {str(te)}",
                "stage": unit_name,
                "fallback": True
            }

        except Exception as e:
            # أي خطأ غير متوقع
            logger.exception(f"فشل تنفيذ '{unit_name}': {e}")
            return {
                "success": False,
                "error": str(e),
                "exc_type": type(e).__name__,
                "stage": unit_name,
                "fallback": True
            }
        
    def _should_trigger_auto_refresh(self) -> bool:
        """
        تقرر هل الوقت مناسب لتشغيل الـ auto-refresh أم لا
        (debounce + تغيير في المحتوى + عدد كلمات كافٍ + ...)
        """
        now = perf_counter()

        # 1. Debounce: هل مر وقت كافٍ من آخر معالجة؟
        if now - self.last_input_time < self.debounce_delay:
            return False

        # 2. هل وصلنا للحد الأدنى من الكلمات؟
        if len(self.completed_words) < self.min_words_for_check:
            return False

        # 3. (اختياري) هل تغير المحتوى فعلياً من آخر معالجة؟
        #    لو كنت تحتفظ بنسخة سابقة من النص أو hash، قارن هنا
        #    (في الكود الحالي نعتمد على last_processed_hash في on_char)

        # 4. شروط إضافية ممكنة مستقبلاً:
        #    - هل زاد عدد الكلمات بما يكفي؟
        #    - هل ظهرت كلمة مفتاحية مهمة؟
        #    - هل مر وقت طويل من آخر refresh حتى لو ما تغير شيء؟

        return True

    def _maybe_auto_check_and_refresh(self, partial_text: str) -> Optional[str]:
        """فحص خفيف → قرار refresh جزئي إذا لزم"""
        if len(partial_text.split()) < self.min_words_for_check:
            return None

        logger.info(f"Auto-check بعد debounce → {partial_text[:70]}...")

        quality = self._quick_quality_check(partial_text)
        if not quality["needs_refresh"]:
            logger.debug("الجودة مقبولة حالياً → لا refresh")
            return None

        stage = quality["recommended_stage"]
        logger.info(f"Refresh جزئي تلقائي → {stage} | سبب: {quality['reason']}")

        refreshed_data = self._refresh_stage(stage, partial_text)
        if not refreshed_data:
            logger.warning("الـ refresh رجع فارغ")
            return None
        
        try:
            preview = self.engine._create_simple_image(refreshed_data, is_video=False)
            if preview is None:
                logger.warning("preview رجع None → لا يوجد صورة للعرض")
                return "preview_not_generated"
            return preview

        except Exception as e:
            logger.error(f"فشل إنشاء preview في auto-refresh: {type(e).__name__} - {e}")
            # fallback بسيط جدًا (نص أو placeholder)
            return f"[preview failed - {stage} refreshed]"

    def _quick_quality_check(self, text: str) -> Dict[str, Any]:
        """فحص سريع نسبي — يركز على التغيير والاكتمال"""
        words = text.split()
        word_count = len(words)

        if word_count < self.min_words_for_check:
            return {
                "needs_refresh": True,
                "recommended_stage": "nlp",
                "reason": f"كلمات قليلة ({word_count} < {self.min_words_for_check})"
            }

        lower_text = text.lower()

        # ─── كيانات أساسية (موضوع رئيسي) ───────────────────────────────
        subject_keywords = [
            "حصان", "فتاة", "تنين", "غابة", "مدينة", "وحش", "قلعة", "بحر",
            "سماء", "جبل", "سيارة", "روبوت", "فضاء", "قمر", "شمس"
        ]
        has_subject = any(kw in lower_text for kw in subject_keywords)

        # ─── تفاصيل / جودة ────────────────────────────────────────────────
        quality_keywords = [
            "detailed", "highly detailed", "intricate", "cinematic", "ultra", "4k", "8k",
            "masterpiece", "best quality", "sharp focus", "beautiful", "epic", "dramatic"
        ]
        quality_count = sum(1 for kw in quality_keywords if kw in lower_text)

        # ─── كلمات هندسية / نمطية (مهمة للـ integration) ─────────────────
        geometry_keywords = ["spiral", "hex", "golden", "pattern", "fractal", "symmetry", "grid"]
        has_geometry = any(kw in lower_text for kw in geometry_keywords)

        # ─── قرارات متدرجة ─────────────────────────────────────────────────
        if not has_subject:
            return {
                "needs_refresh": True,
                "recommended_stage": "nlp",
                "reason": "لا يوجد موضوع/كيان واضح بعد"
            }

        if word_count >= 7 and quality_count == 0:
            return {
                "needs_refresh": True,
                "recommended_stage": "post_processing",
                "reason": f"كلمات كثيرة ({word_count}) بدون أي وصف جودة"
            }

        if has_geometry and word_count >= 5:
            return {
                "needs_refresh": True,
                "recommended_stage": "integration",
                "reason": "ظهرت كلمات هندسية/نمطية → يفضل تحديث integration"
            }

        # إضافة بسيطة: لو النص طويل جدًا بدون تقدم واضح
        if word_count > 15 and quality_count < 2:
            return {
                "needs_refresh": True,
                "recommended_stage": "post_processing",
                "reason": "prompt طويل بدون تفاصيل كافية"
            }

        return {
            "needs_refresh": False,
            "recommended_stage": None,
            "reason": f"مقبول (كيان موجود، جودة: {quality_count} hit(s))"
        }

    def process_delta(self, previous, delta_prompt, full_prompt, force_full=False):
        if force_full or not previous:
            return self.process(full_prompt, force_refresh=force_full)
        # وإلا نسخة بسيطة جدًا
        return previous.copy()

    def _safe_call_stage(self, stage_name: str, *args, **kwargs) -> Dict[str, Any]:
        """
        دالة مساعدة آمنة لاستدعاء أي مرحلة مع fallback ذكي
        - تتعامل مع float (legacy)، dict (الجديد)، None، أو أي نوع آخر
        - تضيف معلومات إضافية للـ logging والـ debugging
        """
        try:
            result = self._call_unit(stage_name, *args, **kwargs)

            # حالة 1: النتيجة dict → مثالية (الحالة المستقبلية)
            if isinstance(result, dict):
                return result

            # حالة 2: النتيجة float/int → legacy mode، نحولها إلى dict
            if isinstance(result, (int, float)):
                logger.warning(
                    f"المرحلة '{stage_name}' أرجعت {type(result).__name__} بدلاً من dict → "
                    f"تحويل تلقائي إلى dict متوافق"
                )
                return {
                    "success": True,
                    "duration_seconds": float(result),
                    "summary": f"Legacy {stage_name} result converted (duration: {result:.2f}s)",
                    "warnings": ["Legacy return type (float/int) detected - please update to dict"],
                    "legacy": True
                }

            # حالة 3: None أو نوع غير متوقع → fallback كامل
            if result is None:
                logger.warning(f"المرحلة '{stage_name}' أرجعت None → fallback إلى dict فارغ")
            else:
                logger.warning(
                    f"المرحلة '{stage_name}' أرجعت نوع غير متوقع ({type(result).__name__}) → "
                    f"fallback إلى dict فارغ"
                )

            return {
                "success": False,
                "duration_seconds": 0.0,
                "summary": f"Fallback - {stage_name} returned invalid type",
                "warnings": [f"Invalid return type: {type(result).__name__}"],
                "fallback": True
            }

        except Exception as e:
            logger.exception(f"خطأ أثناء تنفيذ المرحلة '{stage_name}': {e}")
            return {
                "success": False,
                "duration_seconds": 0.0,
                "summary": "Exception occurred during stage execution",
                "error": str(e),
                "warnings": ["Stage execution failed"],
                "fallback": True
            }
        
    # ─── المراحل الموحدة (تحت إشراف AI واحد) ──────────────────────────

    def _is_unified_complete(self, task_data: Dict) -> bool:
        return (
            len(task_data.get("entities", [])) >= 2 and
            len(task_data.get("planes", [])) >= 3 and
            task_data.get("post_summary", {}).get("processed", False)
        )

    # ─── Refresh جزئي (يُفعّل فقط عند الحاجة) ───────────────────────────

    def process(self, prompt: str, force_refresh: bool = False) -> Dict[str, Any]:
        """
        المعالجة الكاملة للـ prompt (تُستخدم عند الضغط على Enter أو زر Generate)

        Args:
            prompt: النص الكامل للـ prompt
            force_refresh: إجبار إعادة تنفيذ جميع المراحل (يتجاهل الكاش)

        Returns:
            قاموس يحتوي على نتائج جميع المراحل + معلومات إضافية (وقت، أخطاء، حالة الاكتمال)
        """
        if not prompt or not prompt.strip():
            self.logger.warning("محاولة معالجة prompt فارغ → إرجاع fallback بسيط")
            return self._create_fallback_result("prompt فارغ")

        start_total = perf_counter()
        self.stage_times.clear()

        task_data: Dict[str, Any] = {
            "raw_prompt": prompt.strip(),
            "entities": [],
            "planes": [],
            "style": "default",
            "mood": "neutral",
            "fallback": False,
            "errors": [],
            "warnings": [],
        }

        stages = ["nlp", "integration", "post_processing"]

        for stage in stages:
            stage_result = self._process_single_stage(
                stage=stage,
                prompt=prompt,
                force_refresh=force_refresh,
                task_data=task_data
            )

            # دمج النتيجة في task_data (إذا كانت صالحة)
            if stage_result.get("success", False):
                task_data.update(stage_result.get("data", {}))
            else:
                task_data["errors"].append(stage_result["error"])
                task_data["fallback"] = True
                if "warning" in stage_result:
                    task_data["warnings"].append(stage_result["warning"])

        # ─── معلومات إضافية بعد معالجة جميع المراحل ────────────────────────
        task_data["unified"] = self._is_unified_complete(task_data)
        task_data["unified_time"] = perf_counter() - start_total
        task_data["total_stages_duration"] = sum(self.stage_times.values())

        # تسجيل نهائي موجز
        error_count = len(task_data["errors"])
        if error_count > 0:
            self.logger.warning("اكتملت المعالجة مع %d أخطاء: %s",
                                error_count, ", ".join(task_data["errors"][:2]))
        else:
            self.logger.info("اكتملت معالجة المراحل بنجاح (وقت إجمالي: %.2f ث)",
                            task_data["unified_time"])

        return task_data

    def _process_single_stage(self,
                            stage: str,
                            prompt: str,
                            force_refresh: bool,
                            task_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        معالجة مرحلة واحدة مع دعم الكاش والـ force_refresh
        ترجع قاموساً موحداً يحتوي على حالة النجاح / البيانات / الخطأ
        """
        t_start = perf_counter()

        try:
            cache_key = None
            result = None

            if not force_refresh:
                cache_key = self._get_stage_cache_key(stage, prompt)
                if cache_key in self.stage_cache:
                    self.logger.debug("cache hit → %s", stage)
                    result = self.stage_cache[cache_key].copy()

            if result is None:
                self.logger.info("تنفيذ %s %s", 
                                "إجباري" if force_refresh else "جديد",
                                stage)
                result = self._refresh_stage(stage, prompt)

                # حفظ في الكاش إذا كان ناجحاً
                if result and isinstance(result, dict):
                    self.stage_cache[cache_key or self._get_stage_cache_key(stage, prompt)] = result.copy()

            # التحقق من صلاحية النتيجة
            if not isinstance(result, dict):
                self.logger.warning("%s أرجع نوع غير متوقع (%s) → fallback", 
                                    stage, type(result).__name__)
                result = self._minimal_fallback_for_stage(stage)
                task_data["warnings"].append(f"{stage}: invalid return type")

            return {
                "success": True,
                "data": result,
                "duration": perf_counter() - t_start
            }

        except Exception as exc:
            self.logger.exception("خطأ أثناء معالجة %s", stage)
            duration = perf_counter() - t_start
            return {
                "success": False,
                "error": f"{stage}: {type(exc).__name__} - {str(exc)}",
                "duration": duration,
                "warning": f"مرحلة {stage} فشلت → تم استخدام fallback"
            }

        finally:
            duration = perf_counter() - t_start
            self.stage_times[stage] = duration
            if "errors" in task_data and task_data["errors"]:
                self.stage_times[f"{stage}_had_error"] = True

    def _get_stage_cache_key(self, stage: str, prompt: str) -> str:
        """إنشاء مفتاح كاش موحد ومحمي"""
        # يمكن تحسينه لاحقاً بإضافة version أو specialization
        prompt_hash = hashlib.md5(prompt.encode('utf-8')).hexdigest()
        return f"{stage}:{prompt_hash[:16]}"  # نأخذ جزءاً فقط لتقليل الطول

    def _create_fallback_result(self, reason: str) -> Dict[str, Any]:
        """إنشاء نتيجة fallback بسيطة وآمنة عند الفشل المبكر"""
        return {
            "raw_prompt": "",
            "entities": [],
            "planes": [],
            "style": "fallback",
            "mood": "neutral",
            "fallback": True,
            "errors": [reason],
            "unified": False,
            "unified_time": 0.0,
            "total_stages_duration": 0.0
        }

    def _minimal_fallback_for_stage(self, stage: str) -> Dict[str, Any]:
        """قيم افتراضية آمنة جدًا لكل مرحلة لو فشلت"""
        fallbacks = {
            "nlp": {
                "entities": [],
                "main_subject": "unknown",
                "mood": "neutral",
                "style": "default",
                "fallback": True
            },
            "integration": {
                "planes": [{"type": "background", "desc": "default"}],
                "plane_interactions": [],
                "fallback": True
            },
            "post_processing": {
                "post_summary": {"processed": False, "note": "fallback"},
                "fallback": True
            }
        }
        return fallbacks.get(stage, {"fallback": True, "note": "no fallback defined"})
    
    # ─── Rendering (منفصل تمامًا تحت إشراف AI مستقل) ────────────────────

    def _is_unified_complete(self, task_data: Dict) -> bool:
        """معيار بسيط للجودة الكلية – يمكن تطويره"""
        return (
            len(task_data.get("entities", [])) >= 1 and
            len(task_data.get("planes", [])) >= 1 and
            task_data.get("post_summary", {}).get("processed", False)
        )

    def render(self, task_data: Dict, is_video: bool = False) -> float:
        t = perf_counter()
        try:
            self.engine._create_simple_image(task_data, is_video)
        except Exception as e:
            logger.error(f"خطأ في الـ render: {e}")
        return perf_counter() - t

    def notify(self, event: str, data: Any):
        self.logger.info(f"تلقي حدث: {event} | بيانات: {data}")
        if event == "analyzed_external":
            self.logger.debug("تحليل خارجي تم → يمكن إضافة refresh أو تعديل")
            # مثال: عمل refresh تلقائي لو needs_refresh
            if data.get("needs_refresh"):
                self.tab3.refresh_engine("traditional")
            
# ──────────────────────────────────────────────
#  قوائم الاختبار (تعريف خارجي لتسهيل الصيانة)
# ──────────────────────────────────────────────

BASIC_TEST_PROMPTS = [
    "مراقبة هذا الـ prompt",
    "غابة سحرية هادئة",
    "تنين فقط",
]

EXTRA_TEST_PROMPTS = [
    "تنين أسود يطير فوق جبال مغطاة بالثلج تحت ضوء القمر",
    "فتاة ساحرة مع شعر أزرق طويل في غابة مضيئة بفطريات سحرية",
    "حصان مجنح أبيض يركض في سهل ذهبي عند الغروب",
    "وحش بحري عملاق يخرج من بحيرة ضبابية",
    "شجرة الحياة العملاقة في وسط صحراء مليئة بالنجوم",
    "مشهد غروب شمس برتقالي مع طيور مهاجرة",
    "فقط بحر هادئ بدون أي كائن",
]


# ────────────────────────────────────────────────
#              اختبار سريع للتحميل (اختياري)
# ────────────────────────────────────────────────
if __name__ == "__main__":
    print("\n" + "═" * 70)
    print("اختبار تحميل unified_stage_pipeline.py + AIHelper".center(70))
    print("═" * 70 + "\n")

    # محاولة إنشاء pipeline
    pipeline = None
    helper = None
    tab3 = None

    try:
        from traditional_design_engine import traditional_design_engine
        engine = traditional_design_engine()
        pipeline = UnifiedStagePipeline(engine)
        print("✓ تم إنشاء UnifiedStagePipeline")

        # محاولة الوصول إلى tab3 بطرق مختلفة
        if hasattr(pipeline, 'helper') and hasattr(pipeline.helper, 'tab3'):
            tab3 = pipeline.helper.tab3
            print("✓ تم العثور على tab3 عبر pipeline.helper.tab3")
        elif hasattr(pipeline, 'tab3'):
            tab3 = pipeline.tab3
            print("✓ تم العثور على tab3 مباشرة في pipeline")
        else:
            print("⚠️ لم يتم العثور على tab3 داخل pipeline")

    except Exception as e:
        print("× فشل إنشاء pipeline:", type(e).__name__, str(e))

    # ─── اختبار monitor_engine ────────────────────────────────────────
    print("\n" + "─" * 70)
    print("اختبار monitor_engine".center(70))
    print("─" * 70 + "\n")

    prompts_to_test = [
        "تنين أسود يطير فوق جبال مغطاة بالثلج تحت ضوء القمر",
        "فتاة ساحرة مع شعر أزرق طويل في غابة مضيئة بفطريات سحرية",
        "فقط بحر هادئ بدون أي كائن",
    ]

    monitor_func = None

    if tab3 is not None and hasattr(tab3, 'monitor_engine'):
        monitor_func = tab3.monitor_engine
        print("→ سيتم استخدام tab3.monitor_engine")
    elif hasattr(pipeline, 'helper') and hasattr(pipeline.helper, 'monitor_engine'):
        monitor_func = pipeline.helper.monitor_engine
        print("→ سيتم استخدام pipeline.helper.monitor_engine")
    else:
        print("× لا يوجد monitor_engine متاح في هذا السياق")

    if monitor_func:
        for prompt in prompts_to_test:
            print(f"\n→ {prompt}")
            try:
                result = monitor_func("traditional", prompt)
                if isinstance(result, dict):
                    print(f"  ✓ نجح – ثقة: {result.get('confidence', 'غير معروف'):.2f}")
                    if 'suggestions' in result and result['suggestions']:
                        print("  اقتراحات:")
                        for i, s in enumerate(result['suggestions'], 1):
                            print(f"    {i}. {s}")
                else:
                    print("  → رجع نوع غير متوقع:", type(result))
            except Exception as e:
                print("  × خطأ:", type(e).__name__, str(e))
            print("─" * 65)
    else:
        print("لا يمكن تشغيل الاختبار – لا توجد دالة monitor_engine متاحة")

    print("\n" + "═" * 70)
    print("الاختبار انتهى".center(70))
    print("═" * 70)