# Final_Generation.py
"""
الموديل النهائي لتوليد الصور المركبة من طبقات متعددة (background, midground, foreground)
كل طبقة تولد باستخدام محرك متخصص مختلف (environment, geometric, traditional)
يحدد الترتيب ديناميكيًا بناءً على الprompt تحت إشراف SuperVisor بسيط.
"""

from typing import Dict, Optional

import logging
from pathlib import Path
from typing import Dict, List, Optional, Any
from time import perf_counter
from dataclasses import dataclass, field
import random
from PIL import Image, ImageDraw, ImageFont, ImageEnhance, ImageFilter, ImageSequence
from PIL import Image
from abc import ABC, abstractmethod

from prompt_supervisor import PromptSupervisor
from memory_manager import GenerativeMemoryManager
from Image_generation import GenerationResult
from plane_layer import PlaneLayer
from contextlib import contextmanager

from environment_design_engine import environment_design_engine
from geometric_design_engine import geometric_design_engine
from traditional_design_engine import traditional_design_engine

logger = logging.getLogger(__name__)

class LayerEngine(ABC):
    @abstractmethod
    def generate_layer(
        self,
        prompt: str,
        target_size: tuple = (1024, 1024),
        is_video: bool = False,
        as_layer: bool = True,          # شفافية افتراضية
        force_refresh: bool = False,
    ) -> GenerationResult:
        pass

    def receive_input(self, prompt: str):
        # لو محتاج buffer داخلي
        pass

class CompositeEngine:
    def __init__(self):
        self.engine_map = {
            "background": environment_design_engine,
            "midground": geometric_design_engine,
            "foreground": traditional_design_engine
        }
        self.memory_manager = GenerativeMemoryManager() 
        self.supervisor = PromptSupervisor(llm_callable=self._dummy_llm_call)  # استبدل بالدالة الحقيقية لاحقًا
        self.specialization = "composite"
        
        # ─── الإضافة المهمة ────────────────────────────────
        self.input_port = []                     # list لتجميع الـ prompts / inputs
        self.specialization = {"name": "composite"}  # dict بسيط، أو ممكن تخلّيه string لو مش محتاج حاجات كتير
        # ─────────────────────────────────────────────────────
        self.tasks = []                          # لتتبع المهام (اختياري)
        self.dependencies = {}                   # لتتبع الاعتماديات بين المهام (اختياري)
        self.stats = {"total_generations": 0, "successes": 0, "failures": 0}  # إحصائيات عامة (اختياري)
        self.layer_opacities = {"background": 255, "midground": 255, "foreground": 255}  # للتحكم في شفافية الطبقات بناءً على التفاعل (اختياري)
        self.interaction_history = []  # لتتبع تاريخ التفاعلات بين الطبقات (اختياري)
        self.composite_history = []    # لتتبع تاريخ التوليد المركب (اختياري)
        self.error_log = []           # لتتبع الأخطاء التي تحدث أثناء التوليد (اختياري)
        self.performance_log = []     # لتتبع أداء التوليد (الأوقات، الموارد المستخدمة، إلخ) (اختياري)
        self.visualization_data = []   # لتخزين بيانات للتصور لاحقًا (اختياري)
        self.debug_mode = True         # لتفعيل/تعطيل الرسائل التفصيلية أثناء التطوير (اختياري)
        self.last_composite_result: Optional[GenerationResult] = None  # لتخزين نتيجة التوليد الأخير (اختياري)
        self.layer_interaction_data = {}  # لتخزين بيانات التفاعل بين الطبقات (اختياري)
        self.composite_count = 0  # عداد لعدد التوليدات المركبة التي تم تنفيذها (اختياري)
        self.successful_composites = 0  # عداد لعدد التوليدات المركبة الناجحة (اختياري)
        self.failed_composites = 0  # عداد لعدد التوليدات المركبة الفاشلة (اختياري)
        self.total_composite_time = 0.0  # لتتبع الوقت الإجمالي الذي استغرقه التوليد المركب (اختياري)
        
        self.unit_tests = {
            "split_prompt_into_layers": self._split_prompt_into_layers,
        }

    def generate_composite(
        self,
        prompt: str,
        resolution: tuple = (1024, 1024),
        output_name: Optional[str] = None,
        force_refresh: bool = False,
        is_video: bool = False,
        auto_split: bool = True,
    ) -> GenerationResult:
        start_total = perf_counter()
        layer_paths = {}
        final_path = None

        result = GenerationResult(
            success=False,
            message="",
            total_time=0.0,
            stage_times={},
            specialization="composite",
            is_video=is_video,
            output_data=None
        )

        try:
            logger.info(f"[Composite] بدء توليد {'فيديو GIF' if is_video else 'صورة'} | prompt: {prompt[:70]}...")

            # 1. تقسيم + تنظيف
            components = self._split_prompt_into_layers(prompt) if auto_split else {
                "background": prompt, "midground": prompt, "foreground": prompt
            }

            # تنظيف كل طبقة على حدة
            for layer_name, sub_prompt in components.items():
                task_data = {"raw_prompt": sub_prompt}
                if self.memory_manager.check_for_creepy(sub_prompt, task_data):
                    cleaned = self.memory_manager.refresh_memory(sub_prompt, task_data, layer_name)["raw_prompt"]
                    components[layer_name] = cleaned
                    logger.info(f"[Memory] تم تنظيف prompt طبقة {layer_name}")

            # بناء الـ composite prompt مرة واحدة فقط + تنظيفه
            composite_prompt = (
                f"Background: {components.get('background', '')}\n"
                f"Midground: {components.get('midground', '')}\n"
                f"Foreground: {components.get('foreground', '')}"
            )
            task_data_comp = {"raw_prompt": composite_prompt}
            if self.memory_manager.check_for_creepy(composite_prompt, task_data_comp):
                composite_prompt = self.memory_manager.refresh_memory(
                    composite_prompt, task_data_comp, "composite"
                )["raw_prompt"]
                logger.info("[Memory] تم تنظيف الـ composite prompt الكامل")

            # 2. ترتيب الطبقات
            layer_order = self._determine_layer_order(components)

            # 3. توليد الطبقات
            for layer_name in layer_order:
                sub_prompt = components.get(layer_name, prompt)
                engine_class = self.engine_map.get(layer_name)
                if not engine_class:
                    logger.warning(f"لا محرك للطبقة: {layer_name}")
                    continue

                engine = engine_class()

                logger.info(f"[Composite → {layer_name}] استدعاء generate_layer(is_video={is_video})")

                layer_result = engine.generate_layer(
                    prompt=sub_prompt,                  # ← الـ prompt يروح مباشرة هنا
                    force_refresh=force_refresh,
                    as_layer=True,
                    target_size=resolution,
                    is_video=is_video,
                    # لو عندك أي باراميتر إضافي كنت بتمرره قبل كده، حطه هنا
                )

                # باقي الكود زي ما هو (التحقق من النجاح وتخزين المسار)
                if layer_result.success and layer_result.output_data and "preview_path" in layer_result.output_data:
                    path = layer_result.output_data["preview_path"]
                    if Path(path).exists():
                        layer_paths[layer_name] = path
                        logger.info(f"✓ تم إنشاء طبقة {layer_name}: {path}")
                    else:
                        logger.warning(f"× مسار الطبقة غير موجود: {path}")
                else:
                    logger.warning(f"× فشل توليد طبقة {layer_name}: {layer_result.message}")

            # 4. دمج
            final_path = self._composite_layers(
                layer_paths=layer_paths,
                resolution=resolution,
                output_name=output_name
            )

            total_time = perf_counter() - start_total

            result = GenerationResult(
                success=True,
                message=f"تم التوليد المركب بنجاح ({len(layer_paths)} طبقات)",
                total_time=total_time,
                stage_times={"composite": total_time},
                specialization="composite",
                is_video=is_video,
                output_data={"final_path": final_path, "layer_paths": layer_paths},
                mode="composite_video" if is_video else "composite_image"
            )

            logger.info(f"[Composite] انتهى بنجاح → {final_path}")

        except Exception as e:
            logger.exception("[Composite] خطأ عام")
            result.message = f"خطأ في التوليد المركب: {str(e)}"
            result.total_time = perf_counter() - start_total

        # محاكاة التفاعل (اختياري – يحتاج تعديل لاستخدام layer_opacities بشكل صحيح)
        interaction_data = self._simulate_layer_interactions(components, layer_paths)
        if interaction_data["influence"] > 0:
            logger.info(f"[Interaction] تأثير x² = {interaction_data['influence']:.2f}")
            # مثال: يمكن تمرير الـ opacities للـ _composite_layers في المرة القادمة

        self.memory_manager.log_stats()
        return result

    @contextmanager
    def temp_reference_image(path: str):
        """
        Context manager يضمن حذف الملف المؤقت بعد الاستخدام حتى لو حصل exception
        """
        try:
            yield path
        finally:
            if os.path.exists(path):
                try:
                    os.remove(path)
                    logger.debug(f"[Cleanup] تم حذف الملف المؤقت: {path}")
                except Exception as e:
                    logger.warning(f"فشل حذف {path}: {e}")

    def generate_scene_with_new_angle(
        self,
        env_data: dict,                     # الـ dict اللي رجعه environment_design_engine
        new_camera_prompt: str,             # وصف الزاوية الجديدة فقط
        reference_temp_path: str = None     # مسار الصورة المؤقتة اللي رجعها environment
    ) -> GenerationResult:
        """
        توليد مشهد بنفس البيئة لكن بزاوية مختلفة
        """
        final_result = None

        # استخدام context manager لضمان الحذف التلقائي
        if reference_temp_path and os.path.exists(reference_temp_path):
            with temp_reference_image(reference_temp_path) as ref_path:
                logger.info(f"استخدام مرجع مؤقت: {ref_path} لزاوية جديدة")
                
                # هنا نولّد الـ master prompt مع تعديل الزاوية فقط
                master_prompt = self._build_master_with_new_angle(
                    env_data["enhanced_prompt"],
                    new_camera_prompt
                )
                
                # استدعاء النموذج النهائي مع الـ reference
                final_result = self._call_generation_model(
                    prompt=master_prompt,
                    reference_image_path=ref_path,   # ← مررها لـ ControlNet/IP-Adapter
                    camera_angle=new_camera_prompt,
                    seed=self.last_seed  # نفس الـ seed لتماسك أكبر
                )
        
        else:
            # بدون مرجع (fallback)
            logger.warning("لا يوجد مرجع مؤقت → توليد بدون conditioning")
            master_prompt = self._build_master_with_new_angle(
                env_data["enhanced_prompt"],
                new_camera_prompt
            )
            final_result = self._call_generation_model(prompt=master_prompt)

        return final_result

    def _simulate_layer_interactions(self, components: Dict[str, str], layer_paths: Dict[str, str]) -> Dict[str, Any]:
        """
        محاكاة تفاعل بين الطبقات باستخدام PlaneLayer (اختياري)
        تعمل فقط لو الـ prompt فيه علاقة مكانية واضحة
        """
        from plane_layer import PlaneLayer

        interaction_result = {"influence": 0.0, "adjusted_opacities": {}, "notes": []}

        # كلمات تدل على علاقة مكانية/تفاعل
        relation_indicators = ["على", "فوق", "جالس", "راكب", "تمسك", "تحمل", "تحت", "داخل", "خارج"]

        full_prompt = " ".join(components.values()).lower()
        if not any(word in full_prompt for word in relation_indicators):
            return interaction_result  # مفيش علاقة → نرجع فاضي

        # مثال بسيط: نفترض mid = عنصر (سيارة)، foreground = شخص
        mid_prompt = components.get("midground", "").lower()
        fg_prompt = components.get("foreground", "").lower()

        if ("سيارة" in mid_prompt or "car" in mid_prompt) and ("فتاة" in fg_prompt or "girl" in fg_prompt):
            car = PlaneLayer([0.0, 0.0, 0.0], force=0.8, label="Car", mass=2.5)
            girl = PlaneLayer([0.0, 1.5, 0.5], force=0.4, label="Girl", mass=1.0)

            influence = girl.x2_effect(car)
            interaction_result["influence"] = influence
            interaction_result["notes"].append("تم اكتشاف علاقة: فتاة على سيارة")

            # استخدام التأثير في تعديل opacity (مثال)
            car_opacity = min(255, int(180 + influence * 30))  # أعلى تأثير = أوضح سيارة
            girl_opacity = min(255, int(220 + influence * 20))
            interaction_result["adjusted_opacities"] = {
                "midground": car_opacity,
                "foreground": girl_opacity
            }

        return interaction_result

    def _determine_layer_order(self, components: Dict) -> List[str]:
        order = []
        # أولوية افتراضية
        priorities = {"background": 0, "midground": 1, "foreground": 2}
        
        # لو في كلمات تدل على "عمق" أو "أمامية قوية" ممكن نعدل الأولوية
        full_text = " ".join(components.values()).lower()
        if any(w in full_text for w in ["في الأمام", "بالمقدمة", "closest", "in front"]):
            priorities["foreground"] -= 1  # نرفعه للأمام
        
        # ترتيب حسب الأولوية + وجود المحتوى
        candidates = [(name, text, priorities.get(name, 10)) 
                    for name, text in components.items() if text.strip()]
        candidates.sort(key=lambda x: x[2])
        
        order = [name for name, _, _ in candidates]
        
        if not order:
            order = ["background", "midground", "foreground"]
            
        logger.info(f"[SuperVisor] ترتيب الطبقات: {order} (priorities: {priorities})")
        return order

    def _split_prompt_into_layers(self, prompt: str) -> Dict[str, str]:
        """
        تقسيم ذكي للـ prompt إلى طبقات (background, midground, foreground)
        يعتمد على كلمات مفتاحية + فواصل + علاقات مكانية (على، فوق، داخل...)
        """
        lower = prompt.lower()
        
        # توسيع قواميس الكلمات المفتاحية
        fg_keywords = {
            'فتاة', 'girl', 'ولد', 'boy', 'امرأة', 'رجل', 'شخص', 'creature', 'person', 'human',
            'تنين', 'dragon', 'حصان', 'horse', 'كائن', 'وحش', 'طفل', 'طفلة'
        }
        
        mg_keywords = {
            'سيارة', 'car', 'دراجة', 'motorcycle', 'دراجة نارية', 'طائرة', 'plane', 'سفينة', 'ship',
            'منزل', 'house', 'مبنى', 'building', 'كرسي', 'chair', 'طاولة', 'table', 'باب', 'door',
            'سلم', 'stairs', 'جسر', 'bridge', 'سياج', 'fence'
        }
        
        bg_keywords = {
            'غابة', 'forest', 'جبل', 'mountain', 'صحراء', 'desert', 'بحر', 'sea', 'محيط', 'ocean',
            'سماء', 'sky', 'ليل', 'night', 'قمر', 'moon', 'شمس', 'sun', 'مدينة', 'city', 'شارع', 'street',
            'نيون', 'neon', 'ضباب', 'fog', 'مطر', 'rain', 'ثلج', 'snow'
        }

        # كلمات علاقة مكانية تساعد في تحديد الطبقة
        relation_keywords = {'على', 'فوق', 'جالس', 'جالسة', 'راكب', 'راكبة', 'يقف', 'تقف', 'داخل', 'خارج'}

        # تقسيم الـ prompt إلى عبارات (على أساس الفواصل)
        import re
        sentences = [s.strip() for s in re.split(r'[،.,;]', prompt) if s.strip()]

        result = {"background": "", "midground": "", "foreground": ""}

        remaining = prompt

        for sentence in sentences:
            s_lower = sentence.lower()
            
            # أولوية عالية للعلاقات المكانية
            if any(rel in s_lower for rel in relation_keywords):
                # لو فيه علاقة → نفصل الشخصية (foreground) والعنصر (midground)
                words = s_lower.split()
                fg_part = ""
                mg_part = ""
                for w in words:
                    if any(kw in w for kw in fg_keywords):
                        fg_part += w + " "
                    elif any(kw in w for kw in mg_keywords):
                        mg_part += w + " "
                if fg_part:
                    result["foreground"] += sentence + " "
                    remaining = remaining.replace(sentence, "")
                if mg_part:
                    result["midground"] += sentence + " "
                    remaining = remaining.replace(sentence, "")

            # تقسيم عادي
            elif any(kw in s_lower for kw in fg_keywords):
                result["foreground"] += sentence + " "
                remaining = remaining.replace(sentence, "")
            elif any(kw in s_lower for kw in mg_keywords):
                result["midground"] += sentence + " "
                remaining = remaining.replace(sentence, "")
            elif any(kw in s_lower for kw in bg_keywords):
                result["background"] += sentence + " "
                remaining = remaining.replace(sentence, "")

        # لو فيه باقي → نضيفه للخلفية كfallback
        if remaining.strip():
            result["background"] += remaining

        # لو طبقة فاضية تمامًا → نعطيها الوصف الكامل كبديل آمن
        for k in result:
            if not result[k].strip():
                result[k] = prompt

        # تنظيف نهائي
        result = {k: v.strip() for k, v in result.items()}

        logger.info(f"[Split Layers - Improved] → {result}")
        return result
    
    def _composite_layers(
        self,
        layer_paths: Dict[str, str],
        resolution: tuple = (1024, 1024),
        output_name: Optional[str] = None,
        background_color: tuple = (0, 0, 0, 255)
    ) -> str:
        """
        دمج الطبقات مع دعم GIF مركب إذا كانت أي طبقة فيديو.
        """
        from PIL import Image, ImageSequence
        import os

        try:
            # ─── تحديد إذا كان فيه GIF أصلاً ────────────────────────────────
            is_gif_composite = any(path.lower().endswith('.gif') for path in layer_paths.values())
            if not is_gif_composite:
                # حالة PNG عادية (الكود القديم)
                base = Image.new("RGBA", resolution, background_color)
                layer_order = ["background", "midground", "foreground"]

                for layer_name in layer_order:
                    path = layer_paths.get(layer_name)
                    if not path or not os.path.exists(path):
                        continue
                    try:
                        layer_img = Image.open(path).convert("RGBA")
                        layer_img = layer_img.resize(resolution, Image.Resampling.LANCZOS)
                        base = Image.alpha_composite(base, layer_img)
                    except Exception as e:
                        logger.error(f"فشل دمج {layer_name}: {e}")

                # حفظ PNG
                if not output_name:
                    ts = int(perf_counter() * 1000)
                    output_name = f"composite_{ts}.png"
                base.save(output_name, "PNG", optimize=True)
                return output_name

            # ─── حالة GIF مركب ───────────────────────────────────────────────────
            logger.info("[Composite GIF] بدء دمج GIF متعدد الطبقات...")

            # جمع كل الإطارات من كل طبقة
            layer_frames = {}
            max_frames = 0
            durations = []

            for layer_name, path in layer_paths.items():
                if not path or not os.path.exists(path):
                    continue
                try:
                    img = Image.open(path)
                    if img.format == 'GIF':
                        frames = []
                        for frame in ImageSequence.Iterator(img):
                            frame_copy = frame.convert("RGBA").resize(resolution, Image.Resampling.LANCZOS)
                            frames.append(frame_copy)
                        layer_frames[layer_name] = frames
                        max_frames = max(max_frames, len(frames))
                        durations.append(img.info.get('duration', 100))
                    else:
                        # لو PNG بس → نكرره على عدد الإطارات
                        frame = img.convert("RGBA").resize(resolution, Image.Resampling.LANCZOS)
                        layer_frames[layer_name] = [frame] * max_frames
                except Exception as e:
                    logger.error(f"فشل قراءة {layer_name}: {e}")

            if not layer_frames:
                raise ValueError("لا إطارات صالحة للدمج")

            # متوسط الـ duration (أو نأخذ أول واحد)
            frame_duration = min(d for d in durations if d > 0) if durations else 100

            # ─── دمج الإطارات ────────────────────────────────────────────────────
            composite_frames = []
            for i in range(max_frames):
                base = Image.new("RGBA", resolution, background_color)
                for layer_name in ["background", "midground", "foreground"]:
                    frames_list = layer_frames.get(layer_name, [])
                    if not frames_list:
                        continue
                    frame_idx = min(i, len(frames_list) - 1)
                    base = Image.alpha_composite(base, frames_list[frame_idx])

                # ─── تحسينات بصرية داخل اللوب (لكل إطار) ───────────────────────────────
                if base.mode != "RGBA":
                    base = base.convert("RGBA")

                # 1. Vignette خفيفة
                vignette = Image.new("L", resolution, 255)
                draw = ImageDraw.Draw(vignette)
                for j in range(0, 256):
                    r = max(0, min(resolution[0], resolution[1])) // 2 - j * 2
                    if r > 0:
                        draw.ellipse(
                            (resolution[0]//2 - r, resolution[1]//2 - r,
                            resolution[0]//2 + r, resolution[1]//2 + r),
                            fill=255 - j
                        )
                vignette = vignette.filter(ImageFilter.GaussianBlur(80))
                vignette = ImageEnhance.Brightness(vignette).enhance(0.7)

                # 2. Color grading خفيف
                enhancer = ImageEnhance.Contrast(base)
                base = enhancer.enhance(1.15)
                enhancer = ImageEnhance.Color(base)
                base = enhancer.enhance(1.12)
                enhancer = ImageEnhance.Brightness(base)
                base = enhancer.enhance(0.98)

                # دمج vignette على الإطار الحالي
                base = Image.composite(base, Image.new("RGBA", resolution, (0,0,0,0)), vignette)

                composite_frames.append(base)

            # ─── حفظ GIF أو PNG ────────────────────────────────────────────────────────
            if not output_name:
                ts = int(perf_counter() * 1000)
                output_name = f"composite_{ts}.{'gif' if is_gif_composite else 'png'}"

            if is_gif_composite:
                composite_frames[0].save(
                    output_name,
                    save_all=True,
                    append_images=composite_frames[1:],
                    duration=frame_duration,
                    loop=0,
                    optimize=True,
                    disposal=2  # مهم للشفافية في GIF
                )
                logger.info(f"[Composite GIF] تم الحفظ مع vignette و grading: {output_name} ({len(composite_frames)} إطار)")
            else:
                composite_frames[0].save(output_name, "PNG", optimize=True)
                logger.info(f"[Composite PNG] تم الحفظ مع vignette و grading: {output_name}")

            return output_name

        except Exception as e:
            logger.exception("خطأ في دمج الطبقات (GIF/PNG)")
            error_path = f"error_composite_{int(perf_counter()*1000)}.png"
            error_img = Image.new("RGBA", resolution, (40, 0, 0, 255))
            from PIL import ImageDraw, ImageFont
            draw = ImageDraw.Draw(error_img)
            try:
                font = ImageFont.truetype("arial.ttf", 40)
            except:
                font = ImageFont.load_default()
            draw.text((50, resolution[1]//2), "خطأ في الدمج", fill=(255, 100, 100), font=font)
            error_img.save(error_path)
            return error_path
        
    def generate(self, prompt: str, as_layer: bool = False, target_size: tuple = (1024, 1024)) -> str:
        """
        دالة توليد صورة أو طبقة بناءً على التخصص
        في هذه النسخة التجريبية → توليد صورة بسيطة مع نص فقط
        لاحقًا سيتم استبدالها بمحركات حقيقية (مثل Stable Diffusion أو غيره)
        """
        from PIL import Image, ImageDraw, ImageFont

        img = Image.new("RGBA", target_size, (0, 0, 0, 0) if as_layer else (255, 255, 255, 255))
        draw = ImageDraw.Draw(img)
        try:
            font = ImageFont.truetype("arial.ttf", 40)
        except:
            font = ImageFont.load_default()
        text = f"{self.specialization.get('name', 'unknown')}\n{prompt[:50]}..."
        draw.text((20, 20), text, fill=(255, 0, 0), font=font)
        output_name = f"{self.specialization.get('name', 'unknown')}_{int(perf_counter() * 1000)}.png"
        img.save(output_name, "PNG", optimize=True)
        return output_name        
                                
    def add_task(self, name: str, duration: float, dependencies: Optional[List[str]] = None):
        if dependencies is None:
            dependencies = []
        self.tasks.append({"name": name, "duration": duration, "dependencies": dependencies})
    
    def clear_input(self):
        old_len = len(self.input_port)
        self.input_port.clear()
        logger.info(f"تم مسح {old_len} إدخالات من المنفذ")
        
    def receive_input(self, input_data: str) -> bool:
        """تلقي وصف جديد → تنظيفه → تخزينه في المنفذ"""
        if not input_data or not isinstance(input_data, str):
            logger.error("الإدخال غير صالح أو فارغ")
            return False

        stripped = input_data.strip()
        if not stripped:
            logger.warning("الإدخال بعد التنظيف فارغ")
            return False

        # بدون أي validate هنا → نقبل كل شيء الآن
        self.input_port.append(stripped)
        logger.info(f"تم إضافة إدخال جديد ({len(self.input_port)} في المنفذ) → {stripped[:60]}...")
        return True
        
    def check_dependencies(self) -> bool:
        """التحقق من سلامة الاعتماديات"""
        all_names = {t["name"] for t in self.tasks}
        for task_name, deps in self.dependencies.items():
            missing = [d for d in deps if d not in all_names]
            if missing:
                logger.error(f"اعتماديات مفقودة لـ '{task_name}': {missing}")
                return False
        return True
    
    def create_layer_image(
        specialization: str,              # "traditional", "geometric", "environment"
        prompt: str = "",
        width: int = 1024,
        height: int = 1024,
        transparent_bg: bool = True,      # طبقات غالباً تحتاج شفافية
        target_opacity: int = 255,
        is_video: bool = False
    ) -> Optional[str]:
        """
        إنشاء طبقة صورة بسيطة حسب نوع التخصص
        تستخدم كـ fallback أو placeholder حتى يتم ربط المحركات الحقيقية
        """
        try:
            # إعداد الصورة الأساسية
            mode = "RGBA" if transparent_bg else "RGB"
            bg_color = (0, 0, 0, 0) if transparent_bg else (10, 12, 25)
            img = Image.new(mode, (width, height), bg_color)
            draw = ImageDraw.Draw(img)

            # ─── تخصيص الرسم حسب Specialization ────────────────────────────────
            lower_prompt = prompt.lower()

            if specialization == "traditional_design":
                # غابة سحرية + كائنات + ضباب + جسيمات
                # أشجار بسيطة
                for _ in range(15):
                    x = random.randint(-50, width + 50)
                    h = random.randint(400, height - 100)
                    draw.polygon(
                        [(x-100, height), (x, height - h), (x+100, height)],
                        fill=(8, 12, 20)
                    )

                # ضباب
                for _ in range(40):
                    x, y = random.randint(0, width), random.randint(0, height // 2 + 100)
                    r = random.randint(100, 300)
                    draw.ellipse((x-r, y-r, x+r, y+r), fill=(200, 210, 240, 30))

                # كائن رئيسي (حصان + راكب تقريبي)
                if "horse" in lower_prompt or "حصان" in lower_prompt or "creature" in lower_prompt:
                    cx, cy = width // 2, height - 180
                    # جسم الحصان
                    draw.ellipse((cx-90, cy-70, cx+90, cy+70), fill=(220, 220, 240))
                    # رأس
                    draw.ellipse((cx-40, cy-110, cx+40, cy-30), fill=(220, 220, 240))
                    # عيون
                    draw.ellipse((cx-15, cy-80, cx-5, cy-70), fill=(0,0,0))
                    draw.ellipse((cx+5, cy-80, cx+15, cy-70), fill=(0,0,0))
                    # راكب بسيط
                    draw.rectangle((cx-35, cy-160, cx+35, cy-80), fill=(180, 140, 100))

                # جسيمات شبحية
                for _ in range(80):
                    x = random.randint(0, width)
                    y = random.randint(0, height)
                    sz = random.randint(3, 9)
                    alpha = random.randint(80, 180)
                    draw.ellipse((x-sz, y-sz, x+sz, y+sz), fill=(230, 240, 255, alpha))

            elif specialization == "geometric_design":
                # أشكال هندسية + spiral + تناظر
                center_x, center_y = width // 2, height // 2

                # دوائر متداخلة
                for r in range(60, 400, 45):
                    draw.ellipse(
                        (center_x - r, center_y - r, center_x + r, center_y + r),
                        outline=(180, 160, 120), width=3
                    )

                # خطوط radial
                for angle in range(0, 360, 15):
                    rad = (angle * 3.14159) / 180
                    x2 = center_x + 500 * random.uniform(0.6, 1.0) * (rad.cos() if hasattr(rad,'cos') else 1)
                    y2 = center_y + 500 * random.uniform(0.6, 1.0) * (rad.sin() if hasattr(rad,'sin') else 1)
                    draw.line((center_x, center_y, x2, y2), fill=(220, 190, 80), width=2)

                # نص توضيحي (اختياري)
                try:
                    from PIL import ImageFont
                    font = ImageFont.load_default()
                    draw.text((40, 40), "Geometric Layer", fill=(255, 215, 0), font=font)
                except:
                    pass

            elif specialization == "environment_design":
                # نيون + سايبر + انعكاسات
                # خلفية مدينة داكنة
                draw.rectangle((0, 0, width, height), fill=(5, 5, 15))

                # خطوط نيون أفقية ورأسية
                for y in range(80, height, 140):
                    draw.line((0, y, width, y), fill=(0, 255, 220, 140), width=3)

                for x in range(100, width, 180):
                    draw.line((x, 0, x, height), fill=(255, 80, 220, 130), width=3)

                # انعكاسات / glow
                for _ in range(25):
                    x, y = random.randint(0, width), random.randint(0, height)
                    r = random.randint(40, 180)
                    draw.ellipse((x-r, y-r, x+r, y+r), fill=(0, 240, 255, 45))

                # نص نيون
                try:
                    from PIL import ImageFont
                    font = ImageFont.load_default()
                    draw.text((width//2 - 140, height//2 - 30), "NEON CITY", fill=(0, 255, 255), font=font)
                except:
                    pass

            else:
                # fallback عام
                draw.text((width//4, height//2), f"Layer: {specialization}\n{prompt[:60]}", fill=(200, 200, 255))

            # تطبيق الشفافية الكلية إذا طُلب
            if target_opacity < 255 and mode == "RGBA":
                alpha = Image.new("L", img.size, target_opacity)
                img.putalpha(alpha)

            # حفظ
            suffix = "video" if is_video else "layer"
            output_path = Path(f"{specialization}_{suffix}_{int(Path().stat().st_mtime_ns % 1000000)}.png")
            img.save(output_path, "PNG", optimize=True)

            logger.info(f"تم إنشاء طبقة {specialization} → {output_path}")
            return str(output_path)

        except Exception as e:
            logger.exception(f"فشل إنشاء طبقة {specialization}")
            return None
    
    def generate_image(
        self,
        specialization: Optional[str] = None,
        is_video: bool = False,
        reset_input_after: bool = True,
        force_refresh: bool = False,
        auto_detect_mode: bool = True,
        debounce_seconds: float = 2.5,
        as_layer: bool = False,           # ← جديد: هل نريد طبقة شفافة فقط؟
        target_size: tuple = (1024, 1024) # ← جديد: الحجم المطلوب
    ) -> GenerationResult:
        """
        دالة توليد طبقة أو صورة (حسب الباراميتر as_layer)
        النسخة المحسنة الانتقالية قبل التحول الكامل لنظام الـ composite
        """
        spec_name = specialization or self.specialization.get("name", "unknown")
        logger.info(f"توليد → {spec_name} | layer={as_layer} | prompt={self.input_port[-1][:60] if self.input_port else 'لا يوجد'}")

        start_total = perf_counter()
        stage_times = {}

        if not self.input_port:
            return GenerationResult(
                success=False,
                message="لا يوجد وصف",
                total_time=0.0,
                stage_times={},
                specialization=spec_name,
                is_video=is_video
            )

        full_prompt = " ".join(self.input_port).strip()

        try:
            # تخطي المراحل المعطلة مؤقتًا (nlp, integration, post-processing)
            logger.debug("تخطي المراحل المتقدمة مؤقتًا حتى يتم إصلاح UnifiedStagePipeline")
            task_data = {
                "raw_prompt": full_prompt,
                "entities": [],
                "planes": [],
                "summary": {"note": "مراحل متقدمة معطلة مؤقتًا"}
            }
            stage_times["unified_stages"] = 0.005  # وقت رمزي

            # الـ rendering الفعلي
            t_render = perf_counter()

            if as_layer:
                # إنتاج طبقة شفافة (خلفية شفافة)
                preview_path = self._create_simple_image(
                    task_data,
                    is_video=is_video,
                    transparent_bg=True,     # ← باراميتر جديد يجب دعمه في _create_simple_image
                    target_size=target_size
                )
            else:
                # الوضع القديم (صورة كاملة)
                preview_path = self._create_simple_image(task_data, is_video=is_video)

            stage_times["rendering"] = perf_counter() - t_render

            if not preview_path:
                raise ValueError("لم يتم إنشاء مسار معاينة")

            total_time = perf_counter() - start_total

            result = GenerationResult(
                success=True,
                message="تم التوليد بنجاح" + (" (طبقة شفافة)" if as_layer else ""),
                total_time=total_time,
                stage_times=stage_times,
                specialization=spec_name,
                is_video=is_video,
                output_data={"preview_path": preview_path}
            )

            if reset_input_after:
                self.input_port.clear()

            return result

        except Exception as e:
            logger.exception("خطأ في generate_image")
            return GenerationResult(
                success=False,
                message=str(e),
                total_time=perf_counter() - start_total,
                stage_times=stage_times,
                specialization=spec_name,
                is_video=is_video
            )  

    def cleanup_temp_references(self):
        """
        حذف جميع الملفات المؤقتة التي تم إنشاؤها من المحركات (environment وغيرها)
        - يُستدعى في نهاية عملية التوليد الكاملة (مثل بعد generate_composite)
        - أو في __del__ أو عند إغلاق الجلسة
        """
        if not hasattr(self, 'temp_files') or not self.temp_files:
            return

        deleted_count = 0
        for path in self.temp_files[:]:  # نسخة لتجنب مشاكل التكرار
            if os.path.exists(path):
                try:
                    os.remove(path)
                    logger.debug(f"[Cleanup] تم حذف: {path}")
                    deleted_count += 1
                    self.temp_files.remove(path)
                except Exception as e:
                    logger.warning(f"فشل حذف {path}: {e}")

        if deleted_count > 0:
            logger.info(f"[Cleanup] تم حذف {deleted_count} ملفات مؤقتة")
        else:
            logger.debug("[Cleanup] لا ملفات تحتاج حذف")

if __name__ == "__main__":
    # مثال بسيط للتشغيل
    generator = FinalGeneration()
    generator.receive_input("فتاة جالسة على حصان في غابة سحرية مع ضباب وجسيمات")
    result = generator.generate_image(as_layer=False)
    print(result)
    
    print("\n--- توليد طبقة Midground ---")
    generator.receive_input("سيارة رياضية حديثة")
    layer_result = generator.generate_image(specialization="geometric_design", as_layer=True)   
    print(layer_result) 
    print("\n--- توليد مركب ---")
    composite_result = generator.generate_composite(
        prompt="فتاة جالسة على سيارة رياضية في مدينة نيون ليلية",
        resolution=(1024, 1024),
        output_name="final_composite.png",
        force_refresh=True,
        is_video=False,
        auto_split=True
    )
    print(composite_result) 
    print("\n--- توليد مركب فيديو ---")
    composite_video_result = generator.generate_composite(
        prompt="فتاة جالسة على سيارة رياضية في مدينة نيون ليلية",
        resolution=(1024, 1024),
        output_name="final_composite_video.mp4",
        force_refresh=True,
        is_video=True,
        auto_split=True
    )
    print(composite_video_result) 
    