# memory_manager.py

import re  # ← أضف هذا السطر في البداية

from typing import Dict, Any, Optional
import logging
import hashlib
from collections import defaultdict
from copy import deepcopy

logger = logging.getLogger(__name__)

from collections import defaultdict
from typing import Set, Dict, Any
import time

import json
import time
from pathlib import Path
from typing import Dict, Any, Set
import logging
from collections import defaultdict

logger = logging.getLogger(__name__)

class GenerativeMemoryManager:
    def __init__(self, max_cache_size: int = 1200):
        """
        تهيئة مدير الذاكرة التوليدية
        Args:
            max_cache_size: الحد الأقصى لعدد الـ prompts المحفوظة (لحماية من memory leak)
        """
        self.memory_store: Dict[str, Dict[str, Any]] = {}
        self.access_order: list[str] = []           # لتطبيق LRU بسيط
        self.max_cache_size = max_cache_size
        self.default_ttl_seconds = 3600  # 1 ساعة – يمكن تمريره كباراميتر

        # ─── تحميل الكلمات المفتاحية والدرجات من ملف خارجي (أولوية) ────────
        keywords_file = Path(__file__).parent / "creepy_keywords.json"
        if keywords_file.exists():
            try:
                with open(keywords_file, encoding="utf-8") as f:
                    data = json.load(f)
                    self.creepy_keywords: Set[str] = set(data.get("keywords", []))
                    self.creepy_severity: Dict[str, int] = data.get("severity", {})
                logger.info(f"تم تحميل {len(self.creepy_keywords)} كلمة مرعبة من {keywords_file}")
            except Exception as e:
                logger.error(f"خطأ أثناء تحميل {keywords_file}: {e}")
                self._load_default_keywords()
        else:
            logger.warning(f"ملف {keywords_file} غير موجود → استخدام قائمة افتراضية")
            self._load_default_keywords()

        # ─── إحصائيات ───────────────────────────────────────────────────────────────
        self.stats = {
            "filtered_count": 0,
            "recovered_count": 0,
            "cache_hits": 0,
            "last_cleanup": time.time(),
        }

    def _load_default_keywords(self):
        """تحميل القائمة الافتراضية في حالة عدم وجود الملف"""
        self.creepy_keywords = {
            # إنجليزي - أساسي
            "creepy", "horror", "scary", "ghost", "monster", "nightmare",
            "blood", "gore", "kill", "murder", "torture", "zombie", "demon",
            "curse", "slaughter", "bloody", "haunted", "terrifying", "macabre",
            "mutilate", "decapitate", "dismember",
            # إنجليزي - مشتقات
            "k!ll", "murd3r", "bl00d", "g0re",
            # عربي
            "مرعب", "كابوس", "شبح", "وحش", "دموي", "رعب", "قتل", "ذبح",
            "لعنة", "جثة", "دماء", "مذبحة", "تعذيب", "زومبي", "شيطان",
            "مخيف", "رعبي", "ظلامي", "كابوسي", "مروع", "مفزع",
        }

        self.creepy_severity = {
            # منخفضة
            "ghost": 1, "شبح": 1, "nightmare": 1, "كابوس": 1,
            "dark": 1, "mysterious": 1,
            # متوسطة
            "scary": 2, "creepy": 2, "monster": 2, "zombie": 2,
            "دموي": 2, "مخيف": 2,
            # عالية
            "blood": 3, "gore": 3, "kill": 3, "murder": 3, "torture": 3,
            "قتل": 3, "ذبح": 3, "تعذيب": 3, "مذبحة": 3,
        }

    def get_prompt_hash(self, prompt: str) -> str:
        """حساب hash فريد للـ prompt"""
        return hashlib.sha256(prompt.encode('utf-8')).hexdigest()[:16]  # قصير للوضوح

    def check_for_creepy(self, prompt: str, task_data: Dict) -> bool:
        """check تنبؤية: الكشف عن Creepy (كلمات مرعبة أو عناصر غير مرغوبة)"""
        lower_prompt = prompt.lower()
        entities = task_data.get("entities", [])
        mood = task_data.get("mood", "calm")

        # تنبؤي: لو وجد creepy keyword أو mood creepy أو entities مرعبة
        if any(kw in lower_prompt for kw in self.creepy_keywords):
            logger.warning("اكتشاف Creepy في الـ prompt → يحتاج refresh")
            return True

        if "dark" in mood or "mysterious" in mood and len(entities) > 3:
            logger.warning("مود Creepy مع تعقيد عالي → يحتاج refresh")
            return True

        return False

    def _update_access_order(self, key: str):
        """تحديث ترتيب الوصول (LRU)"""
        if key in self.access_order:
            self.access_order.remove(key)
        self.access_order.append(key)
        
        # إزالة العناصر الزائدة إذا تجاوزنا الحد
        while len(self.access_order) > self.max_cache_size:
            oldest_key = self.access_order.pop(0)
            if oldest_key in self.memory_store:
                del self.memory_store[oldest_key]
                logger.debug(f"LRU evicted: {oldest_key}")

    def _put_in_cache(self, key: str, value: Dict):
        entry = {
            "data": value,
            "timestamp": time.time(),
            "ttl": self.default_ttl_seconds
        }
        self.memory_store[key] = entry
        self._update_access_order(key)

        # eviction لو تجاوز الحد
        while len(self.memory_store) > self.max_cache_size:
            oldest_key = self.access_order.pop(0)
            del self.memory_store[oldest_key]
    
    def _get_from_cache(self, key: str) -> Optional[Dict]:
        if key not in self.memory_store:
            return None
        entry = self.memory_store[key]
        if time.time() - entry["timestamp"] > entry["ttl"]:
            del self.memory_store[key]
            self.access_order.remove(key) if key in self.access_order else None
            return None
        self._update_access_order(key)
        return entry["data"]
    
    def advanced_creepy_filter(
        self,
        prompt: str,
        task_data: Dict[str, Any],
        specialization: str = "traditional_design"
    ) -> Dict[str, Any]:
        """
        فلتر Creepy متقدم:
        - يُرجع نسخة نظيفة جديدة (لا يعدل المدخل الأصلي)
        - ينظف الكلمات المرعبة من الـ prompt
        - يعدل المود والكيانات إذا لزم الأمر
        - يستخدم shallow copy + تنظيف إجباري (بدون deepcopy كامل)
        """
        # ─── 1. نسخ سطحي سريع + تهيئة آمنة أولية ────────────────────────────────
        cleaned = task_data.copy()

        # تنظيف إجباري مبكر (يضمن هيكل آمن من البداية)
        cleaned = self._sanitize_task_data(cleaned)

        # ─── 2. نسخ يدوي للحقول الحساسة اللي هنعدلها (قوائم وقواميس) ──────────
        for key in ["entities", "planes", "plane_interactions", "filtered_words", "warnings"]:
            if key in cleaned:
                if isinstance(cleaned[key], list):
                    cleaned[key] = cleaned[key].copy()
                elif isinstance(cleaned[key], dict):
                    cleaned[key] = cleaned[key].copy()

        # ─── 3. إعدادات أساسية ────────────────────────────────────────────────────────
        original_prompt = prompt
        prompt_hash = self.get_prompt_hash(original_prompt)
        lower_prompt = prompt.lower()
        removed_words: List[str] = []
        creepy_level = 0

        # ─── 4. تنظيف الـ prompt من الكلمات المرعبة ─────────────────────────────────
        clean_prompt = prompt
        for kw in self.creepy_keywords:
            if kw in lower_prompt:
                clean_prompt = re.sub(
                    rf'\b{re.escape(kw)}\b',
                    "[filtered]",
                    clean_prompt,
                    flags=re.IGNORECASE
                )
                removed_words.append(kw)
                creepy_level = max(creepy_level, self.creepy_severity.get(kw, 1))

        if removed_words:
            cleaned["raw_prompt"] = clean_prompt
            cleaned["filtered_words"] = list(set(removed_words))

        # ─── 5. تعديل المود إذا كان مرعبًا أو تم تنظيف كلمات ──────────────────────
        mood = cleaned.get("mood", "calm").lower()
        creepy_moods = {"dark", "mysterious", "eerie", "sinister", "horror", "ghastly"}
        
        if mood in creepy_moods or removed_words:
            new_mood = "serene" if "traditional" in specialization.lower() else "neutral"
            cleaned["mood"] = new_mood
            creepy_level = max(creepy_level, 2)

        # ─── 6. تنظيف الكيانات (entities) ────────────────────────────────────────────
        entities = cleaned.get("entities", [])
        cleaned_entities = [e for e in entities if e.lower() not in self.creepy_keywords]
        
        if len(cleaned_entities) < len(entities):
            removed_count = len(entities) - len(cleaned_entities)
            logger.info(f"تم إزالة {removed_count} كيان مرعب من entities")
            creepy_level = max(creepy_level, 1)
        
        cleaned["entities"] = cleaned_entities

        # ─── 7. استرجاع نسخة آمنة سابقة إذا كان المستوى مرتفعًا جدًا ─────────────
        if creepy_level >= 3:
            previous_safe = self._get_safe_previous(prompt_hash, specialization)
            if previous_safe:
                # دمج مع التنظيف الإجباري قبل الدمج
                previous_safe = self._sanitize_task_data(previous_safe)
                merged = previous_safe.copy()
                # نعطي الأولوية للبيانات الجديدة في الحقول الحساسة
                for k in ["raw_prompt", "entities", "mood", "filtered_words"]:
                    if k in cleaned:
                        merged[k] = cleaned[k]
                cleaned = merged
                cleaned["recovered_from"] = prompt_hash
                cleaned["recovered_reason"] = "high creepy level → recovered & sanitized"
                creepy_level = 0

        # ─── 8. تنظيف نهائي قبل الحفظ والإرجاع ──────────────────────────────────────
        final_cleaned = self._sanitize_task_data(cleaned)

        # ─── 9. إضافة metadata للتتبع ────────────────────────────────────────────────
        final_cleaned["creepy_filtered"] = bool(removed_words or creepy_level > 0)
        final_cleaned["creepy_level"] = creepy_level
        final_cleaned["timestamp"] = time.time()
        final_cleaned["specialization"] = specialization

        # ─── 10. حفظ النسخة النظيفة في الذاكرة (اختياري – يمكن تعليقه) ───────────
        # self.memory_store[prompt_hash] = final_cleaned.copy()  # shallow copy آمن
        self._put_in_cache(prompt_hash, cleaned.copy())  # shallow copy آمن

        return final_cleaned

    def should_refresh_stages(
        self,
        prompt: str,
        current_task_data: dict,
        specialization: str,
        force_refresh: bool = False,
        max_refresh_attempts: int = 1,
        current_refresh_count: int = 0
    ) -> dict:
        """
        تقرر بشكل مركزي أي مراحل تحتاج إعادة تنفيذ
        
        Returns:
            dict: {
                "needs_refresh": bool,
                "refresh_nlp": bool,
                "refresh_integration": bool,
                "refresh_post": bool,
                "reason": str,
                "suggested_attempts_left": int
            }
        """
        prompt_hash = self.get_prompt_hash(prompt)
        lower_prompt = prompt.lower()

        result = {
            "needs_refresh": False,
            "refresh_nlp": False,
            "refresh_integration": False,
            "refresh_post": False,
            "reason": "",
            "suggested_attempts_left": max(0, max_refresh_attempts - current_refresh_count),
        }

        if force_refresh:
            result["needs_refresh"] = True
            result["refresh_nlp"] = True
            result["refresh_integration"] = True
            result["refresh_post"] = True
            result["reason"] = "force_refresh=True"
            return result

        # ─── 1. تقييم سريع بناءً على heuristic_score (يمكن نقله هنا لاحقًا)
        score = self._quick_heuristic_score(prompt, current_task_data)  # يمكن إضافتها
        if score < 0.72:
            result["needs_refresh"] = True
            result["reason"] += "low heuristic score; "

        # ─── 2. اكتشاف Creepy / محتوى غير مرغوب
        if self.check_for_creepy(prompt, current_task_data):
            result["needs_refresh"] = True
            result["refresh_nlp"] = True
            result["reason"] += "creepy content detected; "

        # ─── 3. التحقق من جودة التحليل السابق (NLP)
        entities = current_task_data.get("entities", [])
        if len(entities) <= 1 and "detailed" not in lower_prompt and "highly" not in lower_prompt:
            result["needs_refresh"] = True
            result["refresh_nlp"] = True
            result["reason"] += "weak entity detection; "

        # ─── 4. التحقق من جودة التكامل (integration)
        planes = current_task_data.get("planes", [])
        interactions = current_task_data.get("plane_interactions", [])
        if len(planes) < 2 or len(interactions) < 3:
            result["needs_refresh"] = True
            result["refresh_integration"] = True
            result["reason"] += "insufficient layers/interactions; "

        # ─── 5. التحقق من جودة المعالجة النهائية
        quality_keywords = {"detailed", "ultra", "cinematic", "masterpiece", "8k", "photorealistic"}
        has_quality = any(kw in lower_prompt for kw in quality_keywords)
        if not has_quality and current_task_data.get("post_summary", {}).get("processed", False) is False:
            result["needs_refresh"] = True
            result["refresh_post"] = True
            result["reason"] += "missing quality indicators + no post-processing; "

        # ─── 6. حد أقصى للمحاولات
        if current_refresh_count >= max_refresh_attempts:
            result["suggested_attempts_left"] = 0
            result["needs_refresh"] = False
            result["reason"] += "max refresh attempts reached; "

        result["reason"] = result["reason"].rstrip("; ")

        if result["needs_refresh"]:
            logger.info(f"[Memory Refresh Decision] refresh needed | reason: {result['reason']}")
        else:
            logger.debug("[Memory Refresh Decision] no refresh needed")

        return result

    def _sanitize_task_data(self, task_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        تنظيف إجباري لـ task_data من أي عناصر creepy
        يُستخدم قبل الحفظ وقبل الاسترجاع
        """
        cleaned = task_data.copy()

        # نسخ يدوي للحقول الحساسة
        for key in ["entities", "planes", "plane_interactions"]:
            if key in cleaned and isinstance(cleaned[key], list):
                cleaned[key] = cleaned[key].copy()

        # 1. تنظيف entities
        entities = cleaned.get("entities", [])
        cleaned["entities"] = [
            e for e in entities
            if e.lower() not in self.creepy_keywords
        ]

        # 2. تنظيف raw_prompt إذا وجد
        if "raw_prompt" in cleaned:
            lower_p = cleaned["raw_prompt"].lower()
            for kw in self.creepy_keywords:
                if kw in lower_p:
                    cleaned["raw_prompt"] = re.sub(
                        rf'\b{re.escape(kw)}\b',
                        "[filtered]",
                        cleaned["raw_prompt"],
                        flags=re.IGNORECASE
                    )

        # 3. إعادة تعيين mood إلى آمن
        if "mood" in cleaned:
            mood = cleaned["mood"].lower()
            if mood in {"dark", "mysterious", "eerie", "sinister", "horror"}:
                cleaned["mood"] = "calm"

        # 4. إزالة أي filtered_words قديمة لو موجودة
        cleaned.pop("filtered_words", None)

        # علامة تنظيف
        cleaned["sanitized"] = True
        cleaned["sanitized_at"] = time.time()

        return cleaned

    def _quick_heuristic_score(self, prompt: str, task_data: Dict[str, Any]) -> float:
        """
        تقييم سريع لجودة الـ prompt + task_data (0.0 إلى 1.0+)
        يُستخدم لقرار الـ refresh
        """
        score = 0.60  # قاعدة افتراضية متوسطة

        # طول الـ prompt
        prompt_len = len(prompt)
        if prompt_len < 50:
            score -= 0.25
        elif prompt_len > 120:
            score += 0.20

        # عدد الكيانات
        entities = task_data.get("entities", [])
        ent_count = len(entities)
        if ent_count <= 1:
            score -= 0.22
        elif ent_count >= 4:
            score += 0.18

        # كلمات جودة عالية (quality boosters)
        quality_keywords = {"detailed", "ultra", "cinematic", "masterpiece", "8k", "photorealistic", "high quality"}
        quality_hits = sum(1 for kw in quality_keywords if kw in prompt.lower())
        score += quality_hits * 0.12

        # عقوبة إذا كان فيه creepy_level مرتفع
        if task_data.get("creepy_level", 0) >= 2:
            score -= 0.35

        # حدود آمنة
        return max(0.35, min(1.50, score))
    
    def refresh_memory(self, prompt: str, task_data: Dict, specialization: str) -> Dict:
        """
        refresh تلقائي:
        - دمج المعلومات (merge old + new) مع الحفاظ على الترتيب
        - تجديد (update)
        - التخلص من Creepy (purge) بعد الدمج
        """
        prompt_hash = self.get_prompt_hash(prompt)
        old_memory = self.memory_store.get(prompt_hash)

        logger.info(f"[Refresh] ذاكرة prompt_hash: {prompt_hash} | تخصص: {specialization}")

        # 1. التخلص من Creepy في task_data الجديد أولاً
        entities = task_data.get("entities", [])
        filtered_entities = [e for e in entities if e.lower() not in self.creepy_keywords]
        if len(filtered_entities) < len(entities):
            logger.info(f"تم التخلص من {len(entities) - len(filtered_entities)} creepy elements في الـ task_data الجديد")
        task_data["entities"] = filtered_entities

        # 2. دمج مع الذاكرة القديمة (مع الحفاظ على الترتيب)
        merged_data = old_memory.copy() if isinstance(old_memory, dict) else {}
        
        for key, value in task_data.items():
            if key in merged_data and isinstance(merged_data[key], list) and isinstance(value, list):
                # دمج مع الحفاظ على الترتيب + إزالة تكرار
                merged_data[key] = list(dict.fromkeys(merged_data[key] + value))
            else:
                # استبدال أو إضافة مباشرة
                merged_data[key] = value

        # 3. تنظيف نهائي للـ merged_data (عشان نضمن ما فيش creepy من القديم)
        merged_data = self._sanitize_task_data(merged_data)

        # 4. تجديد الذاكرة
        self._put_in_cache(prompt_hash, merged_data)  # لو مستخدم الـ LRU الجديد
        # أو: self.memory_store[prompt_hash] = merged_data

        logger.info(f"[Refresh] تم تجديد الذاكرة: {len(merged_data)} عناصر")

        return merged_data

    def _get_safe_previous(self, prompt_hash: str, specialization: str) -> Optional[Dict]:
        candidate = self._get_from_cache(prompt_hash)
        if candidate is None:
            return None
        
        # تنظيف قبل الإرجاع
        return self._sanitize_task_data(candidate)

# ─── دمج مع المحركات ──────────────────────────────────────────────────
# في كل محرك (traditional/geometric/environment)، أضف:

# self.memory_manager = GenerativeMemoryManager()

# ثم في generate_image أو _process_unified_stages:
# if self.memory_manager.check_for_creepy(prompt, task_data):
#     recovered = self.memory_manager.auto_recovery_on_creepy(prompt, specialization)
#     if recovered:
#         task_data = recovered
#     task_data = self.memory_manager.refresh_memory(prompt, task_data, specialization)