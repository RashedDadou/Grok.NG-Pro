# المكان: ملف environment_design_engine.py
# الجزء: البداية من الملف + الدوال الرئيسية (generate_layer, generate_image, receive_input, ...)

"""
محرك التوليد الخاص بالتصاميم البيئية
- يحلل ويحسن الوصف النصي فقط
- يرجع dict محسن (نص + metadata)
- لا يولد صورة نهائية أبدًا
- يمكنه (اختياريًا) إنشاء صورة مرجعية مؤقتة تُحذف بعد الاستخدام
"""

import logging
from typing import Dict, List, Any, Optional, Tuple
from time import perf_counter

from memory_manager import GenerativeMemoryManager
from Image_generation import CoreImageGenerationEngine, GenerationResult, perf_counter 
from layer_engine import LayerEngine  # أو المسار الصحيح

logger = logging.getLogger(__name__)


class environment_design_engine(CoreImageGenerationEngine, LayerEngine):
    """
    محرك متخصص في تحليل وتحسين وصف البيئة فقط.
    الإخراج الرئيسي: dict نصي محسن + metadata
    لا يتدخل في توليد الصور النهائية (دور Final_Generation)
    """

    def __init__(self):
        self.input_port: List[str] = []                     # الوصف المتراكم
        self.memory_manager = GenerativeMemoryManager()
        
        # التخصص البسيط
        self.specialization = {
            "name": "environment_design",
            "description": "تصاميم بيئية، طبيعة، مدن سايبر، نيون، ضباب، إضاءة جوية، عمق، طقس",
            "keywords": ["environment", "cyberpunk", "neon", "fog", "rain", "cityscape"]
        }

        # قائمة لتتبع الملفات المؤقتة (اختياري)
        self.temp_files: List[str] = []

    # ────────────────────────────────────────────────
    # الواجهة الرئيسية الجديدة (prompt مباشر)
    # ────────────────────────────────────────────────
    def generate_layer(
        self,
        prompt: str,
        target_size: Tuple[int, int] = (1024, 1024),
        is_video: bool = False,
        as_layer: bool = True,
        force_refresh: bool = False,
        **kwargs
    ) -> GenerationResult:
        """
        الواجهة المفضلة الجديدة – تأخذ prompt مباشرة
        ترجع dict وصفي محسن فقط (لا صورة نهائية)
        """
        logger.info(f"[Environment] generate_layer called with prompt: {prompt[:70]}...")

        start = perf_counter()
        enhanced = self._enhance_environment_prompt(prompt, force_refresh=force_refresh)

        result = GenerationResult(
            success=True,
            message="تم تحسين وصف البيئة بنجاح",
            total_time=perf_counter() - start,
            stage_times={"enhance": perf_counter() - start},
            specialization=self.specialization["name"],
            is_video=is_video,
            output_data={
                "enhanced_prompt": enhanced["prompt"],
                "metadata": enhanced["metadata"],
                "layer_type": "background"
            }
        )

        return result

    # ────────────────────────────────────────────────
    # الواجهة القديمة للتوافق (من input_port)
    # ────────────────────────────────────────────────
    def generate_image(
        self,
        force_refresh: bool = False,
        as_layer: bool = True,
        target_size: Tuple[int, int] = (1024, 1024),
        reset_input_after: bool = True,
        is_video: bool = False,
        **kwargs
    ) -> GenerationResult:
        """
        الواجهة القديمة – تجمع الـ prompt من input_port
        (للتوافق مع الكود القديم، لكن نفس الإخراج النصي)
        """
        if not self.input_port:
            return GenerationResult(
                success=False,
                message="لا يوجد prompt في input_port",
                total_time=0.0,
                stage_times={},
                specialization=self.specialization["name"]
            )

        full_prompt = " ".join(self.input_port).strip()
        logger.info(f"[Environment] generate_image called – prompt: {full_prompt[:70]}...")

        result = self.generate_layer(
            prompt=full_prompt,
            target_size=target_size,
            is_video=is_video,
            as_layer=as_layer,
            force_refresh=force_refresh,
            **kwargs
        )

        if reset_input_after:
            self.input_port.clear()

        return result

    # ────────────────────────────────────────────────
    # الدوال الأساسية
    # ────────────────────────────────────────────────
    def receive_input(self, prompt: str) -> bool:
        """استقبال وصف جديد"""
        if not isinstance(prompt, str) or not prompt.strip():
            logger.warning("Prompt غير صالح أو فارغ")
            return False

        stripped = prompt.strip()
        self.input_port.append(stripped)
        logger.info(f"[Environment] received: {stripped[:60]}...")
        return True

    def _enhance_environment_prompt(self, prompt: str, force_refresh: bool = False) -> Dict[str, Any]:
        """
        تحسين وصف البيئة (يمكن توسيعها بـ LLM أو قواعد لاحقًا)
        """
        # مثال بسيط (يمكن استبداله بـ LLM call)
        enhanced = (
            f"{prompt}, ultra-detailed environment, cinematic atmosphere, "
            f"volumetric lighting, atmospheric perspective, depth of field, "
            f"highly detailed textures, 8k resolution"
        )

        metadata = {
            "mood": "immersive",
            "lighting": "volumetric",
            "depth": "high",
            "style_tags": ["cinematic", "atmospheric"]
        }

        return {
            "prompt": enhanced,
            "metadata": metadata,
            "confidence": 0.90,
            "notes": ["تم إضافة مصطلحات سينمائية"]
        }

    # ────────────────────────────────────────────────
    # إضافات اختيارية لاحقًا (مرجع مؤقت، مهام، ...)
    # ────────────────────────────────────────────────
    def add_task(self, task_name: str, complexity: float = 1.0):
        """إضافة مهمة بسيطة (اختياري)"""
        if not hasattr(self, "tasks"):
            self.tasks = []
        self.tasks.append({"name": task_name, "complexity": complexity})

    def get_tasks(self) -> List[Dict]:
        return getattr(self, "tasks", [])

    def _post_analyze_add_notes(self, task_data: dict) -> None:
        """
        دالة خفيفة بديلة (اختيارية): تضيف ملاحظات وصفية نصية فقط
        - لا تضيف مهام بصرية أو tasks
        - تستخدم لتسجيل اقتراحات تحسين نصية لاحقًا
        """
        logger.info("===== بدء _post_analyze_add_notes (Environment) =====")
        
        entities = task_data.get("entities", [])
        mood = task_data.get("mood", "neutral")
        notes = []

        if not entities:
            notes.append("لا توجد كيانات محددة → وصف عام")
        else:
            notes.append(f"كيانات رئيسية: {', '.join(entities[:5])}")
        
        if mood != "neutral":
            notes.append(f"مزاج المشهد: {mood} → يُفضل إضافة إضاءة/طقس مناسب")
        
        # مثال بسيط: اقتراحات نصية
        if any(e in entities for e in ["rain", "fog", "mist", "ضباب"]):
            notes.append("اقتراح: أضف volumetric fog وwet reflections للواقعية")
        
        task_data["enhancement_notes"] = notes
        logger.info(f"تم إضافة {len(notes)} ملاحظة وصفية")
        
    def generate_image(
        self,
        force_refresh: bool = False,
        as_layer: bool = True,
        target_size: Tuple[int, int] = (1024, 1024),
        reset_input_after: bool = True,
        is_video: bool = False,
        **kwargs
    ) -> GenerationResult:
        """
        الواجهة القديمة للتوافق – تجمع من input_port
        → تم تنظيفها تمامًا: ترجع dict نصي محسن فقط (لا صورة، لا حفظ، لا render)
        """
        start_total = perf_counter()
        stage_times = {"enhance": 0.0}

        try:
            if not self.input_port:
                return GenerationResult(
                    success=False,
                    message="لا يوجد prompt في المنفذ",
                    total_time=0.0,
                    stage_times={},
                    specialization=self.specialization["name"],
                    output_data={}
                )

            full_prompt = " ".join(self.input_port).strip()
            logger.info(f"[Environment generate_image] prompt: {full_prompt[:70]}...")

            # تحليل وتحسين (بدون أي render أو حفظ)
            t_start = perf_counter()
            enhanced = self._enhance_environment_prompt(full_prompt, force_refresh=force_refresh)
            stage_times["enhance"] = perf_counter() - t_start

            # تنظيف creepy إن وجد
            if self.memory_manager.check_for_creepy(full_prompt, enhanced):
                recovered = self.memory_manager.auto_recovery_on_creepy(full_prompt, "environment")
                if recovered:
                    enhanced["prompt"] = recovered["raw_prompt"]
                enhanced = self.memory_manager.refresh_memory(full_prompt, enhanced, "environment")
                logger.info("[Environment] تم refresh بسبب creepy detection")

            # إضافة ملاحظات وصفية (بديل خفيف لـ _post_analyze_add_tasks)
            self._post_analyze_add_notes(enhanced)

            total_time = perf_counter() - start_total

            result = GenerationResult(
                success=True,
                message="تم تحسين وصف البيئة بنجاح (نصي فقط)",
                total_time=total_time,
                stage_times=stage_times,
                specialization=self.specialization["name"],
                is_video=is_video,
                output_data={
                    "enhanced_prompt": enhanced["prompt"],
                    "metadata": enhanced["metadata"],
                    "notes": enhanced.get("enhancement_notes", []),
                    "layer_type": "background"
                }
            )

            logger.info(f"[Environment] نجح (نصي) | وقت: {total_time:.2f} ث")

            if reset_input_after:
                self.input_port.clear()

            return result

        except Exception as e:
            logger.exception("[Environment generate_image] فشل")
            return GenerationResult(
                success=False,
                message=f"فشل تحسين الوصف: {str(e)}",
                total_time=perf_counter() - start_total,
                stage_times=stage_times,
                specialization=self.specialization["name"],
                output_data={}
            )

    def generate_temp_reference(self, prompt_dict: dict) -> str | None:
        """
        توليد صورة مرجعية مؤقتة بسيطة (placeholder / layout تخطيطي)
        - تستخدم فقط كمرجع لتغيير زاوية الكاميرا في Final_Generation
        - تُحفظ مؤقتًا وتُسجّل في self.temp_files للحذف التلقائي لاحقًا
        - لا تُستخدم كصورة نهائية أبدًا
        """
        import time
        import os
        from PIL import Image, ImageDraw

        try:
            timestamp = int(time.time() * 1000)
            temp_path = f"temp_env_ref_{timestamp}.png"

            # أبعاد من prompt_dict أو افتراضية
            width, height = prompt_dict.get("target_size", (1024, 1024))

            # صورة مرجعية بسيطة جدًا (تخطيط أساسي للبيئة)
            img = Image.new("RGB", (width, height), color=(10, 15, 30))  # خلفية داكنة
            draw = ImageDraw.Draw(img)

            # رسم تخطيط بسيط يمثل عناصر بيئية عامة
            # أرض / أفق
            draw.rectangle([(0, height//2), (width, height)], fill=(30, 50, 70))
            draw.line((0, height//3, width, height//3), fill="cyan", width=10)  # خط أفق أوضح

            # عناصر رمزية (يمكن تخصيصها لاحقًا بناءً على prompt_dict)
            draw.ellipse((width//4, height//4, width*3//4, height*3//4), outline="white", width=8)  # شمس/قمر
            draw.rectangle((width//5, height//2 - 80, width*2//5, height//2), fill="gray")  # مبنى رمزي

            img.save(temp_path, "PNG")
            logger.info(f"[Temp Ref] تم حفظ مرجع مؤقت: {temp_path}")

            # تسجيل الملف للحذف التلقائي (من Final_Generation)
            if not hasattr(self, 'temp_files'):
                self.temp_files = []
            self.temp_files.append(temp_path)

            return temp_path

        except Exception as e:
            logger.error(f"فشل توليد مرجع مؤقت: {e}")
            return None

# ────────────────────────────────────────────────
#              تنفيذ اختياري للـ preview
# ────────────────────────────────────────────────

    def _analyze_prompt(self, prompt: str) -> Dict[str, Any]:
        """
        تحليل الـ prompt واستخراج الكيانات والمزاج بطريقة بسيطة ونصية فقط
        - ترجع dict محسن بدون أي مهام بصرية أو تعقيد أو integration
        """
        if not prompt or not isinstance(prompt, str):
            logger.warning("Prompt فارغ أو غير صالح")
            prompt = ""

        lower = prompt.lower()

        # استخراج الكيانات (entities) بدون تكرار
        entities = set()

        # مجموعات كلمات دقيقة (يمكن توسيعها)
        cyber_indicators = {"cyber", "cyberpunk", "neon", "hologram", "سايبر", "نيون", "هولو"}
        nature_indicators = {"forest", "mountain", "ocean", "غابة", "جبل", "بحر"}
        weather_indicators = {"rain", "fog", "mist", "ضباب", "مطر"}

        words = set(lower.split())

        if any(w in words or w in lower for w in cyber_indicators):
            entities.add("cyberpunk")

        if any(w in words or w in lower for w in nature_indicators):
            entities.add("nature")

        if any(w in words or w in lower for w in weather_indicators):
            entities.add("atmospheric")

        # تحديد المزاج (mood) بسيط
        if "cyber" in lower or "سايبر" in lower:
            mood = "cyberpunk"
        elif any(w in lower for w in ["mysterious", "سحري", "غامض"]):
            mood = "mysterious"
        elif any(w in lower for w in ["calm", "هادئ"]):
            mood = "calm"
        else:
            mood = "neutral"

        # بناء النتيجة النصية فقط
        result = {
            "entities": list(entities),
            "mood": mood,
            "main_element": entities.pop() if entities else "generic_background",
            "raw_prompt": prompt,
            "analysis_timestamp": datetime.now().isoformat(),
            "enhancement_notes": []  # سيتم ملؤها إذا أردت
        }

        # ملاحظات نصية بسيطة (بديل خفيف لـ _post_analyze_add_tasks)
        if entities:
            result["enhancement_notes"].append(f"كيانات رئيسية: {', '.join(entities)}")
        if mood != "neutral":
            result["enhancement_notes"].append(f"مزاج: {mood} → يُفضل إضافة إضاءة/طقس مناسب")

        logger.info(
            f"[Environment Analyze] entities={result['entities']!r} | "
            f"mood={mood} | main={result['main_element']}"
        )

        return result

    def _post_process_environment(self, task_data: Dict) -> float:
        complexity = sum(t.get("complexity", 0) for t in self.tasks)
        base_time = complexity * 0.7

        logger.info(f"[environment Post-process] وقت تقريبي: {base_time:.1f}s")
        return base_time

    def _render(self, task_data: Dict, is_video: bool = False) -> tuple[float, Optional[str]]:
        """
        مرحلة الـ rendering الرئيسية لمحرك البيئة.
        تنتج طبقة خلفية (background layer) وليس صورة نهائية كاملة.
        
        Returns:
            tuple[float, Optional[str]]: 
                - الوقت الفعلي للعملية (ثواني)
                - مسار الطبقة المُنشأة (أو None إذا فشل)
        """
        t_start = perf_counter()
        preview_path = None

        try:
            logger.debug("[Environment Render] بدء توليد طبقة الخلفية...")

            # ─── دعم أفضل للفيديو (حتى لو placeholder حاليًا) ─────────────────────
            if is_video:
                logger.info("[Environment Render] طلب فيديو → سيتم توليد GIF بسيط (placeholder)")
                # هنا يمكن توسيع لاحقًا لعدد إطارات أكبر أو حركة أقوى
                n_frames = 16  # عدد إطارات افتراضي للـ GIF
            else:
                n_frames = 1

            preview_path = self._create_simple_image(
                task_data=task_data,
                is_video=is_video,
                transparent_bg=False,          # الخلفية عادة غير شفافة (background)
                target_size=(1024, 1024),
                layer_opacity=255              # كاملة لأنها الطبقة الأساسية
            )

            if preview_path and Path(preview_path).exists():
                suffix = "GIF" if is_video else "PNG"
                logger.info(f"[Environment Render] تم إنشاء طبقة {suffix} بنجاح → {preview_path}")
            else:
                logger.warning("[Environment Render] فشل في إنشاء مسار طبقة صالح")

        except Exception as e:
            logger.exception("[Environment Render] خطأ أثناء توليد طبقة الخلفية")
            preview_path = None

        render_time = perf_counter() - t_start

        # تسجيل واضح
        mode = "فيديو (GIF)" if is_video else "طبقة خلفية ثابتة"
        time_str = f"{render_time:.3f} ث" if render_time >= 0.02 else f"{render_time:.4f} ث (سريع)"
        path_str = preview_path or "فشل"
        logger.info(f"[Environment Render] {mode} | وقت: {time_str} | مسار: {path_str}")

        return render_time, preview_path

    def _create_simple_image(
        self,
        task_data: Dict,
        is_video: bool = False,
        transparent_bg: bool = False,
        target_size: tuple = (1024, 1024),
        layer_opacity: int = 255
    ) -> Optional[str]:
        """
        إنشاء طبقة خلفية بيئية بناءً على الـ entities والـ mood
        """
        try:
            from PIL import Image, ImageDraw
            import random
            import math
            from pathlib import Path
            from datetime import datetime

            width, height = target_size
            n_frames = 12 if is_video else 1
            frames = []

            entities_set = set(str(e).lower() for e in task_data.get("entities", []))
            raw = task_data.get("raw_prompt", "").lower()
            mood = task_data.get("mood", "neutral")

            for frame in range(n_frames):
                # ─── اختيار لون خلفية أساسي ───────────────────────────────
                if transparent_bg:
                    img = Image.new("RGBA", (width, height), (0, 0, 0, 0))
                    base_color = (0, 0, 0, 0)
                else:
                    img = Image.new("RGB", (width, height), (8, 8, 24))
                    base_color = (8, 8, 24)

                draw = ImageDraw.Draw(img)

                # ─────────────────────────────────────────────────────────────
                # حالات متعددة مرتبة حسب الأولوية الشائعة
                # ─────────────────────────────────────────────────────────────

                if "cyberpunk" in entities_set or "neon_glow" in entities_set or "cybercity" in entities_set:
                    # ─── Cyberpunk / Neon City ───────────────────────────────
                    img = Image.new("RGB", (width, height), (6, 0, 20))
                    # أفقي نيون
                    for y in range(40, height, random.randint(90, 180)):
                        a = random.randint(90, 220)
                        draw.line((0, y, width, y), fill=(0, 255, 240, a), width=2)
                    # رأسي نيون
                    for x in range(60, width, random.randint(110, 220)):
                        a = random.randint(80, 190)
                        draw.line((x, 0, x, height), fill=(255, 60, 220, a), width=1)
                    # جسيمات / نقاط نيون
                    for _ in range(80):
                        x = random.randint(0, width)
                        y = (random.randint(0, height) + frame * 6) % height
                        sz = random.uniform(1.2, 5)
                        draw.ellipse((x-sz, y-sz, x+sz, y+sz), fill=(0, 255, 255, 160))

                elif "space" in entities_set or "galaxy" in entities_set or "stars" in entities_set or "nebula" in raw:
                    # ─── Space / Galaxy / Night Sky ──────────────────────────
                    img = Image.new("RGB", (width, height), (3, 0, 12))
                    # نجوم صغيرة كثيرة
                    for _ in range(600):
                        x, y = random.randint(0, width), random.randint(0, height)
                        sz = random.uniform(0.6, 2.1)
                        br = random.randint(140, 255)
                        draw.point((x, y), fill=(br, br, br))
                    # نجوم أكبر (قليلة)
                    for _ in range(18):
                        x, y = random.randint(0, width), random.randint(0, height)
                        sz = random.uniform(2.5, 5.5)
                        draw.ellipse((x-sz, y-sz, x+sz, y+sz), fill=(255, 245, 220))
                    # سديم خفيف (2-5 مناطق)
                    for _ in range(random.randint(2, 5)):
                        cx = random.randint(100, width-100)
                        cy = random.randint(100, height-100)
                        for r in range(80, 380, 45):
                            a = int(35 + 25 * math.sin(frame*0.08 + r*0.015))
                            draw.ellipse((cx-r, cy-r, cx+r, cy+r), outline=(90, 40, 220, max(0,a)))

                elif "desert" in entities_set or "صحراء" in raw or "sand" in raw or "dune" in raw:
                    # ─── Desert / Sand Dunes ─────────────────────────────────
                    # تدرج رملي
                    for y in range(height):
                        t = y / height
                        r = int(180 + 40 * t)
                        g = int(140 + 60 * t)
                        b = int(60 + 30 * t)
                        draw.line((0, y, width, y), fill=(r, g, b))
                    # كثبان رملية (منحنيات بسيطة)
                    for _ in range(6):
                        base_x = random.randint(-200, width + 200)
                        base_y = height - random.randint(80, 300)
                        points = []
                        for i in range(0, width + 400, 80):
                            x = base_x + i
                            wave = math.sin(i * 0.008 + frame * 0.04) * 35
                            points.append((x, base_y + wave + math.sin(i * 0.015) * 60))
                        if len(points) >= 2:
                            draw.polygon(points + [(width, height), (0, height)], fill=(210, 170, 100))

                elif "mountain" in entities_set or "جبل" in raw or "peak" in raw:
                    # ─── Mountains ───────────────────────────────────────────
                    img = Image.new("RGB", (width, height), (20, 30, 50))
                    # سماء تدرج
                    for y in range(height // 2):
                        t = y / (height // 2)
                        draw.line((0, y, width, y), fill=(40 - int(20*t), 50 - int(25*t), 90 - int(40*t)))
                    # جبال متعددة
                    for _ in range(5):
                        x = random.randint(-100, width + 100)
                        h = random.randint(300, height - 100)
                        pts = [(x-180, height), (x, height - h), (x+180, height)]
                        gray = random.randint(60, 110)
                        draw.polygon(pts, fill=(gray, gray, gray))
                        # ثلج في القمة (اختياري)
                        if random.random() > 0.4:
                            snow_h = h * random.uniform(0.18, 0.35)
                            draw.polygon([
                                (x-80, height - h + snow_h),
                                (x, height - h),
                                (x+80, height - h + snow_h)
                            ], fill=(230, 230, 240))

                elif "ocean" in entities_set or "sea" in entities_set or "underwater" in entities_set or "بحر" in raw:
                    # ─── Ocean / Underwater ──────────────────────────────────
                    img = Image.new("RGB", (width, height), (0, 20, 60))
                    # تدرج مائي
                    for y in range(height):
                        t = y / height
                        b = int(60 + 140 * t)
                        g = int(20 + 60 * t)
                        draw.line((0, y, width, y), fill=(0, g, b))
                    # موجات سطحية
                    for _ in range(40):
                        x = random.randint(0, width)
                        y = random.randint(0, height // 4)
                        sz = random.randint(30, 120)
                        a = random.randint(30, 90)
                        draw.ellipse((x-sz, y-sz, x+sz, y+sz), outline=(200, 240, 255, a), width=2)

                elif "rain" in entities_set or "storm" in entities_set or "مطر" in raw:
                    # ─── Rain / Storm ────────────────────────────────────────
                    for _ in range(180):
                        x = random.randint(0, width)
                        y_start = random.randint(-200, height)
                        y_end = y_start + random.randint(40, 140) + frame * 8
                        thick = random.randint(1, 3)
                        draw.line((x, y_start % height, x, y_end % height), fill=(180, 190, 220, 160), width=thick)

                elif "forest" in entities_set or "غابة" in raw or "jungle" in raw:
                    # ─── Forest ──────────────────────────────────────────────
                    img = Image.new("RGB", (width, height), (10, 25, 15))
                    for _ in range(35):
                        x = random.randint(-60, width + 60)
                        h = random.randint(320, height - 60)
                        g = random.randint(50, 110)
                        draw.polygon([
                            (x-110, height), (x, height - h), (x+110, height)
                        ], fill=(20, g, 20))
                    # ضباب / fog خفيف
                    for _ in range(30):
                        x = random.randint(0, width)
                        y = random.randint(0, height // 2)
                        r = random.randint(140, 400)
                        draw.ellipse((x-r, y-r, x+r, y+r), fill=(220, 240, 220, 35))

                else:
                    # ─── Fallback عام (سماء داكنة + عناصر بسيطة) ───────────
                    for y in range(0, height, 160):
                        draw.line((0, y, width, y), fill=(50, 40, 90, 100), width=4)

                frames.append(img)

            # ─── حفظ الإطار/الصورة النهائية ────────────────────────────────
            ts = datetime.now().strftime("%Y%m%d_%H%M%S_%f")[:-3]
            suffix = "bg_layer" if transparent_bg else "env"
            ext = "gif" if is_video and len(frames) > 1 else "png"
            path = f"env_{suffix}_{ts}.{ext}"

            if is_video and len(frames) > 1:
                frames[0].save(path, save_all=True, append_images=frames[1:],
                            duration=140, loop=0, optimize=True)
            else:
                final = frames[0]
                if layer_opacity < 255:
                    if final.mode != "RGBA":
                        final = final.convert("RGBA")
                    alpha = Image.new("L", final.size, layer_opacity)
                    final.putalpha(alpha)
                final.save(path, quality=89, optimize=True)

            logger.info(f"[Environment] حفظ → {path}")
            return str(path)

        except Exception as e:
            logger.exception("فشل _create_simple_image")
            return None
        
# ────────────────────────────────────────────────
#              اختبار سريع (اختياري)
# ────────────────────────────────────────────────
if __name__ == "__main__":
    engine = environment_design_engine()   # ← هنا ما فيش حاجة لاستيراد إضافي

    engine.receive_input("cyberpunk cityscape with neon lights, flying cars, holographic billboards and towering skyscrapers")
    engine.add_task("main_cityscape", complexity=4.5)
    engine.add_task("neon_glow", complexity=3.2)
    engine.add_task("flying_vehicles", complexity=3.8, dependencies=["main_cityscape"])

    result = engine.generate_image(force_refresh=True)

    print("\nنتيجة environment:")
    print(f"نجاح: {result.success}")
    print(f"رسالة: {result.message}")
    print(f"الوقت الكلي: {result.total_time:.2f} ث")
    if result.output_data and "preview_path" in result.output_data:
        print(f"مسار المعاينة: {result.output_data['preview_path']}")