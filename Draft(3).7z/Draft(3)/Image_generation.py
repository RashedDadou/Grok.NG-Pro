# Image_generation.py
"""
النواة الأساسية + المحركات المتخصصة (Pipeline لتوليد الصور)
"""

import ast
from typing import Dict, List
from abc import ABC, abstractmethod
from dataclasses import dataclass
from collections import deque, defaultdict
import logging
from time import perf_counter
import matplotlib.pyplot as plt
from matplotlib.animation import FuncAnimation, PillowWriter
import numpy as np
from pathlib import Path
from dataclasses import dataclass, field
from PIL import Image
from pathlib import Path
from unified_stage_pipeline import traditional_design_engine, UnifiedStagePipeline
from datetime import datetime
from typing import Dict, List, Optional, Any


logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s | %(levelname)-7s | %(message)s'
)
logger = logging.getLogger(__name__)

def print_generation_result(name: str, result_or_list) -> Optional[str]:
    """
    طباعة ملخص نتيجة التوليد – تدعم كائن واحد أو قائمة من الكائنات
    """
    if isinstance(result_or_list, list):
        print(f"\nنتيجة {name} (قائمة من {len(result_or_list)} نتائج):")
        preview_paths = []
        for i, res in enumerate(result_or_list, 1):
            print(f"  نتيجة رقم {i}:")
            print(f"    نجاح          : {res.success}")
            print(f"    رسالة         : {res.message}")
            print(f"    الوقت الكلي   : {res.total_time:.2f} ث")
            if res.output_data and "preview_path" in res.output_data:
                path = res.output_data["preview_path"]
                preview_paths.append(path)
                print(f"    → معاينة       : {path}")
                if Path(path).is_file():
                    print("      (الملف موجود فعليًا)")
                else:
                    print("      تحذير: المسار موجود لكن الملف غير موجود!")
            print("    ────────────────")
        return preview_paths  # ترجع قائمة المسارات

    # حالة كائن واحد (الوضع القديم)
    print(f"\nنتيجة {name}:")
    print(f"  نجاح          : {result_or_list.success}")
    print(f"  رسالة         : {result_or_list.message}")
    print(f"  الوقت الكلي   : {result_or_list.total_time:.2f} ث")

    if result_or_list.stage_times:
        print("  أوقات المراحل:")
        for k, v in result_or_list.stage_times.items():
            print(f"    • {k:14} : {v:.3f} ث")

    preview_path = None
    if result_or_list.output_data and "preview_path" in result_or_list.output_data:
        preview_path = result_or_list.output_data["preview_path"]
        print(f"  → معاينة       : {preview_path}")
        if Path(preview_path).is_file():
            print("    (الملف موجود فعليًا)")
        else:
            print("    تحذير: المسار موجود لكن الملف غير موجود!")
    else:
        print("  → لم يتم إرجاع مسار معاينة")

    return preview_path

@dataclass
class GenerationResult:
    success: bool
    message: str
    total_time: float
    stage_times: Dict[str, float]
    specialization: str
    is_video: bool = False
    output_data: Optional[Dict] = None
    mode: Optional[str] = None          # ← أضف هذا السطر

    def __post_init__(self):
        if self.stage_times is None:
            self.stage_times = {}

class CoreImageGenerationEngine(ABC):
    def __init__(self):
        super().__init__()  # لو كان فيه super من قبل
        self.specialization = self._get_specialization_config()
        self.tasks: List[Dict[str, Any]] = []
        self.dependencies: Dict[str, List[str]] = {}
        self.reverse_deps: Dict[str, List[str]] = defaultdict(list)
        self.input_port: List[str] = []
        self.render_time: float = 0.0
        self.current_prompt = ""               # النص المتراكم حالياً
        self.tracked_words = []                # الكلمات المكتملة حتى الآن
        self.stage_times = {}  # ← هنا نحفظ أوقات كل مرحلة
        self.last_refresh_time = 0.0
        self.min_refresh_interval = 1.8      # ثواني
        self.min_words_for_auto = 4
        self.last_prompt_hash = ""

    @abstractmethod
    def _get_specialization_config(self) -> Dict[str, Any]:
        pass

    @abstractmethod
    def _analyze_prompt(self, prompt: str) -> Dict[str, Any]:
        pass

    @abstractmethod
    def _integrate(self, task_data: Dict) -> float:
        pass

    @abstractmethod
    def _post_process(self, task_data: Dict) -> float:
        pass

    @abstractmethod
    def _render(self, task_data: Dict, is_video: bool = False) -> float:
        pass

    @abstractmethod
    def _create_simple_image(self, task_data: Dict, is_video: bool = False) -> Optional[str]:
        pass

    def receive_input(self, input_data: str) -> bool:
        if not input_data or not isinstance(input_data, str):
            logger.error("الإدخال غير صالح أو فارغ")
            return False

        stripped = input_data.strip()
        if not stripped:
            logger.warning("الإدخال بعد التنظيف فارغ")
            return False

        self.append_prompt_chunk(stripped)
        logger.info(f"تم إضافة إدخال جديد ({len(self.input_port)} في المنفذ) → {stripped[:60]}...")
        return True

class GeometricDesignEngine(CoreImageGenerationEngine):
    """
    النواة المشتركة - لا يتم إنشاء كائن منها مباشرة
    كل محرك متخصص يرث منها
    """

    def receive_input(self, input_data: str) -> bool:
        if not input_data:
            logger.warning("إدخال فارغ")
            return False
        self.append_prompt_chunk(input_data.strip())
        logger.info(f"تم إضافة وصف جديد: {input_data[:60]}...")
        return True

    def add_task(self, name: str, complexity: float = 1.0, dependencies: Optional[List[str]] = None):
        task = {"name": name, "complexity": max(0.0, complexity)}
        self.tasks.append(task)
        self.dependencies[name] = dependencies or []
        for dep in self.dependencies[name]:
            self.reverse_deps[dep].append(name)
        logger.debug(f"أضيفت مهمة: {name} (تعقيد {complexity})")

    def check_dependencies(self) -> bool:
        all_names = {t["name"] for t in self.tasks}
        for task_name, deps in self.dependencies.items():
            missing = [d for d in deps if d not in all_names]
            if missing:
                logger.error(f"اعتماديات مفقودة لـ '{task_name}': {missing}")
                return False
        return True

    def refresh_stage(self, stage: str):
        units = self.specialization.get("units", {})
        if stage in units and isinstance(units[stage], dict):
            units[stage]["refreshed"] = True
            logger.info(f"تم تنشيط إعادة التوليد للمرحلة: {stage}")
        else:
            logger.warning(f"المرحلة '{stage}' غير موجودة أو غير قابلة للتنشيط")

    def _topological_sort(self) -> List[str]:
        indegree = {t["name"]: len(self.dependencies.get(t["name"], [])) for t in self.tasks}
        queue = deque([name for name, deg in indegree.items() if deg == 0])
        order = []

        while queue:
            node = queue.popleft()
            order.append(node)
            for child in self.reverse_deps[node]:
                indegree[child] -= 1
                if indegree[child] == 0:
                    queue.append(child)

        if len(order) != len(self.tasks):
            logger.warning("يوجد دورة أو اعتماديات مفقودة → ترتيب غير كامل")
        return order

    def auto_refresh_check(self, stage: str) -> bool:  # غيرتها إلى دالة داخل الكلاس لتسهيل الوصول إلى self
        """
        تقييم ما إذا كان من المفيد إعادة تنفيذ مرحلة معينة،
        وتفعيل refreshed تلقائياً إذا كان ذلك ضرورياً.
        """
        units = self.specialization.get("units", {})
        if stage not in units:
            logger.warning(f"المرحلة '{stage}' غير موجودة")
            return False

        # إذا كانت refreshed مفعلة بالفعل → ننفذ ونرجع
        if units[stage].get("refreshed", False):
            return True

        tasks = self.tasks
        if not tasks:
            return False

        task_count = len(tasks)
        total_complexity = sum(t.get("complexity", 0) for t in tasks)

        need_refresh = False

        if task_count >= 3:
            need_refresh = True
            logger.debug(f"عدد المهام ({task_count}) كبير → تفعيل refreshed لـ {stage}")

        elif total_complexity > 7.0:
            need_refresh = True
            logger.debug(f"تعقيد كلي مرتفع ({total_complexity:.1f}) → تفعيل refreshed لـ {stage}")

        elif stage in ("integration", "post_processing"):
            has_deps = any(self.dependencies.get(t["name"], []) for t in tasks)
            if has_deps:
                need_refresh = True
                logger.debug(f"يوجد اعتماديات → تفعيل refreshed لـ {stage}")

        if need_refresh:
            units[stage]["refreshed"] = True
            logger.info(f"تم تفعيل refreshed تلقائياً للمرحلة: {stage}")

        return need_refresh
  
    def _get_specialization_config(self) -> Dict[str, Any]:
        return {
            "name": "geometric_design",
            "rendering_style": "geometric",
            "units": {
                "nlp": {"function": self._analyze_prompt},
                "integration": {"function": self._integrate},
                "post_processing": {"function": self._post_process},
                "rendering": {"function": self._render},
            }
        }

    def _analyze_prompt(self, prompt: str) -> Dict[str, Any]:
        logger.info("[Geometric] Analyzing prompt...")
        entities = []
        if "spiral" in prompt.lower():
            entities.append("spiral")
        if "hex" in prompt.lower():
            entities.append("hexagon")
        return {"entities": entities, "symmetry_level": "high" if "symmetrical" in prompt.lower() else "medium", "planes": []}  # أضفت planes فارغة لتجنب KeyError

    def _render(self, task_data: Dict, is_video: bool = False) -> float:
        logger.info("[Geometric] Rendering...")
        complexity = len(task_data.get("entities", [])) * 0.8
        time_cost = complexity + (1.5 if is_video else 0.0)
        return time_cost

    def _integrate(self, task_data):
        logger.info("[Geometric] Integrating...")
        # مثال: لو بتنشئ planes
        # planes = task_data.get("planes", [])
        # logger.info(f"عدد الطبقات: {len(planes)}")

    def _post_process(self, task_data: Dict) -> Dict[str, Any]:
        entities_count = len(task_data.get("entities", []))
        symmetry_bonus = 0.3 if task_data.get('symmetry_level') == 'high' else 0.0
        duration = 0.4 + entities_count * 0.15 + symmetry_bonus

        logger.info(
            f"[Geometric Post-process] وقت تقريبي: {duration:.1f}s - "
            f"تناظر عالي: {task_data.get('symmetry_level') == 'high'}"
        )

        return {
            "success": True,
            "duration_seconds": duration,
            "summary": f"Post-processing completed | symmetry: {task_data.get('symmetry_level', 'unknown')}",
            "entities_count": entities_count,
            "warnings": [],
            "metadata": {
                "symmetry_level": task_data.get("symmetry_level", "medium"),
                "processed_at": perf_counter()
            }
        }

    def _create_simple_image(self, task_data: Dict, is_video: bool = False) -> Optional[str]:
        import matplotlib.pyplot as plt
        import numpy as np
        from matplotlib.animation import FuncAnimation, PillowWriter
        from pathlib import Path

        specialization_name = self.specialization.get("name", "geometric")
        base_name = f"{specialization_name}_{'animation' if is_video else 'preview'}"
        output_path = Path(f"{base_name}.{'gif' if is_video else 'png'}")

        try:
            fig, ax = plt.subplots(figsize=(10, 10))
            ax.set_aspect('equal')
            ax.set_facecolor('#0a0a14')
            ax.set_xlim(-5.5, 5.5)
            ax.set_ylim(-5.5, 5.5)
            ax.set_xticks([])
            ax.set_yticks([])

            entities = task_data.get("entities", [])
            symmetry_level = task_data.get("symmetry_level", "medium")
            has_pattern = any(word in entities for word in ["pattern", "grid", "spiral", "fractal"])

            # ─── Koch snowflake ───────────────────────────────────────────────────────
            def koch_curve(start, end, iterations=3):
                if iterations == 0:
                    return [start, end]
                dx = end - start
                p1 = start + dx * 1/3
                p3 = start + dx * 2/3
                perp = np.array([-dx[1], dx[0]]) * (np.sqrt(3)/3)
                p2 = p1 + perp
                return (koch_curve(start, p1, iterations-1) +
                        koch_curve(p1, p2, iterations-1) +
                        koch_curve(p2, p3, iterations-1) +
                        koch_curve(p3, end, iterations-1))

            def draw_koch_snowflake(center, size, color='#00ffcc', alpha=0.72, iterations=4):
                angles = np.linspace(0, 2*np.pi, 4)[:-1]
                points = [center + size * np.array([np.cos(a), np.sin(a)]) for a in angles]
                points.append(points[0])
                curve_points = []
                for i in range(len(points)-1):
                    curve_points.extend(koch_curve(points[i], points[i+1], iterations))
                curve_points = np.array(curve_points)
                ax.plot(curve_points[:,0], curve_points[:,1], color=color, lw=1.6, alpha=alpha, zorder=8)

            if "fractal" in entities or has_pattern:
                draw_koch_snowflake(np.array([0,0]), 3.4, iterations=4)

            # ─── Golden spiral ────────────────────────────────────────────────────────
            golden_ratio = (1 + np.sqrt(5)) / 2
            spiral_data = None
            if has_pattern:
                n_turns = 7 if symmetry_level == "high" else 5
                theta = np.linspace(0, n_turns * 2 * np.pi, 500)
                r = 0.12 * np.exp(theta / (golden_ratio * 2.3))
                x = r * np.cos(theta)
                y = r * np.sin(theta)
                ax.plot(x, y, color='#ffd700', lw=2.3, alpha=0.9, zorder=7)

                # نقاط لامعة
                for i in range(0, len(theta), 38):
                    ax.scatter(x[i], y[i], s=90 + 30*np.sin(i/12), color='#ffeb3b',
                            alpha=0.75, edgecolor='white', zorder=9, linewidth=0.8)

                spiral_data = {'r': r.copy(), 'theta': theta.copy()}

            # ─── Planes + trails ──────────────────────────────────────────────────────
            planes_data = task_data.get("planes", [])
            planes_copy = []
            for p in planes_data:
                pos = np.array(p.get("position", [0, 0])[:2])
                color = p.get("color", "silver")
                scale = 0.25 + p.get("force", 1.0) * 0.18
                planes_copy.append({'position': pos, 'color': color, 'scale': scale})

                if "trail" in p and p["trail"]:
                    trail = np.array(p["trail"])
                    ax.plot(trail[:,0], trail[:,1], color=color, alpha=0.48, lw=1.4,
                            ls='--', zorder=6)

                ax.add_patch(plt.Circle(pos, scale*1.15, color=color, alpha=0.7,
                                    ec='white', lw=2.0, zorder=10))
                ax.text(pos[0] + scale*1.4, pos[1] + scale*1.4,
                        p.get("label", "Plane"), fontsize=9.5, color="white",
                        fontweight="bold", zorder=11)

            # ─── الـ Rendering حسب is_video ──────────────────────────────────────────
            if is_video:
                # التحقق: هل فيه محتوى يستحق الدوران؟
                if spiral_data is None and not planes_copy:
                    logger.info("[GIF] لا يوجد spiral ولا planes متحركة → حفظ صورة ثابتة")
                    output_path = output_path.with_suffix('.png')
                else:
                    # إعدادات الـ animation
                    frames_count = 140
                    rotation_speed = 0.75     # درجة لكل فريم
                    fps = 30

                    def update(frame):
                        ax.clear()
                        ax.set_xlim(-5.5, 5.5)
                        ax.set_ylim(-5.5, 5.5)
                        ax.set_facecolor('#0a0a14')
                        ax.set_xticks([])
                        ax.set_yticks([])

                        rot_rad = np.radians(frame * rotation_speed)

                        # دوران الـ spiral
                        if spiral_data is not None:
                            xr = spiral_data['r'] * np.cos(spiral_data['theta'] + rot_rad)
                            yr = spiral_data['r'] * np.sin(spiral_data['theta'] + rot_rad)
                            ax.plot(xr, yr, color='#ffd700', lw=2.4, alpha=0.92)

                            # نقاط لامعة متحركة
                            for i in range(0, len(xr), 42):
                                alpha_p = 0.65 + 0.35 * np.sin(frame * 0.28 + i * 0.12)
                                ax.scatter(xr[i], yr[i], s=110, color='#ffeb3b',
                                        alpha=alpha_p, edgecolor='white', zorder=9)

                        # دوران الـ planes
                        for plane in planes_copy:
                            pos = plane['position']
                            dx = pos[0] * np.cos(rot_rad) - pos[1] * np.sin(rot_rad)
                            dy = pos[0] * np.sin(rot_rad) + pos[1] * np.cos(rot_rad)
                            ax.add_patch(plt.Circle((dx, dy), plane['scale']*1.2,
                                                color=plane['color'], alpha=0.72,
                                                ec='white', lw=2.2, zorder=10))

                        ax.set_title(f"Geometric Harmony • {frame:03d}  |  {rotation_speed*frame:04.1f}°",
                                    color="white", fontsize=11, pad=12)

                    ani = FuncAnimation(fig, update, frames=frames_count,
                                        interval=1000/fps, blit=False)

                    writer = PillowWriter(fps=fps)
                    ani.save(output_path, writer=writer, dpi=180,
                            savefig_kwargs={'facecolor': '#05050f'})

                    logger.info(f"[Geometric Video] تم حفظ GIF دوراني "
                                f"({frames_count} فريم، {fps} fps): {output_path}")
                    plt.close(fig)
                    return str(output_path)

            # حفظ الصورة الثابتة
            fig.patch.set_facecolor('#05050f')
            plt.savefig(output_path, dpi=180, bbox_inches="tight",
                        facecolor=fig.get_facecolor())
            plt.close(fig)
            logger.info(f"[Geometric Preview] تم حفظ الصورة الثابتة: {output_path}")
            return str(output_path)

        except Exception as e:
            logger.exception(f"[Geometric Preview] فشل إنشاء المعاينة: {e}")
            plt.close('all')
            return None
    
# ────────────────────────────────────────────────
# الاختبار الرئيسي
# ────────────────────────────────────────────────
if __name__ == "__main__":
    # استخدم المحرك المناسب للـ prompt
    engine = GeometricDesignEngine()   # أو GeometricDesignEngine() حسب الاختبار
    specialization = "traditional_design"  # أو "geometric_design"

    # Prompt أول
    engine.receive_input("creature in forest with glowing aura")
    
    # مهام يدوية (اختياري، لو مش عايز تعتمد على التلقائي)
    engine.add_task("main_creature", complexity=4.5)
    engine.add_task("forest_background", complexity=3.0)
    engine.add_task("aura_effect", complexity=2.5)

    print("المهام قبل التوليد:", [t["name"] for t in engine.tasks])

    result = engine.generate_image(
        specialization=specialization,
        is_video=False,
        force_refresh=False
    )
    print_generation_result("أول توليد", result)

    # Prompt ثاني
    def clear_input(self):
        self.input_port = []
    setattr(engine, 'clear_input', clear_input.__get__(engine))  # لو عايز تبدأ من جديد
    engine.clear_input()
    engine.receive_input("symmetrical geometric pattern with golden spiral")

    result2 = engine.generate_image(
        specialization=specialization,
        is_video=False
    )
    print_generation_result("ثاني توليد", result2)

    print("\n" + "═" * 60)
    print("المهام النهائية:", [t["name"] for t in engine.tasks])
    print("═" * 60)